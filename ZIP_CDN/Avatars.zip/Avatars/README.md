### Typecho读者墙+头像缓存插件Avatars
2018年6月22日更新至**v1.2.5**: 
- 更新模版钩子及国内镜像服务
- 修正action的安全校验等bug
- 增加tooltip效果支持css定制

#### 详细说明与效果演示见blog发布地址: 
 > http://www.yzmb.me/archives/net/avatars-for-typecho