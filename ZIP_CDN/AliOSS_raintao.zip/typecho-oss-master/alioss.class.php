<?php
//检测API路径
require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'sdk.class.php';
