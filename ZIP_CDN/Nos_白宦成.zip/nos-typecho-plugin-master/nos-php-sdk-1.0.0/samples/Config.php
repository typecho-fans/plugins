<?php

class Config
{
    const NOS_ACCESS_ID = '';
    const NOS_ACCESS_KEY = '';
    const NOS_ENDPOINT = '';
    const NOS_TEST_BUCKET = '';
}

