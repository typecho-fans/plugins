# Typecho Plugin Adminer

Adminer is a full-featured MySQL management tool written in PHP. This plugin include this tool in Typecho.

## Description
Adminer (formerly phpMinAdmin) is a full-featured MySQL management tool written in PHP. Conversely to phpMyAdmin, it consist of a single file ready to deploy to the target server. This plugin include this tool in Typecho for a fast management of your database. [Adminer](http://www.adminer.org/ "Adminer") is also used without this plugin and Typecho.


## Installation
1. Unpack the download-package
2. Rename the folder to `Adminer`
3. Upload the file to your plugin-directory, default is `/usr/plugins/`
4. Activate the plugin through the 'Plugins' menu in Typecho.
5. Menu `Console` -> `Adminer`

## License
[MIT license](http://opensource.org/licenses/mit-license.php)
