# CompressHTML For Typecho

Typecho插件：该插件支持开启gzip、压缩HTML、HTML关键词替换

开发者：情留メ蚊子

插件地址：[http://www.94qing.com/compresshtml-for-typecho.html](http://www.94qing.com/compresshtml-for-typecho.html)

最新版本：1.0.0.1

更新日期：2016-12-23