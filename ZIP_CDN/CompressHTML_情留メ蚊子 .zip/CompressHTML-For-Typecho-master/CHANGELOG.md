Change Log
==========

Version 1.0.0.1 *(2016-12-31)*
----------------------------

 * 兼容FileCache插件，请安装本插件再安装FileCache插件
