Quicktags - Typecho编辑器
=========


为typecho博客系统移植的Quicktags编辑器工具。
