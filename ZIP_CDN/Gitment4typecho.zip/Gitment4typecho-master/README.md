# Gitment4typecho - Taskeren
基于[gitment](https://github.com/imsun/gitment)开发的评论/留言系统。
## 使用方法
1. 从 [Release](https://github.com/nitu2003/Gitment4typecho/release/latest) 中下载本项目  
2. 上传至 `/usr/plugin/`中  
3. 根据 [帮助文档](https://github.com/nitu2003/Gitment4typecho/wiki/Gitment4typecho-%E5%B8%AE%E5%8A%A9%E6%96%87%E6%A1%A3) 创建Github OAuth Application  
4. 在控制台启用和设置本插件  
5. 享受和 Star 本项目  

## 开源协议
本项目以WTFPL（Do What The Fuck You Want To Public License）协议开源  

## 特别鸣谢
[保罗](https://paugram.com)  

## 赞助
投喂宝：3070190799@qq.com  
微信：18658405256  
QQ：3070190799  

Made with Love <3  