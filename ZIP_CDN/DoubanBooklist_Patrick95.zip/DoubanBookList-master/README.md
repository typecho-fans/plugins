# Douban-BookList
Typecho 豆瓣个人书单展示插件



### 使用

下载并解压，上传到`/usr/plugins/`目录下，在Typecho后台开启本插件

新建一个独立页面，在文章内容区域插入**[douban_id:YourID]**(YourID为你的豆瓣id,并非豆瓣昵称)

### 已知问题

部分主题下，书单JS效果无法正常显示，或者影响主题本身动效。(大多为jQuery冲突)

### 预览

![https://raw.githubusercontent.com/Patrick-95/Douban-BookList/master/screenshot.png](https://raw.githubusercontent.com/Patrick-95/Douban-BookList/master/screenshot.png)

