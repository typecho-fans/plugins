# Typecho-Uighur-Input
A plugin for Typecho that input uighur characters directly.
