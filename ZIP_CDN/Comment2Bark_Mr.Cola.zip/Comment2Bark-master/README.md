# Comment2Bark

> Typecho 插件——新评论Bark通知 

## 感谢
本插件的推送采用了 [Fin](https://github.com/Finb/Bark) 的 [Bark]解决方案.

## 使用方法

 1. [点此下载](https://github.com/Colaink/Comment2Bark/archive/master.zip)，将解压后的目录名改为 `Comment2Bark`，然后上传到你的 Typecho 的 `/usr/plugins`，并在 Typecho 后台开启插件
 2. 在App Store商店搜索【Bark】，下载打开后，提取https://api.day.app/后边的字符串
 3. 将你 `BARKKEY` 填到插件设置里，保存即可


## 截图

![推送截图](pic.PNG)

## 更新记录
 - v1.0
   - init
