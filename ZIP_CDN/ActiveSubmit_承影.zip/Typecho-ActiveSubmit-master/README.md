# Typecho-ActiveSubmit
主动推送是目前百度收录效果最好的，本插件会在在文章发布时主动推送给百度。

**主动推送：**最为快速的提交方式，建议您将站点当天新产出链接立即通过此方式推送给百度，以保证新链接可以及时被百度收录。(特别适合时效性文章)



## 食用说明

- 上传文件后解压并重命名为ActiveSubmit
- 激活后在后台配置你的百度推送接口**token**（在百度搜索资源平台-提交链接处获取，需要有百度账号并站点所有权验证）
- 选择是否生成错误日志（如果生成，需要插件目录下可写权限）

![接口地址](https://blog.irow.top/usr/uploads/2019/07/2349109388.png)



## 项目地址

Github：<https://github.com/invelop/Typecho-ActiveSubmit>

码云：<https://gitee.com/invelop/Typecho-ActiveSubmit>

博客：<https://blog.irow.top/archives/562.html>
