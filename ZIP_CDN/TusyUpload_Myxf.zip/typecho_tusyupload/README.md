# typecho免费图片存储上传插件

在\usr\plugins\文件夹下创建文件夹TusyUpload，将文件放在TusyUpload中，管理后台插件中启用即可

免费存储申请地址：https://oss.bilnn.com/