<?php
/**
 * 图速云上传插件
 * @package TusyUpload
 * @author Myxf
 * @link https://gitee.com/mayoushang/typecho_tusyupload
 * @version 1.0.0
 * @date 2019年11月21日
 */
require __DIR__ . '/TusyUpload.php';

class TusyUpload_Plugin implements Typecho_Plugin_Interface
{
    // 激活插件
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Upload')->uploadHandle = array('TusyUpload_Plugin', 'uploadHandle');
        Typecho_Plugin::factory('Widget_Upload')->modifyHandle = array('TusyUpload_Plugin', 'modifyHandle');
        Typecho_Plugin::factory('Widget_Upload')->deleteHandle = array('TusyUpload_Plugin', 'deleteHandle');
        Typecho_Plugin::factory('Widget_Upload')->attachmentHandle = array('TusyUpload_Plugin', 'attachmentHandle');
        return _t('插件已经激活，需先配置图速云的信息！');
    }


    // 禁用插件
    public static function deactivate()
    {
        return _t('插件已被禁用');
    }


    // 插件配置面板
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $api_url = new Typecho_Widget_Helper_Form_Element_Text('api_url', null, 'http://', _t('API地址：(例：http://free-cn-01.oss.bilnn.com)'));
        $form->addInput($api_url->addRule('required', _t('API请求地址不能为空！')));

        $bucket = new Typecho_Widget_Helper_Form_Element_Text('bucket', null, '', _t('存储名称：(免费存储申请地址：https://oss.bilnn.com/)'));
        $form->addInput($bucket->addRule('required', _t('存储名称不能为空！')));

        $secret_key = new Typecho_Widget_Helper_Form_Element_Text('secret_key', null, '', _t('存储密钥：'));
        $form->addInput($secret_key->addRule('required', _t('存储密钥不能为空！')));

        $domain = new Typecho_Widget_Helper_Form_Element_Text('domain', null, '', _t('绑定域名：(例：www.bilnn.com)'));
        $form->addInput($domain);

        $style = new Typecho_Widget_Helper_Form_Element_Text('style', null, '', _t('样式名称：'));
        $form->addInput($style);
    }


    // 个人用户配置面板
    public static function personalConfig(Typecho_Widget_Helper_Form $form)
    {
    }


    // 获得插件配置信息
    public static function getConfig()
    {
        return Typecho_Widget::widget('Widget_Options')->plugin('TusyUpload');
    }


    // 删除文件
    public static function deleteFile($filepath)
    {   
        $option = self::getConfig();
        $TusyUpload = new TusyUpload($option->api_url,$option->bucket,$option->secret_key);
        $result = $TusyUpload->delfile($filepath);
        return $result;
    }


    // 上传文件
    public static function uploadFile($file, $content = null)
    {
        if (!empty($content['attachment']->path)){
            self::deleteFile($content['attachment']->path);
        }
        // 获取上传文件
        if (empty($file['name'])) return false;

        // 校验扩展名
        $part = explode('.', $file['name']);
        $ext = (($length = count($part)) > 1) ? strtolower($part[$length-1]) : '';
        if (!Widget_Upload::checkFileType($ext)) return false;

        // 获取插件配置
        $option = self::getConfig();
        // 上传文件
        $filename = $file['tmp_name'];
        $path = __TYPECHO_ROOT_DIR__."/usr/uploads/".date("YmdHis").rand(111111,999999).".".$ext;
        move_uploaded_file($filename, $path);
        if (!file_exists($path)) return false;
		$TusyUpload = new TusyUpload($option->api_url,$option->bucket,$option->secret_key);
		$result = $TusyUpload->upload($path);
        unlink($path);
		$arr = json_decode($result,true);
        if ($arr['code']!=0) return false;
        return array
            (
                'name'  =>  $arr['data']['name'],
                'path'  =>  $arr['data']['path'],
                'size'  =>  $arr['data']['size'],
                'type'  =>  $ext,
                'mime'  =>  Typecho_Common::mimeContentType($filename)
            );
    }


    // 上传文件处理函数
    public static function uploadHandle($file)
    {
        return self::uploadFile($file);
    }

    // 修改文件处理函数
    public static function modifyHandle($content, $file)
    {
        return self::uploadFile($file, $content);
    }


    // 删除文件
    public static function deleteHandle(array $content)
    {
        self::deleteFile($content['attachment']->path);
    }


    // 获取实际文件绝对访问路径
    public static function attachmentHandle(array $content)
    {
        $option = self::getConfig();
        $path = $content['attachment']->path;
        if (!empty($option->domain)){
            $url = parse_url($path);
            $path = str_replace($url['host'], $option->domain, $path);
        }
        if (!empty($option->style)){
            $path = $path."?style=".$option->style;
        }
        return $path;

    }
}