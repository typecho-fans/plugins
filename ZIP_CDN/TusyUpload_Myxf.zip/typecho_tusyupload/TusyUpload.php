<?php
class TusyUpload{

    /**
     * 上传图床接口
     */
    private $url = '';
    private $bucket = '';
    private $secret_key = '';

    public function __construct($url,$bucket,$secret_key){
        $this->url = $url;
        $this->bucket = $bucket;
        $this->secret_key = $secret_key;
    }

    /**
     * 上传图片
     * @param $file 图片文件/图片url
     * @return 返回的json数据
     */
    public function upload($file) {
        $url = $this->url."/?a=upload";
        $post['bucket'] = $this->bucket;
        $post['secret_key'] = $this->secret_key;
        if (class_exists('CURLFile')) {     // php 5.5
            $post['file'] = new \CURLFile(realpath($file));
        } else {
            $post['file'] = '@'.realpath($file);
        }
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
        @curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($curl, CURLOPT_AUTOREFERER, 1);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $post);
        curl_setopt($curl, CURLOPT_TIMEOUT, 30);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $tmpInfo = curl_exec($curl);
        if (curl_errno($curl)) {
           return '';
        }
        curl_close($curl);
        return $tmpInfo;
    }

    //删除图片
    public function delfile($filepath){
        //图片地址获取图片id
        $file_id = $this->get_file_id($filepath);
        if ($file_id<=0){
            return false;
        }else{
            $url = $this->url."/?c=file&a=file_del";
            $post['bucket'] = $this->bucket;
            $post['secret_key'] = $this->secret_key;
            $post['id'] = $file_id;
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
            @curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($curl, CURLOPT_AUTOREFERER, 1);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $post);
            curl_setopt($curl, CURLOPT_TIMEOUT, 30);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            $tmpInfo = curl_exec($curl);
            if (curl_errno($curl)) {
               return '';
            }
            curl_close($curl);
            $back = json_decode($tmpInfo,true);
            if ($back['code']==0){
                return true;
            }else{
                return false;
            }
        }
    }

    //图片地址获取图片id
    public function get_file_id($filepath){
        $url = $this->url."/";
        //如果url有样式就去除样式
        if (strpos($filepath, "?")!==false){
            $filepath = explode("?", $filepath);
            $filepath = $filepath[0];
        }
        //替换掉域名
        $host = parse_url($url);
        $filepath = str_replace("http://".$host."/", "", $filepath);
        $filepath = str_replace("https://".$host."/", "", $filepath);
        $url = $url."?c=file&a=get_file_id&url=".$filepath;
        $back = file_get_contents($url);
        $back = json_decode($back,true);
        if ($back['code']!=0){
            return 0;
        }else{
            return $back['data']['id'];
        }
    }
  
}

