# Typecho_Plugins_BaiduAnti

Typecho插件、在百度网址跳转到网站弹出提示的插件

# 使用说明：

1，在插件目录（/usr/plugins）新建的文件夹，名称：BaiduAnti

2，把下载的文件解压，并复制到新建的文件夹中

3，打开 博客的插件管理 界面，启动 BaiduAnti 插件

4，在百度搜索中，找到你的网站，然后点击，即可查看效果

![img](img/001.png)