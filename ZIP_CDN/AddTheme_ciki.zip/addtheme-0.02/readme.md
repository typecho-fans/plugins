# 在线下载主题到 typecho

## 背景

作者喜欢使用不同的主题，每隔几天就想去换主题，但是主题还要来回上传到服务器，太麻烦了，于是这款插件就诞生了。



## 快速使用

![typecho](https://github.com/cikiChe/addtheme/blob/6f4648be0b68854aa52101e9fed1cf1ae06f367c/typecho.gif?raw=true)



本插件 github 地址 ：https://github.com/cikiChe/addtheme

详细地址：https://blog.2pp.link/index.php/archives/166/


## 题外话

作者一直想为 typecho 开发一款插件，但是奈何作者比较懒。又不懂 typecho 的一些用法，所以本插件还是有不少瑕疵的，欢迎大家PR 和指出 。不管有没有 star, 作者心中的那团火是不会熄灭的。



## end

欢迎 PR 或者 fork 

最最后，卑微的作者在线求个 star
