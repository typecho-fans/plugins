## google-analytics-for-typecho

插件名称:`GoogleAnalytics`

下载压缩包后，需要把文件夹名称改为`GoogleAnalytics`，否则无法正常使用插件。

google analytics 在2015年4月份进行了升级。而之前 typecho 的插件还是使用的以前的代码，所以我就手动修改了一下，这样就支持最新版统计代码了。 [原版链接](http://blog.mutoo.im/google-analytics.html)

更新记录：
2018年09月08日 1.0.2版，优化代码，删除网站域名这一多余设置项。
2017年10月14日 1.0.1版，增加 Google Optimize 优化工具容器 设置。
2015年11月4日12:01:20 修改“其它代码”。
