<script type="text/javascript" src="<?php $options->siteUrl('usr/plugins/SkyCaiji/source/static/jquery.js'); ?>"></script>
<style type="text/css">
footer{display:none;}
</style>
<div id="install_status"></div>
<div id="error_msg" style="max-height:200px;overflow-y:scroll;"></div>
<div id="ifr_box">
	<iframe style="width:100%;height:100%;border:0;display:none;" name="ifr_install" id="ifr_install"></iframe>
</div>

<script type="text/javascript">
"use strict";
var boxHeight=$(window).height()-$('#ifr_box').offset().top;
$('#ifr_box').height((boxHeight-15)+'px');

var downloaded='<?php echo $downloaded;?>';
if(!downloaded){
	$.ajax({
		type: 'get',
		dataType: 'json',
		url:"<?php $options->adminUrl('extending.php?panel=SkyCaiji%2Fpanel.php&type=install&opdo=files');?>",
		success: function (list) {
			if(list.success){
				$('#install_status').html("<?php echo $langData['tpl_downloading'];?> <span class='num'>"+downSize+'</span>\/'+parseInt(list.size/1024/1024)+'mb - <span class="perct">'+parseInt((downSize/list.size)*100)+'</span>%');
				down_file(list,list.list[0]);//第一个开始
			}else{
				if(list.error){
					alert(list.error);
				}else{
					$('#error_msg').html("<?php echo $langData['tpl_down_none'];?>");
				}
			}
		},
		error: function(data) {
			$('#error_msg').html("<?php echo $langData['tpl_down_failed'];?>");
		}
	});
}else{
	bushu_install(0);
}

var downSize=0;//已下载字节
var downNum=0;//已下载数量
function down_file(list,size){
	$.ajax({
		type: 'get',
		dataType: 'json',
		url:"<?php $options->adminUrl('extending.php?panel=SkyCaiji%2Fpanel.php&type=install&opdo=down');?>",
		data:{'size':list.size,'start_size':size.start,'end_size':size.end,'fileid':size.id},
		success: function (block) {
			if(block.success){
				downSize+=size.end-size.start+1;
				downNum++;
				$('#install_status').find('.num').text(parseInt(downSize/1024/1024)+'mb');
				$('#install_status').find('.perct').text(parseInt((downSize/list.size)*100));

				if(list.list.length>size.id&&list.list[size.id]){
					//有下一个
					down_file(list,list.list[size.id]);
				}
			}else{
				$('#error_msg').append("<p><?php echo $langData['tpl_block_down'];?>"+size.id+"<?php echo $langData['tpl_failed'];?></p>");
			}
		},
		error: function(){
			$('#error_msg').append("<p><?php echo $langData['tpl_block_get'];?>"+size.id+"<?php echo $langData['tpl_failed'];?></p>");
		},
		complete:function(){
			if(downNum==list.list.length){
				$('#install_status').find('.num').text(parseInt(list.size/1024/1024)+'mb');
				$('#install_status').append("<?php echo $langData['tpl_downloaded'];?>").find('.perct').text(100);
				
				bushu_install(list.size);
			}
		}
	});
}

function bushu_install(size){
	$.ajax({
		type: 'get',
		dataType: 'json',
		url:"<?php $options->adminUrl('extending.php?panel=SkyCaiji%2Fpanel.php&type=install&opdo=bushu');?>",
		data:{size:size},
		success: function (bushu) {
			if(bushu.success){
				if(bushu.error){
					$('#error_msg').html(bushu.error);
				}else{
					$('#ifr_install').show();
					$('#ifr_install').attr('src',"<?php echo $skycaijiUrl;?>/index.php?s=/Install");
					if(bushu.db){
						if(size>0){
							$('#install_status').append("<?php echo $langData['tpl_deployed'];?>");
						}
						
						$('#ifr_install').bind('load',function(){
							var ifr=$('#ifr_install').contents();
							var formDb=ifr.find('#form_db');
							if(formDb.length>0){
								for(var i in bushu.db){
									formDb.find('[name="'+i+'"]').val(bushu.db[i]);
								}
							}
						});
					}
				}
			}else{
				$('#error_msg').html("<?php echo $langData['tpl_file_lost'];?>");
			}
		},
		error: function(){
			$('#error_msg').append("<?php echo $langData['tpl_deploy_failed'];?>");
		}
	});
}
</script>