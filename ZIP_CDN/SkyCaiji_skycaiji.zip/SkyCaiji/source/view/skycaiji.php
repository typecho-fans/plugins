<script type="text/javascript" src="<?php $options->siteUrl('usr/plugins/SkyCaiji/source/static/jquery.js'); ?>"></script>
<style type="text/css">
footer{display:none;}
#ifr_box{display:block;overflow:hidden;}
#ifr_skycaiji{width:100%;height:100%;border:0;}
</style>
<div id="ifr_box">
	<iframe id="ifr_skycaiji" src="<?php echo $skycaijiUrl;?>/index.php?s=admin"></iframe>
</div>
<script type="text/javascript">
$('#body').css({'padding':0});
$('#body > .container').removeClass('container');

var boxHeight=$(window).height()-$('#ifr_box').offset().top;
$('#ifr_box').height(boxHeight+'px');
</script>