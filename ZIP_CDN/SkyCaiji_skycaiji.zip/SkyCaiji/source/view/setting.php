<script type="text/javascript" src="<?php $options->siteUrl('usr/plugins/SkyCaiji/source/static/jquery.js'); ?>"></script>
<style type="text/css">
.sky-box{
	width:50%;;
	margin:20px auto;
	border: 1px solid #e9e9e9;
    border-radius: 0.25rem;
	padding:20px;
    background: #f8f9fa;
    box-shadow: 2px 2px 3px rgba(173, 181, 189, 0.25);
}
.sky-box-title{margin:0;padding:0;margin-bottom:10px;font-size:18px;}
.sky-form-group{margin-bottom:15px;}
.sky-form-group .form-control{width:100%;margin:5px 0;}
.sky-form-group .help-block{color:#999;padding:0;margin:0;}
</style>
<div class="sky-box">
	<h4 class="sky-box-title"><?php echo $langData['tpl_bushu'];?></h4>
	<form id="form_params" action="<?php $options->adminUrl('extending.php?panel=SkyCaiji%2Fpanel.php&type=index');?>" method="post">
		<div class="sky-form-group">
			<div><?php echo $langData['tpl_path'];?></div>
			<input type="text" class="form-control" name="params[path]" value="skycaiji" />
			<p class="help-block"><?php echo $langData['tpl_path_tips'];?></p>
		</div>
		<div class="sky-form-group">
			<div><?php echo $langData['tpl_user'];?></div>
			<input type="text" class="form-control" name="params[user]" value="<?php $user->screenName();?>" />
			<p class="help-block"><?php echo $langData['tpl_user_tips'];?></p>
		</div>
		<div class="sky-form-group">
			<div><?php echo $langData['tpl_pwd'];?></div>
			<input type="text" class="form-control" name="params[pwd]" value="" />
			<p class="help-block"><?php echo $langData['tpl_pwd_tips'];?></p>
		</div>
		<div class="sky-form-group">
			<div><?php echo $langData['tpl_email'];?></div>
			<input type="text" class="form-control" name="params[email]" value="<?php $user->mail();?>" />
			<p class="help-block"><?php echo $langData['tpl_email_tips'];?></p>
		</div>
		<button type="submit" class="btn btn-default" id="btn_install"><?php echo $langData['tpl_install'];?></button>
	</form>
</div>
<script type="text/javascript">
$('#form_params').bind('submit',function(){
	var obj=$(this);
	$.ajax({
		type: 'post',
		dataType: 'json',
		url:obj.attr('action'),
		data:obj.serialize(),
		success: function (data) {
			if(data.success){
				window.location.href="<?php $options->adminUrl('extending.php?panel=SkyCaiji%2Fpanel.php&type=install');?>";
			}else{
				alert(data.error);
			}
		}
	});
	return false;
});

</script>
