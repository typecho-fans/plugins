<?php
//error_reporting(E_ERROR | E_PARSE);

class skycaiji {
	public static $rootPath;//插件目录
	public static $cmsUrl;//cms根网址 
	public static $cmsPath;//cms根目录
	public static $lang;//语言包
	public static function init($cmsPath='',$cmsUrl=''){
		self::$rootPath=dirname(dirname(__FILE__)).'/';
		self::$cmsUrl=$cmsUrl;
		self::$cmsPath=$cmsPath.'/';
		self::$lang=array(
			'error_path'=>'目录名称只能由字母组成！',
			'error_user'=>'用户名长度3-15位',
			'error_pwd'=>'密码长度6-20位',
			'error_email'=>'邮箱格式错误',
			'error_zip'=>'解压失败',
			'error_ziparchive'=>'您的服务器不支持ZipArchive解压',
			'error_zip_self'=>'，请自行将文件{down}skycaiji.zip 解压到{plugin}里',
				
			'tpl_bushu'=>'一键部署',
			'tpl_path'=>'安装目录：',
			'tpl_path_tips'=>'设置蓝天采集器安装目录，将在根目录中创建文件夹',
			'tpl_user'=>'账号：',
			'tpl_user_tips'=>'设置蓝天采集器管理员账号',
			'tpl_pwd'=>'密码：',
			'tpl_pwd_tips'=>'设置蓝天采集器管理员密码',
			'tpl_email'=>'邮箱：',
			'tpl_email_tips'=>'设置蓝天采集器管理员邮箱',
			'tpl_install'=>'开始安装',
			
			'tpl_downloading'=>'正在下载... ',
			'tpl_down_none'=>'没有获取到文件',
			'tpl_down_failed'=>'获取文件失败',
			'tpl_failed'=>'失败',
			'tpl_block_down'=>'下载片段文件',
			'tpl_block_get'=>'获取片段文件',
			'tpl_downloaded'=>' - 下载完成，正在部署...',
			
			'tpl_deployed'=>'部署完成',
			'tpl_file_lost'=>'<p>文件缺失，请重新下载</p>',
			'tpl_deploy_failed'=>'部署失败',
		);
	}
	
	public static function get_html($url, $header=null,$size) {
		$ch = curl_init ();
		curl_setopt ( $ch, CURLOPT_URL, $url );
		curl_setopt ( $ch, CURLOPT_TIMEOUT, 100 );
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt ( $ch, CURLOPT_FOLLOWLOCATION, 1 );
		curl_setopt ( $ch, CURLOPT_HEADER, 0 );
		curl_setopt ( $ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; AcooBrowser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)");
	
		//https模式
		curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
		curl_setopt ( $ch, CURLOPT_SSL_VERIFYHOST, FALSE );
	
		if (! empty ( $header )) {
			curl_setopt ( $ch, CURLOPT_HTTPHEADER, $header );
		}
		//curl_setopt($ch, CURLOPT_RESUME_FROM, $offset);
		curl_setopt($ch, CURLOPT_RANGE, $size);
	
		$html = curl_exec ( $ch );
		curl_close ( $ch );
		return $html;
	}
	
	/*清空目录，不删除根目录*/
	public static function clear_dir($path,$passFiles=null){
		if(empty($path)){
			return;
		}
		$path=realpath($path);
		if(empty($path)){
			return;
		}
		if(!empty($passFiles)){
			$passFiles=array_map('realpath', $passFiles);
		}
	
		$fileList=scandir($path);
		foreach( $fileList as $file ){
			$fileName=realpath($path.'/'.$file);
			if(is_dir( $fileName ) && '.' != $file && '..' != $file ){
				self::clear_dir($fileName,$passFiles);
				rmdir($fileName);
			}elseif(is_file($fileName)){
				if($passFiles&&in_array($fileName, $passFiles)){
	
	
				}else{
					unlink($fileName);
				}
			}
		}
		clearstatcache();
	}
	
	public static function get_params(){
		$params=self::$rootPath.'data/params.php';//参数
		if(file_exists($params)){
			$params=include $params;
		}else{
			$params=null;
		}
		$params=is_array($params)?$params:array();
		return $params;
	}
	public static function set_params($params=array()){
		$params=is_array($params)?$params:array();
		$php="<?php\r\nreturn ".var_export($params,true).";\r\n?>";
		self::write_dir_file(self::$rootPath.'data/params.php',$php);//保存参数
	}
	public static function installed($params){
		if(!empty($params)&&file_exists(self::$cmsPath.$params['path'].'/SkycaijiApp/install/data/install.lock')){
			return true;
		}
		return false;
	}
	public static function downloaded($params){
		if(!empty($params)&&file_exists(self::$cmsPath.$params['path'].'/SkycaijiApp/install')){
			return true;
		}
		return false;
	}
	/*写入文件*/
	public static function write_dir_file($filename,$data,$flags=null,$content=null){
		$dir = dirname($filename);
		if(!is_dir($dir)){
			mkdir($dir,0777,true);
		}
		return file_put_contents($filename,$data,$flags,$content);
	}
	
	public static function echo_json($data){
		header('Content-Type:application/json; charset=utf-8');
		echo json_encode($data);
		exit();
	}
	
}
?>