<?php
if (! defined ( '__TYPECHO_ROOT_DIR__' ))
	exit ();
/**
 * 蓝天采集器，免费的数据采集系统
 *
 * @package SkyCaiji
 * @author skycaiji
 * @version 1.0.0
 * @link http://www.skycaiji.com
 */
class SkyCaiji_Plugin implements Typecho_Plugin_Interface {
	/* 激活插件方法 */
	public static function activate() {
		Helper::addPanel(1, 'SkyCaiji/panel.php', _t('蓝天采集器'), _t('蓝天采集器'), 'administrator');
	}
	
	/* 禁用插件方法 */
	public static function deactivate() {
        Helper::removePanel(1, 'SkyCaiji/panel.php');
	}
	
	/* 插件配置方法 */
	public static function config(Typecho_Widget_Helper_Form $form) {
		if(isset($_GET['config'])){
			header('Location:extending.php?panel=SkyCaiji%2Fpanel.php');//跳转安装界面
			exit();
		}
	}
	
	/* 个人用户的配置方法 */
	public static function personalConfig(Typecho_Widget_Helper_Form $form) {
	}
	
	/* 插件实现方法 */
	public static function render() {
	}
}
