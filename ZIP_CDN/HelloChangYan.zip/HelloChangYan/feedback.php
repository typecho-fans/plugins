<?php

header('Access-Control-Allow-Origin:*');
header("Access-Control-Allow-Method:POST,GET");

/**
 * 写入log文件 用于调试
 * 写入不成功 请尝试手动新建log文件并赋予写权限
 */
function write_log($content = '', $fileName = 'log.log')
{
	file_put_contents($fileName, date('Y-m-d H:i:s') . ' ' . $content . PHP_EOL, FILE_APPEND);
}

// 引入Typecho
require_once '../../../config.inc.php';
$jsonp = $_POST["data"];

write_log($jsonp);  // 调试开启

if($jsonp) {
	$jsonp = json_decode($jsonp);
	// 去掉多余字符串 获得标题
	$title = str_replace(' - 命中水', '', $jsonp->title); 
	// 查询标题ID
	$rows  = $db->fetchAll($db->select()->from('table.contents')->where('title = ?', $title));
	// 评论写入
	$db->query(
		$db->insert('table.comments')->rows(
			array(
				'cid'     => $rows['0']['cid'],
				'created' => $jsonp->comments['0']->ctime / 1000, 
				'author'  => $jsonp->comments['0']->user->nickname, 
				'ownerId' => $jsonp->comments['0']->cmtid , 
				// 'url'     => $jsonp->comments['0']->user->userurl,
				'ip'      => $jsonp->comments['0']->ip, 
				'agent'   => $jsonp->comments['0']->useragent, 
				'text'    => $jsonp->comments['0']->content, 
				'type'    => 'comment', 
				'status'  => 'approved', 
				'parent'  => $jsonp->comments['0']->replyid)
			)
		);
}else {
	write_log('没有json数据');
}


