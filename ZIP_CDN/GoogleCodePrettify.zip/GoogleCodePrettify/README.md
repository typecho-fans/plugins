### GoogleCodePrettify代码高亮插件 v2.0.0

为Markdown模式下的代码标记段落(3反引号包围或4空格开头)自动渲染高亮效果，支持多种样式自定义。例如：
<pre>
```
echo "Hello World!";
```
</pre>
非Markdown模式下请使用pre+code双标签包围代码，如：
```
<pre>
    <code>
        echo "Hello World!";
    </code>
</pre>
```

 > 修正默认样式生效bug和部分样式行号显示问题。

###### 更多详见作者博客：http://imnerd.org/google-code-prettify-plugin-for-typecho-0-9.html