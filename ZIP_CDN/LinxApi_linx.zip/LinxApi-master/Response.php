<?php


/**
 * Created by PhpStorm.
 * User: linx
 * Date: 2016/12/10
 * Time: 21:37
 */
class Response
{
    var $message;
}

