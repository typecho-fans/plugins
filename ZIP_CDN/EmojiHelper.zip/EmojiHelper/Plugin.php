<?php
/**
 * 解决typecho不支持使用Emoji的问题，其实就是封装sql，该插件实际并不会启动，点击启动后根据引导操作完成即可支持emoji
 * 
 * @package EmojiHelper
 * @author 泽泽社长
 * @version 2.0
 * @link http://qqdie.com
 */
class EmojiHelper_Plugin implements Typecho_Plugin_Interface
{ 
 public static function activate()
	{
$db = Typecho_Db::get();
$prefix = $db->getPrefix();
$db->query("
alter table ".$prefix."comments convert to character set utf8mb4 collate utf8mb4_unicode_ci;
alter table ".$prefix."contents convert to character set utf8mb4 collate utf8mb4_unicode_ci;
alter table ".$prefix."fields convert to character set utf8mb4 collate utf8mb4_unicode_ci;
alter table ".$prefix."metas convert to character set utf8mb4 collate utf8mb4_unicode_ci;
alter table ".$prefix."options convert to character set utf8mb4 collate utf8mb4_unicode_ci;
alter table ".$prefix."relationships convert to character set utf8mb4 collate utf8mb4_unicode_ci;
alter table ".$prefix."users convert to character set utf8mb4 collate utf8mb4_unicode_ci;
");
$turl=Helper::options()->pluginUrl.'/EmojiHelper/';
echo '<!DOCTYPE html><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"><meta http-equiv="X-UA-Compatible" content="IE=edge"><title>emoji引导</title><style type="text/css">html,body{height:100%;margin:0;padding:0}body{background-image:linear-gradient(120deg,#84fab0 0,#8fd3f4 100%)}div{text-align:center;padding-top:25vh}a{text-decoration:none;border:2px solid #ff3030;padding:10px 20px;border-radius:10px;font-size:24px;color:white;background:#ff3030}</style></head><body><div><a href="'.$turl.'rewrite.php">点我支持Emoji</a></div></body></html>';
exit();
    }
	/* 禁用插件方法 */
	public static function deactivate(){}
    public static function config(Typecho_Widget_Helper_Form $form){}
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
}