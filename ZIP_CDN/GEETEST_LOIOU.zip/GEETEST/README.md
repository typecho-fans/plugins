# GEETEST

#### 说明
GEETEST - Typecho插件

#### 安装
下载后改文件名为`GEETEST`，并在后台启动插件。
启动后设置参数。

#### 使用
`<?php GEETEST_Plugin::gtOut();?>`

#### 示例图
![前端展示](https://images.gitee.com/uploads/images/2019/0111/110030_3bb2a245_424874.png "前端展示")
![插件设置](https://images.gitee.com/uploads/images/2019/0111/110150_5d18361d_424874.png "插件设置")
