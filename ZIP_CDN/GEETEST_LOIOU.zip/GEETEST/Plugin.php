<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * GEETEST - 极验
 * 
 * @package GEETEST
 * @author LOIOU
 * @version 1.0.0
 * @link https://www.loiou.com
 */

require_once dirname(__FILE__) . '/gt/lib/class.geetestlib.php';

class GEETEST_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive') ->footer = array('GEETEST_Plugin', 'footerScript');
    }
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){}
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        /** 分类名称 */
        $id = new Typecho_Widget_Helper_Form_Element_Text('id', NULL, '48a6ebac4ebc6642d68c217fca33eb4d', _t('极验ID'));
        $form->addInput($id);
        
        $key = new Typecho_Widget_Helper_Form_Element_Text('key', NULL, '4f1c085290bec5afdc54df73535fc361', _t('极验KEY'));
        $form->addInput($key);
        
        $gtproduct = new Typecho_Widget_Helper_Form_Element_Select('gtproduct', array(
        'popup'=>'popup（弹出式）',
        'float' => 'float（浮动式）',      
        'bind' => 'bind（隐藏按钮类型）',
        'click' => 'click（点击按钮类型）'),
        'popup', _t('产品形式'), _t('id和key只有常量没有值的情况下会有[点击按钮类型]，会导致不记录验证数据。验证方式请在极验后台修改，如点击词语或滑动拼图验证。'));
        $form->addInput($gtproduct);
        
        $gtdiv = new Typecho_Widget_Helper_Form_Element_Text('gtdiv', NULL, 'captcha', _t('验证码容器ID'));
        $form->addInput($gtdiv);
        
        $btndiv = new Typecho_Widget_Helper_Form_Element_Text('btndiv', NULL, 'btn', _t('提交按钮ID'));
        $form->addInput($btndiv);
        
        $gtwidth = new Typecho_Widget_Helper_Form_Element_Text('gtwidth', NULL, '300px', _t('验证码宽度'), _t('官网高度固定44px'));
        $form->addInput($gtwidth);
        
        $jq_set = new Typecho_Widget_Helper_Form_Element_Radio(
          'jq_set', array(0 => '自己处理', 1 => '插件载入'), 0,'JQ设置');
        $form->addInput($jq_set);
    }
    
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    
    /**
     * JS 加入 footer
     *
     * @access public
     * @return void
     */
    public static function footerScript()
    {
        
        $options = Typecho_Widget::widget('Widget_Options');
        
        //极验验证
        if($options->plugin('GEETEST')->gtproduct == "click"){
            $GtSdk = new GeetestLib(CAPTCHA_ID, PRIVATE_KEY);
        }else{
            $GtSdk = new GeetestLib($options->plugin('GEETEST')->id, $options->plugin('GEETEST')->key);
        }
        
        session_start();
    
        $data = array(
        		"user_id" => "test", # 网站用户id
        		"client_type" => "web", #web:电脑上的浏览器；h5:手机上的浏览器，包括移动应用内完全内置的web_view；native：通过原生SDK植入APP应用的方式
        		"ip_address" => "127.0.0.1" # 请在此处传输用户请求验证时所携带的IP
        	);
        
        $status = $GtSdk->pre_process($data, 1);
        $_SESSION['gtserver'] = $status;
        $_SESSION['user_id'] = $data['user_id'];
        $server_data = $GtSdk->get_response_str();
        
        

        // 载入 jQuery
        if ($options->plugin('GEETEST')->jq_set)
        {
            echo "<script src='https://cdn.bootcss.com/jquery/2.2.4/jquery.min.js'></script>\n";
        }
        // 载入极验js
        echo "<script src='",$options->pluginUrl,"/GEETEST/gt/static/gt.js'></script>\n";
        echo "<script>var gtdiv ='#",$options->plugin('GEETEST')->gtdiv,"';var btndiv ='#",$options->plugin('GEETEST')->btndiv,"';var gturl ='",$options->pluginUrl,"';var gtproduct = '",$options->plugin('GEETEST')->gtproduct,"';var gtwidth = '",$options->plugin('GEETEST')->gtwidth,"';var data = ",$server_data,";</script>";
        echo "<script src='",$options->pluginUrl,"/GEETEST/main.js'></script>\n";
    }
    
    /**
     * 插件输出方法
     * 
     * @access public
     * @return void
     */
    public static function gtOut()
    {
        $options = Typecho_Widget::widget('Widget_Options');
        echo '<div id=',$options->plugin('GEETEST')->gtdiv,'></div>';
    }

}
