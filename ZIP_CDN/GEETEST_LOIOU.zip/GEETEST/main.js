$(function(){
    var handler = function (captchaObj) {
        captchaObj.appendTo(gtdiv); //添加到容器内
        captchaObj.onReady(function () { //加载后执行
            
        });
        $(btndiv).click(function () { //提交按钮点击事件
            if(gtproduct == 'bind'){
                captchaObj.verify();
                return false;
            }else{
                var result = captchaObj.getValidate(); //判断是否通过验证
                if (!result) {
                    alert('请完成验证');
                    return false;
                }
            }

            //后面可以放验证成功后所执行的事件
    
        })
        // 更多前端接口说明请参见：//docs.geetest.com/install/client/web-front/
    };
    
    
    // 调用 initGeetest 进行初始化
    // 参数1：配置参数
    // 参数2：回调，回调的第一个参数验证码对象，之后可以使用它调用相应的接口
    initGeetest({
        // 以下 4 个配置参数为必须，不能缺少
        gt: data.gt,
        challenge: data.challenge,
        offline: !data.success, // 表示用户后台检测极验服务器是否宕机
        new_captcha: data.new_captcha, // 用于宕机时表示是新验证码的宕机

        product: gtproduct, // 产品形式，包括：float，popup
        width: gtwidth //验证码宽度
        
        // 更多前端配置参数说明请参见：//docs.geetest.com/install/client/web-front/
    }, handler);


})