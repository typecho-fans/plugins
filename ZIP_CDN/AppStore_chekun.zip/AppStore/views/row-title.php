<tr>
    <th><?php echo _t('名称'); ?></th>
    <th><?php echo _t('描述'); ?></th>
    <th><?php echo _t('版本'); ?></th>
    <th><?php echo _t('版本要求'); ?></th>
    <th><?php echo _t('作者'); ?></th>
    <th><?php echo _t('操作'); ?></th>
</tr>