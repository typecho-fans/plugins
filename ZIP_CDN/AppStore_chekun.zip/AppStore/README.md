 > :no_entry:不可用：需要抓取和储存zip包的服务端配合，作者已关闭官网。  
 > 原Go脚本服务端源码(已废弃)：https://github.com/chekun/typecho-app-store  
 > 新Go脚本服务端源码(已停更)：https://github.com/chekun/echoed

Typecho 应用商店 插件
========================

The missing plugins store for Typecho!

## 如何使用

- 方法一

进入 [官网](https://typecho.chekun.me/) 搜索 AppStore, 下载对应的版本

- 方法二

进入 [Github Releases](https://github.com/typecho-app-store/AppStore/releases) 下载对应的版本

- 方法三

```
git clone git@github.com:chekun/AppStore.git AppStore
```

> 不管使用哪种方法，最终请将得到的文件夹命名为 *AppStore* 放到 *Typecho* 目录的 *usr/plugins* 目录下  
> 进入插件面板，启用本插件即可

## 代码贡献者

- [@chekun](https://github.com/chekun)
- [@jzwalk](https://github.com/jzwalk)
- [@fengyunljp](https://github.com/fengyunljp)
- [@aiwb](https://github.com/aiwb)

## 欢迎参与开发，共同完善
