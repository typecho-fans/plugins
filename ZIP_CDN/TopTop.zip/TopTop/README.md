# TopTop 

typecho 博客的一款返回顶部插件

## 使用方法 

Download ZIP, 解压

重命名文件夹为TopTop

上传至usr/plugins目录

登录后台启用即可

## 主题

自带两套主题,欢迎提供想法

在线体验: [夜雨博客](https://heeeepin.com)

![kk6h8K.png](https://s2.ax1x.com/2019/01/22/kk6h8K.png)
![kk64gO.png](https://s2.ax1x.com/2019/01/22/kk64gO.png)


## 感谢

[GoTop](https://github.com/NicoNicooooo/GoTop)






