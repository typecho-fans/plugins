KindEditor.lang({
	i_br : '换行',
	i_more : '摘要',
});