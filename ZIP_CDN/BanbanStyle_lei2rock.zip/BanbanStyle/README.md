# Typecho-Plugin-BanbanStyle

<a href="https://github.com/lei2rock/Typecho-Plugin-BanbanStyle"><img src="https://img.shields.io/badge/BanbanStyle-v0.3.1-brightgreen?&style=flat-square"></a>
<a href="https://typecho.org/"><img src="https://img.shields.io/badge/Typecho->=1.2-0e83cd?&style=flat-square"></a>

为「[班班碎碎念](https://blog.dlzhang.com)」Typecho 博客站点准备的简易配置插件

## 功能
 
注意：部分功能可能需要 Handsome 主题配合，未对其他主题适配。

- 设置多种类型的 Favicon 图标，推荐图片生成工具 [RealFaviconGenerator](https://realfavicongenerator.net)
- 搜索引擎优化（SEO）：设置 [Google 搜索](https://search.google.com/search-console)验证、[百度搜索资源平台](https://ziyuan.baidu.com/site)验证
- 设置 [Google 分析](https://analytics.google.com)网站识别代码
- 加载 Font Awesome 5 图标
- [Google Fonts](https://fonts.google.com) ：异步加载 EB Garamond、思源宋体的 400 和 700 字重字体（含斜体）
- 加载 Pangu.js，实现中英文字符直接自动空格排版
- 内置了 [Typecho-Plugin-macOScode 插件](https://github.com/lei2rock/Typecho-Plugin-macOScode)，实现 macOS 风格代码框

## 安装

1. 下载源码并上传到 Typecho 插件目录 `usr/plugins` 下
2. 修改插件文件夹名为 `BanbanStyle`
3. 在 Typecho 后台插件管理中启用插件，并进行相关设置
4. 请关闭之前开启的 Handsome 主题的代码高亮和风格
5. 如果开启了 PJAX，你需要添加回调/重载函数：

```javascript
// pangu.js
pangu.spacingPage();

// macOS 风格代码框
if (typeof Prism !== 'undefined') {
Prism.highlightAll(true,null);}
```

## macOS 风格代码框自定义

如果需要添加更多的代码语言高亮支持，可以参见 [lei2rock/Typecho-Plugin-macOScode](https://github.com/lei2rock/Typecho-Plugin-macOScode)