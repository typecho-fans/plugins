[
  {
    "category": "Lo",
    "mappings": {
      "default": {
        "default": "alef symbol",
        "alternative": "first transfinite cardinal",
        "short": "alef"
      }
    },
    "key": "2135"
  },
  {
    "category": "Lo",
    "mappings": {
      "default": {
        "default": "bet symbol",
        "alternative": "second transfinite cardinal",
        "short": "bet"
      }
    },
    "key": "2136"
  },
  {
    "category": "Lo",
    "mappings": {
      "default": {
        "default": "gimel symbol",
        "alternative": "third transfinite cardinal",
        "short": "gimel"
      }
    },
    "key": "2137"
  },
  {
    "category": "Lo",
    "mappings": {
      "default": {
        "default": "dalet symbol",
        "alternative": "fourth transfinite cardinal",
        "short": "dalet"
      }
    },
    "key": "2138"
  }
]