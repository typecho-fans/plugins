[
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "decimal exponent symbol"
      }
    },
    "key": "23E8"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "black star"
      }
    },
    "key": "2605"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "white star"
      }
    },
    "key": "2606"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "medium white circle",
        "short": "white circle"
      }
    },
    "key": "26AA"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "medium black circle",
        "short": "black circle"
      }
    },
    "key": "26AB"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "white heavy check mark",
        "short": "white check"
      }
    },
    "key": "2705"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "check mark",
        "short": "check"
      }
    },
    "key": "2713"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "heavy check mark",
        "short": "heavy check"
      }
    },
    "key": "2714"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "multiplication x"
      }
    },
    "key": "2715"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "heavy multiplication x"
      }
    },
    "key": "2716"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "ballot x"
      }
    },
    "key": "2717"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "heavy ballot x"
      }
    },
    "key": "2718"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "open center cross"
      }
    },
    "key": "271B"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "heavy open center cross"
      }
    },
    "key": "271C"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "maltese cross"
      }
    },
    "key": "2720"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "star of david"
      }
    },
    "key": "2721"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "four teardrop spoked asterisk"
      }
    },
    "key": "2722"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "four balloon spoked asterisk"
      }
    },
    "key": "2723"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "heavy four balloon spoked asterisk"
      }
    },
    "key": "2724"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "four club spoked asterisk"
      }
    },
    "key": "2725"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "black four pointed star"
      }
    },
    "key": "2726"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "white four pointed star"
      }
    },
    "key": "2727"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "sparkles"
      }
    },
    "key": "2728"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "stress outlined white star"
      }
    },
    "key": "2729"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "circled white star"
      }
    },
    "key": "272A"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "open center black star"
      }
    },
    "key": "272B"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "black center white star"
      }
    },
    "key": "272C"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "outlined black star"
      }
    },
    "key": "272D"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "heavy outlined black star"
      }
    },
    "key": "272E"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "pinwheel star"
      }
    },
    "key": "272F"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "shadowed white star"
      }
    },
    "key": "2730"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "heavy asterisk"
      }
    },
    "key": "2731"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "open center asterisk"
      }
    },
    "key": "2732"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "eight spoked asterisk"
      }
    },
    "key": "2733"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "eight pointed black star"
      }
    },
    "key": "2734"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "eight pointed pinwheel star"
      }
    },
    "key": "2735"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "six pointed black star"
      }
    },
    "key": "2736"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "twelve pointed black star"
      }
    },
    "key": "2739"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "sixteen pointed asterisk"
      }
    },
    "key": "273A"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "teardrop spoked asterisk"
      }
    },
    "key": "273B"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "open center teardrop spoked asterisk"
      }
    },
    "key": "273C"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "heavy teardrop spoked asterisk"
      }
    },
    "key": "273D"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "six petalled black and white florette"
      }
    },
    "key": "273E"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "black florette"
      }
    },
    "key": "273F"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "white florette"
      }
    },
    "key": "2740"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "eight petalled outlined black florette"
      }
    },
    "key": "2741"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "circled open center eight pointed star"
      }
    },
    "key": "2742"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "heavy teardrop spoked pinwheel asterisk"
      }
    },
    "key": "2743"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "snowflake"
      }
    },
    "key": "2744"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "tight trifoliate snowflake"
      }
    },
    "key": "2745"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "heavy chevron snowflake"
      }
    },
    "key": "2746"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "sparkle"
      }
    },
    "key": "2747"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "heavy sparkle"
      }
    },
    "key": "2748"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "balloon spoked asterisk"
      }
    },
    "key": "2749"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "eight teardrop spoked propeller asterisk"
      }
    },
    "key": "274A"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "heavy eight teardrop spoked propeller asterisk"
      }
    },
    "key": "274B"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "cross mark"
      }
    },
    "key": "274C"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "shadowed white circle"
      }
    },
    "key": "274D"
  }
]