[
  {
    "category": "Zs",
    "mappings": {
      "default": {
        "default": "space"
      }
    },
    "key": "0020"
  },
  {
    "category": "Zs",
    "mappings": {
      "default": {
        "default": "no break space",
        "alternative": "non breaking space"
      }
    },
    "key": "00A0"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "soft hyphen"
      }
    },
    "key": "00AD"
  },
  {
    "category": "Zs",
    "mappings": {
      "default": {
        "default": "en quad"
      }
    },
    "key": "2000"
  },
  {
    "category": "Zs",
    "mappings": {
      "default": {
        "default": "em quad"
      }
    },
    "key": "2001"
  },
  {
    "category": "Zs",
    "mappings": {
      "default": {
        "default": "en space"
      }
    },
    "key": "2002"
  },
  {
    "category": "Zs",
    "mappings": {
      "default": {
        "default": "em space"
      }
    },
    "key": "2003"
  },
  {
    "category": "Zs",
    "mappings": {
      "default": {
        "default": "three per em space"
      }
    },
    "key": "2004"
  },
  {
    "category": "Zs",
    "mappings": {
      "default": {
        "default": "four per em space"
      }
    },
    "key": "2005"
  },
  {
    "category": "Zs",
    "mappings": {
      "default": {
        "default": "six per em space"
      }
    },
    "key": "2006"
  },
  {
    "category": "Zs",
    "mappings": {
      "default": {
        "default": "figure space"
      }
    },
    "key": "2007"
  },
  {
    "category": "Zs",
    "mappings": {
      "default": {
        "default": "punctuation space"
      }
    },
    "key": "2008"
  },
  {
    "category": "Zs",
    "mappings": {
      "default": {
        "default": "thin space"
      }
    },
    "key": "2009"
  },
  {
    "category": "Zs",
    "mappings": {
      "default": {
        "default": "hair space"
      }
    },
    "key": "200A"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "zero width space"
      }
    },
    "key": "200B"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "zero width non joiner"
      }
    },
    "key": "200C"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "zero width joiner"
      }
    },
    "key": "200D"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "left to right mark"
      }
    },
    "key": "200E"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "right to left mark"
      }
    },
    "key": "200F"
  },
  {
    "category": "Zl",
    "mappings": {
      "default": {
        "default": "line separator"
      }
    },
    "key": "2028"
  },
  {
    "category": "Zp",
    "mappings": {
      "default": {
        "default": "paragraph separator"
      }
    },
    "key": "2029"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "left to right embedding"
      }
    },
    "key": "202A"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "right to left embedding"
      }
    },
    "key": "202B"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "pop directional formatting"
      }
    },
    "key": "202C"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "left to right override"
      }
    },
    "key": "202D"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "right to left override"
      }
    },
    "key": "202E"
  },
  {
    "category": "Zs",
    "mappings": {
      "default": {
        "default": "narrow no break space"
      }
    },
    "key": "202F"
  },
  {
    "category": "Zs",
    "mappings": {
      "default": {
        "default": "medium mathematical space"
      }
    },
    "key": "205F"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "word joiner"
      }
    },
    "key": "2060"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "function application",
        "short": "of"
      }
    },
    "key": "2061"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "invisible times",
        "short": "times"
      }
    },
    "key": "2062"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "invisible separator",
        "short": "separator"
      }
    },
    "key": "2063"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "invisible plus",
        "short": "plus"
      }
    },
    "key": "2064"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "inhibit symmetric swapping"
      }
    },
    "key": "206A"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "activate symmetric swapping"
      }
    },
    "key": "206B"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "national digit shapes"
      }
    },
    "key": "206E"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "nominal digit shapes"
      }
    },
    "key": "206F"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "zero width no break space",
        "alternative": "byte order mark"
      }
    },
    "key": "FEFF"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "interlinear annotation anchor"
      }
    },
    "key": "FFF9"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "interlinear annotation separator"
      }
    },
    "key": "FFFA"
  },
  {
    "category": "Cf",
    "mappings": {
      "default": {
        "default": "interlinear annotation terminator"
      }
    },
    "key": "FFFB"
  }
]
