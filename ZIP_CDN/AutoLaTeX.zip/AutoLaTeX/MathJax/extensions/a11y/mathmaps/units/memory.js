[
  {"category": "",
   "mappings": {
     "default": {
       "default": "bits"
     }
   },
   "key": "b",
   "names": ["b"]
  },
  {"category": "",
   "mappings": {
     "default": {
       "default": "bytes"
     }
   },
   "key": "B",
   "names": ["B"]
  },
  {"category": "",
   "mappings": {
     "default": {
       "default": "kilobytes"
     }
   },
   "key": "KB",
   "names": ["KB"]
  },
  {"category": "",
   "mappings": {
     "default": {
       "default": "megabytes"
     }
   },
   "key": "MB",
   "names": ["MB"]
  },
  {"category": "",
   "mappings": {
     "default": {
       "default": "gigabytes"
     }
   },
   "key": "GB",
   "names": ["GB"]
  },
  {"category": "",
   "mappings": {
     "default": {
       "default": "terabytes"
     }
   },
   "key": "TB",
   "names": ["TB"]
  }
]
