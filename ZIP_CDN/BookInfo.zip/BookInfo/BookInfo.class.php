<?php

class BookInfo{

    public static function getInfo($bookId){

        $localInfoHave = file_exists(__DIR__."/resources/bookinfo/".$bookId.".json");
     
        if($localInfoHave){
            return $localInfo = file_get_contents(__DIR__."/resources/bookinfo/".$bookId.".json"); 
        }else{
            return self::getInfoFromDouban($bookId);
        }

    }


    public static function getInfoFromDouban($bookId){

        $bookHref = 'https://api.douban.com/v2/book/'.$bookId;
        $doubanInfo = file_get_contents($bookHref);  
        $infoPath = __DIR__."/resources/bookinfo/".$bookId.".json";
        $infoSave = fopen($infoPath,"w");
        $sava = fwrite($infoSave, $doubanInfo); //将信息存入本地
        fclose($infoSave);
        return  $doubanInfo;

    }


    public static function getBookCover($bookId,$url){

        $localCoverHave = file_exists(__DIR__."/resources/bookcover/".$bookId.".jpg");
        $options = Helper::options();
        $siteUrl = $options->siteUrl;
    
        if($localCoverHave){

            $localCover = "/resources/bookcover/".$bookId.".jpg"; 
            return $siteUrl."usr/plugins/BookInfo/resources/bookcover/".$bookId.".jpg"; 

        }else{
           
            $localCover =  self::getImage($url,__DIR__."/resources/bookcover",$bookId.".jpg",0);  
           
            return $siteUrl."usr/plugins/BookInfo/resources/bookcover/".$localCover['file_name'];

        }

    } 


    public static function showBook($bookId){
        $bookInfoJson = self::getInfo($bookId);
        $bookInfo = json_decode($bookInfoJson);
        $bookCover =  self::getBookCover($bookId,$bookInfo->image);

        return $output = "
                <!-- 以下内容由BookInfo for Typecho插件生成-->
                <div class=\"bookCard\">
                    <div class=\"bookCover\">
                        <img src=\"".$bookCover."\" alt=\"BookCover\" class=\"coverImg\">
                    </div>

                    <div class=\"bookDetail\">
                        <div class=\"bookInfo\">
                            <h2><b><a href=\"".$bookInfo->alt."\">".$bookInfo->title."</a></b></h2>
                            <p><b>".$bookInfo->author[0]."</b> <span class=\"rate\"> 豆瓣评分：".$bookInfo->rating->average." 分</span></p> 
                            <p>".substr($bookInfo->summary,0,350)."......</p> 
                            <span class=\"more\"><a href=".$bookInfo->alt.">在豆瓣查看更多信息</a></p> 
                        </div>
                    </div>
                    <div style=\"clear:both;\"></div>
                </div>
                <!-- 以上内容由BookInfo for Typecho插件生成-->
                ";

    }



 protected static function getImage($url,$save_dir='',$filename='',$type=0){
        if(trim($url)==''){
            return array('file_name'=>'','save_path'=>'','error'=>1);
        }
        if(trim($save_dir)==''){
            $save_dir='./';
        }
        if(trim($filename)==''){//保存文件名
            $ext=strrchr($url,'.');
            if($ext!='.gif'&&$ext!='.jpg'){
                return array('file_name'=>'','save_path'=>'','error'=>3);
            }
            $filename=time().$ext;
        }
        if(0!==strrpos($save_dir,'/')){
            $save_dir.='/';
        }
        //创建保存目录
        if(!file_exists($save_dir)&&!mkdir($save_dir,0777,true)){
            return array('file_name'=>'','save_path'=>'','error'=>5);
        }
        //获取远程文件所采用的方法 
        if($type){
            $ch=curl_init();
            $timeout=300;
            curl_setopt($ch,CURLOPT_URL,$url);
            curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
            curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
            $img=curl_exec($ch);
            curl_close($ch);
        }else{
            ob_start(); 
            readfile($url);
            $img=ob_get_contents(); 
            ob_end_clean(); 
        }
        //$size=strlen($img);
        //文件大小 
        $fp2=@fopen($save_dir.$filename,'a');
        fwrite($fp2,$img);
        fclose($fp2);
        unset($img,$url);
        return array('file_name'=>$filename,'save_path'=>$save_dir.$filename,'error'=>0);
       
    }


}

