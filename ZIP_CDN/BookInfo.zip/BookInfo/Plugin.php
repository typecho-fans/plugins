<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * BookInfo 一款用于在博文中嵌入豆瓣图书信息的插件,使用方法：在需要嵌入图书信息卡的地方输入[book:27191009] 即可调用对应豆瓣图书编号(网址中subject后的数字)为27191009的豆瓣图书信息。
 * 
 * @package BookInfo  
 * @author Zephyr
 * @version 1.0.0
 * @link http://notekit.cn/a/0920180049/
 */

include_once('BookInfo.class.php');
class BookInfo_Plugin implements Typecho_Plugin_Interface
{


    /**
     * 自定义变量
     * 
     * 
     */

    public static $bookIds;



    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
      
        Typecho_Plugin::factory('Widget_Abstract_Contents')->contentEx = array('BookInfo_Plugin', 'showBookInfo');
    }
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){}
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form){}
    
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    
    /**
     * 插件实现方法
     * 
     * @access public
     * @return void
     */


    public static function showBookInfo($content,$widget,$lastResult){
        $getBookIds = self::getBookIds($content);
        $content = empty($lastResult) ? $content : $lastResult;
        if ($widget->is('page') | $widget->is('post') && false!==stripos($content,'[book')) {

           include("template/style.php");
           return $content = preg_replace_callback('/\[book\:(\w*[^>]*)\]/i',array('BookInfo_Plugin','callback'),$content);

        }else{
            return $content;
        }
    }


    public static function getBookIds($content){

        $rep = "/\[book\:(\w*[^>]*)\]/i";
        preg_match_all($rep,$content,$result);
        $bookIds = $result[1];
        self::$bookIds = $bookIds;
        
    }

    public static function callback(){
        static $i = 0;
        $i = $i+1;
        $bookId = self::$bookIds[$i-1];
        return BookInfo::showBook($bookId);

    }
}
