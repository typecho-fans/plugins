<style>

      /* BookInfo 图书信息插件 For Typecho 显示样式 */
    .bookCard {

        box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
        transition: 0.3s;
        margin-bottom: 10px;
        border-top: 1px solid #eee;
    }

    .bookCard:hover {
        box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
    }

    .bookCard .bookCover {
        float: left;
        padding: 10px;
        margin:5px;
    }

    .bookCard .coverImg {
        height:200px;
    }

    .bookCard .bookDetail a{
        color: #4169E1;
    }

  
    .bookInfo {
        padding: 2px 16px;
    }

    .bookInfo .rate{
        color: #000;
        margin-left: 20px;
    }

    .bookInfo .more{
        text-align: right;
    }
</style>