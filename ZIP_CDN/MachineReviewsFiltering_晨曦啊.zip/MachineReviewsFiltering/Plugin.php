<?php
/**
 * 机器评论屏蔽（测试版）
 *
 * @package MachineReviewsFiltering
 * @author 晨曦啊
 * @version 0.1.0
 * @link https://cx-a.com
 *
 * 历史版本
 * version 0.1.0 at 2018-11-13
 * 改进上一个版本的问题
 * 支持预加载
 * version 0.0.1 at 2018-11-11
 * 实现屏蔽机器人评论
 *
 */

class MachineReviewsFiltering_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     *
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Feedback')->comment = array('MachineReviewsFiltering_Plugin', 'shield');
        Typecho_Plugin::factory('Widget_Archive')->footer = array('MachineReviewsFiltering_Plugin', 'add_hide_input');
        return _t('屏蔽机器评论启用成功');
    }

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     *
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){}

    /**
     * 获取插件配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $shield = new Typecho_Widget_Helper_Form_Element_Radio('shield', array("enable" => "启用", "disable" => "禁用"), "enable",
            _t('屏蔽机器人的评论'), "是否启用屏蔽机器人评论。如果需要开启该屏蔽功能，请尝试进行评论测试，以免不同模板造成误判。");
        $form->addInput($shield);

        $s_cookie_name = new Typecho_Widget_Helper_Form_Element_Textarea('cookie_name', NULL, "5oiR54ix5L2g",
            _t('cookie名称设置'), _t('设置不同的名称，防止机器批量获取'));
        $form->addInput($s_cookie_name);

        $s_hide_name = new Typecho_Widget_Helper_Form_Element_Textarea('hide_name', NULL, "5LiA55Sf5LiA5LiW",
            _t('隐藏传的值'), _t('注意：最好不要是中文，大小写英文和数组就行了！！设置不同的名称，防止机器批量获取'));
        $form->addInput($s_hide_name);
    }

    /**
     * 个人用户的配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    /**
     * 评论过滤器
     *
     */
    public static function shield($comment, $post)
    {
        $options = Typecho_Widget::widget('Widget_Options');
        $shield_set = $options->plugin('MachineReviewsFiltering');
        $error = "";
        $a="";

        //机器评论处理
        if ($shield_set->shield == "enable") {

            $cx_a=$_POST['cx_a'];
            $strc=strrev(@$_COOKIE[$shield_set->cookie_name]);
            
            if (!$strc || $cx_a != $strc || $cx_a != $shield_set->hide_name) {
                $error = "不正常评论（如果不是机器人请返回页面重新刷新页面再评论！）";
                $a = 'enable';
            }
        }
        //执行操作
        if ($a == "enable") {
            throw new Typecho_Widget_Exception($error);
        }

        Typecho_Cookie::delete('__typecho_remember_text');
        return $comment;
    }

    /**
     * 在表单中增加隐藏域
     *
     */
    public static function add_hide_input(){
        $options = Typecho_Widget::widget('Widget_Options');
        $shield_set = $options->plugin('MachineReviewsFiltering');

        if ($shield_set->shield == "enable") {
            $a_str=$shield_set->hide_name;
            echo '<script type="text/javascript"> 
document.onkeydown=function(e){ 
    var text=document.getElementById("textarea");
    var cx_a=document.getElementById("cx_a");
    if(!cx_a){
        var input_h = document.createElement("input");
                input_h.type = "hidden";
                input_h.name = "cx_a";
                input_h.id = "cx_a";
                input_h.value = "'.$a_str.'";
                text.appendChild(input_h);
          var str="'.$a_str.'";
          str=str.split("").reverse().join("");
          document.cookie="'.$shield_set->cookie_name.'="+str;
    }
};
</script>';
        }
    }
}