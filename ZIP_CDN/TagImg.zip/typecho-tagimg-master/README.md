# TagImg for Typecho
----------------------------
## NOTICE 

已经放弃Typecho，不再更新。

## Description

根据tag来调用文章关联图片，类似cnbeta每个文章右边的图片

使用说明：
1.解压到插件目录
2.在usr/uploads放置想要调用的tag对应的图片，名称为 tag名称.jpg
3.后台激活插件
4.在写文章的时候写入指定的tag，即可调用相应的图片在文章前面。
5.目前使用Map.php来指定tag调用。

###1.0.4

* 在初始typecho 0.8 上测试无误
* 修改版本依赖

###1.0.3
* 增加版本检查

###1.0.2
* 修改文件路径，默认为上传路径

###1.0.1
* 修改Map文件的调用方式

## License

MIT License
