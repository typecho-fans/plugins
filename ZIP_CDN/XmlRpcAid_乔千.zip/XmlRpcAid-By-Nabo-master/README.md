# XmlRpcAid-By-Nabo
一款更新南博XmlRpc专用插件
# 使用教程
1.下载插件

2.解压到插件目录

3.更名文件夹为XmlRpcAid

4.启用插件

