# HyperMD

**Markdown编辑器 [HyperMD](https://github.com/laobubu/HyperMD) for Typecho**

![HyperMD.png](https://img.imjad.cn/images/2018/06/14/HyperMD.png)

## 介绍

- 所见即所得；
- 可通过拖放、粘贴快速上传图片；

## 使用

点击 ```Download ZIP``` 按钮，解压，将 HyperMD-Typecho-Plugin-master 重命名为 HyperMD ，之后上传到你博客中的 /usr/plugins 目录，在后台启用即可

## 感谢

[HyperMD](https://github.com/laobubu/HyperMD)

## LICENSE

MIT © [journey.ad](https://github.com/journey-ad/)
