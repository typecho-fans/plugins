# CommentAuditor
一款typecho插件。
[食用方法](https://b.nit9.cn/archives/9.html)