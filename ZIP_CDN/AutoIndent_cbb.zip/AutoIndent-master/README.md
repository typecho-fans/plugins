# AutoIndent
typecho插件，查看文章时给每个段落缩进。

不修改文章内容，只是在查看文章时使用js给每个段落前加上两个空格。

文件解压缩之后，将“AutoIndent”文件夹上传至服务器“/var/www/usr/plugins/”目录下，然后在浏览器登录typecho后台->控制台->插件，找到“AutoIndent”插件启用即可。
