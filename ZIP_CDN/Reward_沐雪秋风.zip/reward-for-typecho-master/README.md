# Reward

Reward是一个打赏插件，简单来说 就是那种有钱的土豪大佬看上我写的白水文，随手就点一下打赏，然后我就收到了这笔钱。


demo:   
https://yubanmei.com/archives/27/ 

### 如何安装

下载项目，将Reward文件夹放到./usr/plugins/<Reward>这个地方即可，请不要更改文件夹名称，会导致找不到文件。
然后到typecho后台启用即可

### 更改JavaScript
```
npm i
npm run watch
```

注意事项

 - 设置正确的时区

实现功能

 - 自定义完全后的消息
 - 插件设置项都是后台的，不需要更改源码
 - 轮询逻辑完备，也不会有人这么蛋疼给伪造吧
 - 可选是否验证ssl
 - 可选多个二维码生成api
 - 支持payjs渠道
 - 支持支付宝当面付渠道
 - 无冲突依赖，完全原生js
 - 引用sweetalert，实现美美哒


引用项目

https://github.com/t4t5/sweetalert  
https://github.com/musnow/alipayf2f  
https://github.com/musnow/payjs  


# License 许可证
Open sourced under the MIT license.

根据 MIT 许可证开源。