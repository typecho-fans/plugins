<?php
class CloudflareAPI{
    private static $cloudflareAPI = null;
    private $email = "";
    private $apiID = "";
    private $zoneID = "";

    public static function GetInstance(){
        if(CloudflareAPI::$cloudflareAPI == null){
            CloudflareAPI::$cloudflareAPI = new CloudflareAPI();
        }
        return CloudflareAPI::$cloudflareAPI;
    }

    private static function getJSON($url,$_email,$_apiID,$_zoneID){
        $headers = array(
            "X-Auth-Email: " . $_email,
            "X-Auth-Key: " . $_apiID,
            "Content-Type: text/plain",
        );
        $curl = curl_init($url);
        curl_setopt($curl,CURLOPT_URL,$url);
        curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($curl,CURLOPT_BINARYTRANSFER,true);
        curl_setopt($curl,CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl,CURLOPT_HTTPHEADER,$headers);
        curl_setopt($curl,CURLINFO_HEADER_OUT,true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        $json = curl_exec($curl);
        curl_close($curl);
        return $json;
    }

    public function init($_email,$_apiID,$_zoneID){
        if($_apiID == null || $_zoneID == null){
            echo '请填写字段';
            return;
        }
        $this -> $email = $_email;
        $this -> $apiID = $_apiID;
        $this -> $zoneID = $_zoneID;
    
        $data = fopen("data.json","w");
        $json = CloudflareAPI::getJSON("https://api.cloudflare.com/client/v4/zones/" . $_zoneID . "/analytics/dashboard?since=-10080&until=0&continuous=true",$_email,$_apiID,$_zoneID);
        fwrite($data,$json);
        fclose($data);
    }
}

class CloudflareAnalytics_Action extends Widget_Abstract_Contents implements Widget_Interface_Do{
    public function action(){
        $options = Helper::options();
        $email = $options -> plugin('CloudflareAnalytics') -> email;
        $apiID = $options -> plugin('CloudflareAnalytics') -> apiID;
        $zoneID = $options -> plugin('CloudflareAnalytics') -> zoneID;

        $cloudflare = CloudflareAPI::GetInstance();
        $cloudflare -> init($email,$apiID,$zoneID);
    }
}
?>