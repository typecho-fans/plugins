## typecho_Cloudflare_Analytics_Plugin

1. Make sure the directory of this plugin is **CloudflareAnalytics**. If not, rename it.

   确保插件目录名字是**CloudflareAnalytics**

2. Then you should copy page.php from your theme and rename it **cloudflare.php**.

   然后将你的主题独立页面模版文件复制一份，（比如page.php），改名为**cloudflare.php**

3. Add following codes at the begining of cloudflare.php.

    在开头加上如下注释：

```php
<?php
/**
 * cloudflare 统计
 * @package custom
 */
?>
```

4. Insert this line where the cloudflare.php output content.

    在输出文章内容的地方加上
    
```php
<?php CloudflareAnalytics_Plugin::output() ?>
```

5. And finally, you need to fill in fields of the plugin settings.

   Then create a new page which chose `cloudflare 统计` as a template.
   
   It will be OK. Good luck.:)

    填写插件相关字段，新建独立页面，选择`cloudflare 统计`模板，即可
