<?php
/**
 * Cloudflare 统计
 * @package CloudflareAnalytics
 * @author Cinema
 * @version 1.0.0
 * @link https://4o5.xyz
 */
class CloudflareAnalytics_Plugin implements Typecho_Plugin_Interface{
    public static function activate(){
        Helper::addRoute('route_CloudflareAnalytics','/CloudflareAnalytics','CloudflareAnalytics_Action','action');
        return '插件安装成功，请进入设置填写密钥';
    }

    public static function deactivate(){
        Helper::removeRoute('route_CloudflareAnalytics');
        return '插件卸载成功';
    }

    public static function config(Typecho_Widget_Helper_Form $form){
        $email = new Typecho_Widget_Helper_Form_Element_Text('email',null,null,_t('Cloudflare Email'));
        $form -> addInput($email);
        $apiID = new Typecho_Widget_Helper_Form_Element_Text('apiID',null,null,_t('Cloudflare API ID'));
        $form -> addInput($apiID);
        $zoneID = new Typecho_Widget_Helper_Form_Element_Text('zoneID',null,null,_t('Cloudflare Zone ID'));
        $form -> addInput($zoneID);
    }

    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    public static function render(){}

    public static function output(){
        $path = Helper::options() -> pluginUrl . "/CloudflareAnalytics/";
        echo '<script type="text/javascript" src="https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js">';
        echo '<script type="text/javascript" src="' . $path . 'assets/Chart.bundle.min.js"></script>
        <script type="text/javascript" src="' . $path . 'assets/Chart.min.js"></script>
        <style type="text/css" src="' . $path . 'assets/Chart.min.css"></style>
        <div id="cloudflare">
            <div style="display: block;"><canvas id="basic"></canvas></div>
            <div style="display: block;"><canvas id="type"></canvas></div>
            <div style="display: block;"><canvas id="ssl"></canvas></div>
            <div style="display: block;"><canvas id="search_engine"></canvas></div>
            <script>
                var httpRequest2 = new XMLHttpRequest();
                httpRequest2.open("GET","' . Helper::options() -> siteUrl . 'index.php/CloudflareAnalytics",true);
                httpRequest2.send();
                httpRequest2.onreadystatechange = function(){}
                var data2 = "";
                jQuery.ajax({type:"GET",url:"' . Helper::options() -> siteUrl . 'data.json",async:false,contentType:"application/json;charset=utf-8",dataType:"json",success:function(data2){draw(data2);}});
                function draw(data){
                    var array1 = new Array(6);
                    var array2 = new Array(13);
                    var array3 = new Array(3);
                    var array4 = new Array(4);
                    for(var i = 0;i < 6;i++) array1[i] = new Array(7);for(var i = 0;i < 14;i++) array2[i] = new Array(7);
                    for(var i = 0;i < 3;i++) array3[i] = new Array(7);for(var i = 0;i < 4;i++) array4[i] = new Array(7);
                    for(var i = 0;i < 7;i++){
                        array1[0][i] = new Date(data.result.timeseries[i].since).toDateString();
                        array1[1][i] = Math.round(parseInt(data.result.timeseries[i].uniques.all) / 10);
                        array1[2][i] = Math.round(parseInt(data.result.timeseries[i].requests.all) / 100);
                        array1[3][i] = parseInt(data.result.timeseries[i].bandwidth.cached) / parseInt(data.result.timeseries[i].bandwidth.all) * 100;
                        array1[4][i] = Math.round(parseInt(data.result.timeseries[i].bandwidth.all) / 1024 / 1024);
                        array1[5][i] = Math.round(parseInt(data.result.timeseries[i].bandwidth.cached) / 1024 / 1024);
                        array2[0][i] = Math.round(parseInt(data.result.timeseries[i].bandwidth.content_type.hasOwnProperty("css") ? data.result.timeseries[i].bandwidth.content_type.css : 0) / 1024 / 1024);
                        array2[1][i] = Math.round(parseInt(data.result.timeseries[i].bandwidth.content_type.hasOwnProperty("empty") ? data.result.timeseries[i].bandwidth.content_type.empty : 0) / 1024 / 1024);
                        array2[2][i] = Math.round(parseInt(data.result.timeseries[i].bandwidth.content_type.hasOwnProperty("gif") ? data.result.timeseries[i].bandwidth.content_type.gif : 0) / 1024 / 1024);
                        array2[3][i] = Math.round(parseInt(data.result.timeseries[i].bandwidth.content_type.hasOwnProperty("html") ? data.result.timeseries[i].bandwidth.content_type.html : 0) / 1024 / 1024);
                        array2[4][i] = Math.round(parseInt(data.result.timeseries[i].bandwidth.content_type.hasOwnProperty("javascript") ? data.result.timeseries[i].bandwidth.content_type.javascript : 0) / 1024 / 1024);
                        array2[5][i] = Math.round(parseInt(data.result.timeseries[i].bandwidth.content_type.hasOwnProperty("jpeg") ? data.result.timeseries[i].bandwidth.content_type.jpeg : 0) / 1024 / 1024);
                        array2[6][i] = Math.round(parseInt(data.result.timeseries[i].bandwidth.content_type.hasOwnProperty("json") ? data.result.timeseries[i].bandwidth.content_type.json : 0) / 1024 / 1024);
                        array2[7][i] = Math.round(parseInt(data.result.timeseries[i].bandwidth.content_type.hasOwnProperty("octetStream") ? data.result.timeseries[i].bandwidth.content_type.octetStream : 0) / 1024 / 1024);
                        array2[8][i] = Math.round(parseInt(data.result.timeseries[i].bandwidth.content_type.hasOwnProperty("other") ? data.result.timeseries[i].bandwidth.content_type.other : 0) / 1024 / 1024);
                        array2[9][i] = Math.round(parseInt(data.result.timeseries[i].bandwidth.content_type.hasOwnProperty("plain") ? data.result.timeseries[i].bandwidth.content_type.plain : 0) / 1024 / 1024);
                        array2[10][i] = Math.round(parseInt(data.result.timeseries[i].bandwidth.content_type.hasOwnProperty("png") ? data.result.timeseries[i].bandwidth.content_type.png : 0) / 1024 / 1024);
                        array2[11][i] = Math.round(parseInt(data.result.timeseries[i].bandwidth.content_type.hasOwnProperty("svg") ? data.result.timeseries[i].bandwidth.content_type.svg : 0) / 1024 / 1024);
                        array2[12][i] = Math.round(parseInt(data.result.timeseries[i].bandwidth.content_type.hasOwnProperty("xml") ? data.result.timeseries[i].bandwidth.content_type.xml : 0) / 1024 / 1024);
                        array3[0][i] = data.result.timeseries[i].requests.ssl_protocol["TLSv1.2"];
                        array3[1][i] = data.result.timeseries[i].requests.ssl_protocol["TLSv1.3"];
                        array3[2][i] = data.result.timeseries[i].requests.ssl_protocol.none;
                        array4[0][i] = data.result.timeseries[i].pageviews.search_engine.hasOwnProperty("baiduspider") ? data.result.timeseries[i].pageviews.search_engine.baiduspider : 0;
                        array4[1][i] = data.result.timeseries[i].pageviews.search_engine.hasOwnProperty("bingbot") ? data.result.timeseries[i].pageviews.search_engine.bingbot : 0;
                        array4[2][i] = data.result.timeseries[i].pageviews.search_engine.hasOwnProperty("googlebot") ? data.result.timeseries[i].pageviews.search_engine.googlebot : 0;
                        array4[3][i] = data.result.timeseries[i].pageviews.search_engine.hasOwnProperty("yandexbot") ? data.result.timeseries[i].pageviews.search_engine.yandexbot : 0;
                    }
                    var ctx = document.getElementById("basic").getContext("2d");
                    var lineCharData = new Chart(ctx,{type:"line",data:{labels:[array1[0][0],array1[0][1],array1[0][2],array1[0][3],array1[0][4],array1[0][5],array1[0][6]],datasets:[{label:"Unique Visitors / 10",backgroundColor:["rgba(255, 99, 132, 0.2)","rgba(255, 99, 132, 0.2)","rgba(255, 99, 132, 0.2)","rgba(255, 99, 132, 0.2)","rgba(255, 99, 132, 0.2)","rgba(255, 99, 132, 0.2)","rgba(255, 99, 132, 0.2)"],borderColor:["rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)"],data:[array1[1][0],array1[1][1],array1[1][2],array1[1][3],array1[1][4],array1[1][5],array1[1][6]]},{label:"Total Requests / 100",backgroundColor:["rgba(54, 162, 235, 0.2)","rgba(54, 162, 235, 0.2)","rgba(54, 162, 235, 0.2)","rgba(54, 162, 235, 0.2)","rgba(54, 162, 235, 0.2)","rgba(54, 162, 235, 0.2)","rgba(54, 162, 235, 0.2)"],borderColor:["rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)"],data:[array1[2][0],array1[2][1],array1[2][2],array1[2][3],array1[2][4],array1[2][5],array1[2][6]]},{label:"Percent Cached(%)",backgroundColor:["rgba(255, 206, 86, 0.2)","rgba(255, 206, 86, 0.2)","rgba(255, 206, 86, 0.2)","rgba(255, 206, 86, 0.2)","rgba(255, 206, 86, 0.2)","rgba(255, 206, 86, 0.2)","rgba(255, 206, 86, 0.2)"],borderColor:["rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)"],data:[array1[3][0],array1[3][1],array1[3][2],array1[3][3],array1[3][4],array1[3][5],array1[3][6]]},{label:"Total Data Served(MB)",backgroundColor:["rgba(153, 102, 255, 0.2)","rgba(153, 102, 255, 0.2)","rgba(153, 102, 255, 0.2)","rgba(153, 102, 255, 0.2)","rgba(153, 102, 255, 0.2)","rgba(153, 102, 255, 0.2)","rgba(153, 102, 255, 0.2)"],borderColor:["rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)"],data:[array1[4][0],array1[4][1],array1[4][2],array1[4][3],array1[4][4],array1[4][5],array1[4][6]]},{label:"Data Cached(MB)",backgroundColor:["rgba(255, 159, 64, 0.2)","rgba(255, 159, 64, 0.2)","rgba(255, 159, 64, 0.2)","rgba(255, 159, 64, 0.2)","rgba(255, 159, 64, 0.2)","rgba(255, 159, 64, 0.2)","rgba(255, 159, 64, 0.2)"],borderColor:["rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)"],data:[array1[5][0],array1[5][1],array1[5][2],array1[5][3],array1[5][4],array1[5][5],array1[5][6]]}]}});
                    var ctx2 = document.getElementById("type").getContext("2d");
                    var barChartData = new Chart(ctx2,{type:"bar",data:{labels:[array1[0][0],array1[0][1],array1[0][2],array1[0][3],array1[0][4],array1[0][5],array1[0][6]],datasets:[{label:"css",backgroundColor:["rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)"],borderColor:["rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)","rgba(255, 99, 132, 1)"],data:[array2[0][0],array2[0][1],array2[0][2],array2[0][3],array2[0][4],array2[0][5],array2[0][6]]},{label:"empty",backgroundColor:["rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)"],borderColor:["rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)","rgba(54, 162, 235, 1)"],data:[array2[1][0],array2[1][1],array2[1][2],array2[1][3],array2[1][4],array2[1][5],array2[1][6]]},{label:"gif",backgroundColor:["rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)"],borderColor:["rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)","rgba(255, 206, 86, 1)"],data:[array2[2][0],array2[2][1],array2[2][2],array2[2][3],array2[2][4],array2[2][5],array2[2][6]]},{label:"html",backgroundColor:["rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)"],borderColor:["rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)","rgba(153, 102, 255, 1)"],data:[array2[3][0],array2[3][1],array2[3][2],array2[3][3],array2[3][4],array2[3][5],array2[3][6]]},{label:"js",backgroundColor:["rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)"],borderColor:["rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)"],data:[array2[4][0],array2[4][1],array2[4][2],array2[4][3],array2[4][4],array2[4][5],array2[4][6]]},{label:"jpeg",backgroundColor:["rgba(25, 159, 64, 1)","rgba(25, 159, 64, 1)","rgba(25, 159, 64, 1)","rgba(25, 159, 64, 1)","rgba(25, 159, 64, 1)","rgba(25, 159, 64, 1)","rgba(25, 159, 64, 1)"],borderColor:["rgba(25, 159, 64, 1)","rgba(25, 159, 64, 1)","rgba(25, 159, 64, 1)","rgba(25, 159, 64, 1)","rgba(25, 159, 64, 1)","rgba(25, 159, 64, 1)","rgba(25, 159, 64, 1)"],data:[array2[5][0],array2[5][1],array2[5][2],array2[5][3],array2[5][4],array2[5][5],array2[5][6]]},{label:"json",backgroundColor:["rgba(25, 15, 64, 1)","rgba(25, 15, 64, 1)","rgba(25, 15, 64, 1)","rgba(25, 15, 64, 1)","rgba(25, 15, 64, 1)","rgba(25, 15, 64, 1)","rgba(25, 15, 64, 1)"],borderColor:["rgba(25, 15, 64, 1)","rgba(25, 15, 64, 1)","rgba(25, 15, 64, 1)","rgba(25, 15, 64, 1)","rgba(25, 15, 64, 1)","rgba(25, 15, 64, 1)","rgba(25, 15, 64, 1)"],data:[array2[6][0],array2[6][1],array2[6][2],array2[6][3],array2[6][4],array2[6][5],array2[6][6]]},{label:"octetStream",backgroundColor:["rgba(255, 10, 64, 1)","rgba(255, 10, 64, 1)","rgba(255, 10, 64, 1)","rgba(255, 10, 64, 1)","rgba(255, 10, 64, 1)","rgba(255, 10, 64, 1)","rgba(255, 10, 64, 1)"],borderColor:["rgba(255, 10, 64, 1)","rgba(255, 10, 64, 1)","rgba(255, 10, 64, 1)","rgba(255, 10, 64, 1)","rgba(255, 10, 64, 1)","rgba(255, 10, 64, 1)","rgba(255, 10, 64, 1)"],data:[array2[7][0],array2[7][1],array2[7][2],array2[7][3],array2[7][4],array2[7][5],array2[7][6]]},{label:"other",backgroundColor:["rgba(55, 10, 64, 1)","rgba(55, 10, 64, 1)","rgba(55, 10, 64, 1)","rgba(55, 10, 64, 1)","rgba(55, 10, 64, 1)","rgba(55, 10, 64, 1)","rgba(55, 10, 64, 1)"],borderColor:["rgba(55, 10, 64, 1)","rgba(55, 10, 64, 1)","rgba(55, 10, 64, 1)","rgba(55, 10, 64, 1)","rgba(55, 10, 64, 1)","rgba(55, 10, 64, 1)","rgba(55, 10, 64, 1)"],data:[array2[8][0],array2[8][1],array2[8][2],array2[8][3],array2[8][4],array2[8][5],array2[8][6]]},{label:"plain",backgroundColor:["rgba(55, 100, 64, 1)","rgba(55, 100, 64, 1)","rgba(55, 100, 64, 1)","rgba(55, 100, 64, 1)","rgba(55, 100, 64, 1)","rgba(55, 100, 64, 1)","rgba(55, 100, 64, 1)"],borderColor:["rgba(55, 100, 64, 1)","rgba(55, 100, 64, 1)","rgba(55, 100, 64, 1)","rgba(55, 100, 64, 1)","rgba(55, 100, 64, 1)","rgba(55, 100, 64, 1)","rgba(55, 100, 64, 1)"],data:[array2[9][0],array2[9][1],array2[9][2],array2[9][3],array2[9][4],array2[9][5],array2[9][6]]},{label:"png",backgroundColor:["rgba(64, 100, 10, 1)","rgba(64, 100, 10, 1)","rgba(64, 100, 10, 1)","rgba(64, 100, 10, 1)","rgba(64, 100, 10, 1)","rgba(64, 100, 10, 1)","rgba(64, 100, 10, 1)"],borderColor:["rgba(64, 100, 10, 1)","rgba(64, 100, 10, 1)","rgba(64, 100, 10, 1)","rgba(64, 100, 10, 1)","rgba(64, 100, 10, 1)","rgba(64, 100, 10, 1)","rgba(64, 100, 10, 1)"],data:[array2[10][0],array2[10][1],array2[10][2],array2[10][3],array2[10][4],array2[10][5],array2[10][6]]},{label:"svg",backgroundColor:["rgba(240, 12, 10, 1)","rgba(240, 12, 10, 1)","rgba(240, 12, 10, 1)","rgba(240, 12, 10, 1)","rgba(240, 12, 10, 1)","rgba(240, 12, 10, 1)","rgba(240, 12, 10, 1)"],borderColor:["rgba(240, 12, 10, 1)","rgba(240, 12, 10, 1)","rgba(240, 12, 10, 1)","rgba(240, 12, 10, 1)","rgba(240, 12, 10, 1)","rgba(240, 12, 10, 1)","rgba(240, 12, 10, 1)"],data:[array2[11][0],array2[11][1],array2[11][2],array2[11][3],array2[11][4],array2[11][5],array2[11][6]]},{label:"xml",backgroundColor:["rgba(24, 12, 100, 1)","rgba(24, 12, 100, 1)","rgba(24, 12, 100, 1)","rgba(24, 12, 100, 1)","rgba(24, 12, 100, 1)","rgba(24, 12, 100, 1)","rgba(24, 12, 100, 1)"],borderColor:["rgba(24, 12, 100, 1)","rgba(24, 12, 100, 1)","rgba(24, 12, 100, 1)","rgba(24, 12, 100, 1)","rgba(24, 12, 100, 1)","rgba(24, 12, 100, 1)","rgba(24, 12, 100, 1)"],data:[array2[12][0],array2[12][1],array2[12][2],array2[12][3],array2[12][4],array2[12][5],array2[12][6]]}]}});
                    var ctx3 = document.getElementById("ssl").getContext("2d");
                    var pieCharData = new Chart(ctx3,{type:"pie",data:{labels:["TLSv1.2","TLSv1.3","none"],datasets:[{backgroundColor:["rgba(255, 99, 132, 1)","rgba(54, 162, 235, 1)","rgba(255, 206, 86, 1)"],data:[array3[0][6],array3[1][6],array3[2][6]]},{backgroundColor:["rgba(255, 99, 132, 1)","rgba(54, 162, 235, 1)","rgba(255, 206, 86, 1)"],data:[array3[0][5],array3[1][5],array3[2][5]]},{backgroundColor:["rgba(255, 99, 132, 1)","rgba(54, 162, 235, 1)","rgba(255, 206, 86, 1)"],data:[array3[0][4],array3[1][4],array3[2][4]]},{backgroundColor:["rgba(255, 99, 132, 1)","rgba(54, 162, 235, 1)","rgba(255, 206, 86, 1)"],data:[array3[0][3],array3[1][3],array3[2][3]]},{backgroundColor:["rgba(255, 99, 132, 1)","rgba(54, 162, 235, 1)","rgba(255, 206, 86, 1)"],data:[array3[0][2],array3[1][2],array3[2][2]]},{backgroundColor:["rgba(255, 99, 132, 1)","rgba(54, 162, 235, 1)","rgba(255, 206, 86, 1)"],data:[array3[0][1],array3[1][1],array3[2][1]]},{backgroundColor:["rgba(255, 99, 132, 1)","rgba(54, 162, 235, 1)","rgba(255, 206, 86, 1)"],data:[array3[0][0],array3[1][0],array3[2][0]]}]}});
                    var ctx4 = document.getElementById("search_engine").getContext("2d");
                    var pieCharData2 = new Chart(ctx4,{type:"doughnut",data:{labels:["Baidu","Bing","Google","Yandex"],datasets:[{backgroundColor:["rgba(255, 99, 132, 1)","rgba(54, 162, 235, 1)","rgba(255, 206, 86, 1)","rgba(153, 102, 255, 0.2)"],data:[array4[0][6],array4[1][6],array4[2][6],array4[3][6]]},{backgroundColor:["rgba(255, 99, 132, 1)","rgba(54, 162, 235, 1)","rgba(255, 206, 86, 1)","rgba(153, 102, 255, 0.2)"],data:[array4[0][5],array4[1][5],array4[2][5],array4[3][5]]},{backgroundColor:["rgba(255, 99, 132, 1)","rgba(54, 162, 235, 1)","rgba(255, 206, 86, 1)","rgba(153, 102, 255, 0.2)"],data:[array4[0][4],array4[1][4],array4[2][4],array4[3][4]]},{backgroundColor:["rgba(255, 99, 132, 1)","rgba(54, 162, 235, 1)","rgba(255, 206, 86, 1)","rgba(153, 102, 255, 0.2)"],data:[array4[0][3],array4[1][3],array4[2][3],array4[3][3]]},{backgroundColor:["rgba(255, 99, 132, 1)","rgba(54, 162, 235, 1)","rgba(255, 206, 86, 1)","rgba(153, 102, 255, 0.2)"],data:[array4[0][2],array4[1][2],array4[2][2],array4[3][2]]},{backgroundColor:["rgba(255, 99, 132, 1)","rgba(54, 162, 235, 1)","rgba(255, 206, 86, 1)","rgba(153, 102, 255, 0.2)"],data:[array4[0][1],array4[1][1],array4[2][1],array4[3][1]]},{backgroundColor:["rgba(255, 99, 132, 1)","rgba(54, 162, 235, 1)","rgba(255, 206, 86, 1)","rgba(153, 102, 255, 0.2)"],data:[array4[0][0],array4[1][0],array4[2][0],array4[3][0]]},]}});
                }
            </script>
        </div>';
    }
}
?>
