<?php
/**
 * 开启支持后台在线上传插件
 *
 * @package PluginUpload
 * @author 术与道
 * @version 1.0.0
 * @link http://www.shuyudao.top
 * */

class PluginUpload_Plugin implements Typecho_Plugin_Interface{


    public static function activate()
    {

        Helper::addAction("upload_pl",'PluginUpload_Action');

        Typecho_Plugin::factory('admin/menu.php')->navBar = array('PluginUpload_Plugin', 'run');


        return _t('启动成功');

    }


    public static function deactivate()
    {
        Helper::removeAction("upload_pl");
        Helper::removeRoute("upload_pl");
    }


    public static function config(Typecho_Widget_Helper_Form $form)
    {
        // TODO: Implement config() method.
    }


    public static function personalConfig(Typecho_Widget_Helper_Form $form)
    {
        // TODO: Implement personalConfig() method.
    }

    public static function run(){
        echo "<div id='upload' style='width: 100px;height: 34px;line-height: 34px;text-align: center;position: absolute;top: 60px;right: 200px;background-color: #467B96;color: #fff;'>上传插件(ZIP)<input type='file' style='position: absolute;top: 0px;opacity: 0;left: 0px;width: 100%;height: 34px;cursor: pointer;'></div>
            <script>
               if (window.location.href.indexOf('plugins.php')<0){
                   document.getElementById('upload').style.display = 'none';
                   
               } else{
                   var file = document.getElementById('upload').getElementsByTagName('input')[0];
                   file.onchange = function() {
                      var formData = new FormData();
                      formData.append('file',$('input')[0].files[0]);
                      if(($('input')[0].files[0].name).indexOf('.zip')<0){
                          alert('请上传ZIP压缩文件');
                          return false;
                      }
                      document.getElementById('upload').innerHTML='上传中...';
                      $.ajax({
                        url:'../index.php/action/upload_pl', /*接口域名地址*/
                        type:'post',
                        data: formData,
                        contentType: false,
                        processData: false,
                        success:function(res){
                            location.reload();
                        }
                    })
                   } 
               }
               
               
            </script>
        ";
    }
}