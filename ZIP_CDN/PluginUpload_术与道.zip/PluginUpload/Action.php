<?php
/**
 * Created by PhpStorm.
 * User: Sad
 * Date: 2019/8/31
 * Time: 11:35
 */

class PluginUpload_Action extends Typecho_Widget implements Widget_Interface_Do{

    private $db;

    public function action()
    {
        $this->db = Typecho_Db::get();
        $cookieUid = Typecho_Cookie::get('__typecho_uid');
        if (NULL !== $cookieUid) {
            /** 验证登陆 */
            $user = $this->db->fetchRow($this->db->select()->from('table.users')
                ->where('uid = ?', intval($cookieUid))
                ->limit(1));

            $cookieAuthCode = Typecho_Cookie::get('__typecho_authCode');
            if ($user && Typecho_Common::hashValidate($user['authCode'], $cookieAuthCode)) {
                $this->_user = $user;
                if (($this->_hasLogin = true)&&$user['group']=="administrator"){
                    $file = $_FILES['file'];
                    $name = $file['name'];
                    $path = getcwd().'/usr/plugins/';
                    $filepath= $path.$name;
                    move_uploaded_file($file['tmp_name'],$filepath);
                    $zip = new ZipArchive();
                    if ($zip->open($filepath) === true) {
                        $zip->extractTo($path);
                        $zip->close();
                        unlink($filepath);
                        echo 1;
                    } else {
                        echo 'error';
                    }
                }else{
                    echo "非法";
                }
            }

        }else{
            echo "非法";
        }



    }
}

