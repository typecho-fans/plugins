# ExternalTool
 A typecho plugin for marking external link
