# 这个有点难搞。。。

# Typecho的微博头条文章发布插件

引用 easy-http---->[easy-http](https://github.com/duoshuo/easy-http)


插件版本：1.0.6
# 更新记录：

>1.0.6
语法解析支持！

>1.0.5
修复一个严重bug

>1.0.4
似乎真正修复了500错误

>1.0.3.001
测试版本尝试修复500错误

>1.0.3         
发现easy-http,移植WP方案

>1.0.1-1.0.2   
修复bug

>1.0.0        
正式版初步采用微博官方方案进行发布

>1.0 test:    
测试版本 



[详细介绍](https://www.jysafe.cn/3226.air)
