# typecho-plugin-aphorisms
Typecho 名言警句插件
