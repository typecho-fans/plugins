# typecho-kiana
博客可以挂起来个萌萌哒萝莉

文章地址：https://qqdie.com/archives/typecho-gancia-widgets.html

食用方法：将压缩包解压到typecho的插件目录，将文件夹重命名为kiana，然后后台启用该插件即可，看首页是不是出现了萌萌哒的小萝莉。
如果没有出现，请在设置里打开加载选项。

该插件来自http://853.bronya.net/kiana-guajian


