TypExport
=========

Typecho导出WXR插件

WXR全称为WordPress eXtended Rss，是wordpress导出数据的一种格式，它包含了您的全部文章、页面、评论、自定义字段、分类目录和标签。

#### 简介

测试平台：typecho 1.0 & wordpress 4.0/4.1

#### 如何使用

点击右侧的`Download ZIP`按钮，下载完成之后解压得到类似`TypExport-master`文件夹，将文件夹重命名为`TypExport`,上传到Typecho目录`usr/plugins`,然后在后台启用插件。

在后台界面，`控制台`菜单下会有一个`数据导出`菜单，点击进入导出界面，只有一个按钮，我相信你肯定会使用的。

#### 更新纪录

##### 2015-01-06

* 修正typecho 0.9 markdown类报错的问题
* typecho 1.0 文章内容可能不是markdown格式的处理

#### 问题反馈

在[这里](https://github.com/panxianhai/TypExport/issues)提出使用中的问题，我会在时间允许的第一时间进行处理。

另外，欢迎fork & star。

#### LICENSE

[MIT LICENSE](https://github.com/panxianhai/TypExport/blob/master/LICENSE)

