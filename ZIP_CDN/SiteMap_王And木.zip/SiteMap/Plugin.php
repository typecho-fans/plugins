<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * 生成一个xml文件
 * 
 * @package SiteMap 
 * @author 王And木
 * @version 1.0.0
 * @link http://www.iwonmo.com
 */
class SiteMap_Plugin implements Typecho_Plugin_Interface  // 预定义类
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
	 
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate() 
    {
		
		 Helper::addAction('SiteMap', 'SiteMap_Action');
         Helper::addPanel(1, 'SiteMap/panel.php', _t('SiteMap'), _t('SiteMap'), 'administrator');
         return _t('插件已经激活');
    }
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){
	        Helper::removeAction('SiteMap');
        Helper::removePanel(1, 'SiteMap/panel.php');
	
	
	
	}  // 预定义接口
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form){
        $path = new Typecho_Widget_Helper_Form_Element_Text(
            'path', NULL, 'http://www.iwonmo.com/archives/[iwonmo].html',
            _t('你的网址路径其中[iwonmo]为文章ID'),
            _t('输入一个文章路径，以便生成一个质量更好的SiteMap.xml')
        );
        $form->addInput($path->addRule('required', _t('SiteMap OK')));
    }
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}  // 预定义接口
    
    /**
     * 插件实现方法
     * 
     * @access public
     * @return void
     */
}
