<?php
include_once 'common.php';
include 'header.php';
include 'menu.php';
?>
<div class="main">
    <div class="body container">
        <div class="typecho-page-title">
            <h2><?php _e('SiteMap View')?></h2>
	 
        </div>
        <div class="row typecho-page-main" role="form">
            <div id="SiteMap-plugin" class="col-mb-12 col-tb-8 col-tb-offset-2">
				<!-- -->
			
				
				 <div id="tab-sitemapaction" class="tab-content">
					<form action="<?php $options->index('/action/SiteMap?sitemapaction'); ?>" method="post" enctype="application/x-www-form-urlencoded">
                   <ul class="typecho-option" id="typecho-option-item-formats-2">
                            <li>
                                <label class="typecho-label"><?php _e('XML Format'); ?></label>
                                <span>
                                    <input name="formats" type="radio" value="0" id="formats-0" checked="true">
                                    <label for="formats-0"><?php _e('百度'); ?></label>
                                </span>
                                <span>
                                    <input name="formats" type="radio" value="1" id="formats-1">
                                    <label for="formats-1"><?php _e('谷歌'); ?></label>
                                </span>
                                <p class="description"></p>
                            </li>
                        </ul>
						
                        <ul class="typecho-option typecho-option-submit" id="typecho-option-item-submit-0">
                            <li>
                                <button type="submit" class="btn primary"><?php _e('Update XML'); ?></button>
                            </li>
                        </ul>
                    </form>
                </div>

				
				
                
                </div>
            </div>
    </div>
</div>

<?php
include 'copyright.php';
include 'common-js.php';
include 'table-js.php';
include 'footer.php';
?>