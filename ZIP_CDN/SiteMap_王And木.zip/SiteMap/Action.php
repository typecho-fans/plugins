<?php

class SiteMap_Action extends Typecho_Widget implements Widget_Interface_Do
{
    /**
     * 编辑XML文件
     *
     * @access public
     * @return void
     */
    public function SiteMapEdit()
    { if (0 == $this->request->get('formats')) {
                       $db = Typecho_Db::get();
					$select = $db->select()->from('table.contents')
						->where('type = ?', 'post')
						->where('table.contents.status = ?', 'publish')
						->where('table.contents.created < ?', time())
						->order('table.contents.created', Typecho_Db::SORT_DESC);
					$posts = $db->fetchAll($select);
					$exportConfig = Typecho_Widget::widget('Widget_Options')->plugin('SiteMap');
					$urltext=$exportConfig->path;
					$SiteMapStr='<?xml version="1.0" encoding="UTF-8" ?> 
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" 
xmlns:mobile="http://www.baidu.com/schemas/sitemap-mobile/1/">';	
					
					file_put_contents('SiteMap.xml', print_r($SiteMapStr, true));
					foreach ($posts as $color){
					$UrlR=str_replace("[iwonmo]", $color['cid'], $urltext);
					$TimeStr=date("Y-m-d", $color['created']);
					/*遍历所有的文章*/
$SiteMapStr = '
<url>
<loc>'.$UrlR.'</loc>
<mobile:mobile type="pc,mobile"/>
<lastmod>'.$TimeStr.'</lastmod>
<changefreq>daily</changefreq>
<priority>0.8</priority>
</url>
'
;
					
				file_put_contents('SiteMap.xml', print_r($SiteMapStr, true), FILE_APPEND);
					/*遍历结束*/
 
					}
						file_put_contents('SiteMap.xml', print_r('</urlset>', true), FILE_APPEND);
					
					
					$this->widget('Widget_Notice')->set(_t('更新完毕'), 'success');
					
					
					
                    } else {
                        $this->widget('Widget_Notice')->set(_t('暂未开发'), 'success');
                    }
					
					$this->response->goBack(); // 返回到插件页面
    }
    /**
     * 绑定动作
     *
     * @access public
     * @return void
     */
    public function action()
    {
        $this->widget('Widget_User')->pass('administrator');
        $this->on($this->request->is('sitemapaction'))->SiteMapEdit();
    }
}
?>