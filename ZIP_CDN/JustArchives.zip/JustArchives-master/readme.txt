##说明

搬运自https://plugins.typecho.me/plugins/just-archives.html

=== JustArchives ===

== Installation ==
1.创建一个页面
2.在页面内容中写入 <justarchives>
