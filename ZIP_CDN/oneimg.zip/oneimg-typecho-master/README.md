# oneimg-typecho
oneimg typecho傻瓜式插件
为页面添加可变的背景
示例 
https://www.haotown.cn
