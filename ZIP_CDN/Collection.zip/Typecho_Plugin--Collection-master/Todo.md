# Todo

## Typecho插件部分
+ Plugin
	- 增加按账号多级分级
+ Action
	- editStatus函数配合JS搜索
+ Panel
	- rate修改方式变更
	- 搜索JS实现
	- 豆瓣书籍系列链接表示
	- 类别显示修改修正
	- stylesheet合并
+ template
	- 进行状态图片右上角表示
	- 条目类型另外标识
	- PS默认Cover
	- 吐槽增加缩进或边框

## 移动端
