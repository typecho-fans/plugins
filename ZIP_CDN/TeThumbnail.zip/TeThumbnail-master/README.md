# TeThumbnail
Typecho 缩略图插件

使用方法
--------

 1. 启用插件
 2. 设置缩略图模式

调用代码：

    TeThumbnail_Plugin：：show($this,$size,$link,$pattern);

 - size 缩略图大小 200x140|full
 - link 是否返回链接
 - pattern 输出的缩略图模版

