<?php

class Text_Wiki_Render_Plain_Newline extends Text_Wiki_Render {
    
    
    function token($options)
    {
        return "\n";
    }
}

?>