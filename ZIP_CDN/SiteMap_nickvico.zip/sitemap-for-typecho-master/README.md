# Sitemap For Typecho

鉴于 Typecho 没有此类的 网站地图 插件（当然很可能是我没找到），所以自己动手写了一个，新手一枚，如本插件有任何问题请根据源代码自行修改或与我联系。

# 使用方法

将本插件文件夹改名为 `Sitemap` 后放置在 `usr\plugins` 目录下，最后在后台启用即可，然后访问 http://www.yourblog.com/sitemap.html 即可看到效果！

# License

Open sourced under the MIT license.
