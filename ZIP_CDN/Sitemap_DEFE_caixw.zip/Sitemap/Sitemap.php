<?php
/**
 * Silk Framework
 *
 * @caetgory    Silk
 * @package     Silk
 * @author      caixw <http://www.caixw.com>
 * @copyright   Copyright (C) 2010, http://www.caixw.com
 * @license     NewBSD License
 */

/**
 * 用于产生sitemap.xml文件。
 */
final class Silk_SitemapFile implements Countable
{
	private $_domain;
	private $_filename;
    private $_xml;
    private $_count = 0;

    /**
     * 构造函数。
     *
     * @param string $domain 保存的路径。
     * @param string $filename XML文件名。
     * @param string $xsl
     */
    public function __construct($domain, $filename, $xsl = '')
    {
		$string = '<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="'.$xsl.'"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
</urlset>';
        $this->_xml = simplexml_load_string($string);
		$this->_domain = $domain;
		$this->_filename = $filename;       
    }

    /**
     * 添加一条记录。
     *
     * @param string $loc URL。
     * @param string $changefreq 可选值为：always,hourly,daily,weekly,monthly,yearly,never。
     * @param string $priority 优先级别：0.1-1.0之间的值。
     * @param int $lastmod 最后更新时间的时间戳。
     * @return void
     */
    public function add($loc, $changefreq, $priority, $lastmod)
    {
        $url = $this->_xml->addChild('url');
        $url->addChild('loc', $loc);
        $url->addChild('lastmod', date(DATE_W3C, $lastmod));
        $url->addChild('changefreq', $changefreq);
        $url->addChild('priority', $priority);       
        $this->_count++;
    }

    /**
     * 保存此文件。
     *
     * @return void
     */
    public function save()
    {
        //file_put_contents('saestor://sitemap.xml',$this->_xml->asXML());
        $s = new SaeStorage();
        $s->write ($this->_domain, $this->_filename, $this->_xml->asXML());
        $this->_count = 0;
    }

    /**
     * 此文件的记录数目。
     *
     * @return int
     */
    public function count()
    {
        return $this->_count;
    }
}


/**
 * 产生一系列sitemap的索引文件。
 *
 * @category    Silk
 * @package     Silk
 */
final class Silk_Sitemap
{   
	private $_domain; //sitemap文件存放的domain
    private $_baseurl; // sitemap文件的URL路径。
    private $_maxCount; // 每个sitemap文件的最大记录个数。
    private $_createIndexFile = false;
    private $_xsl;

    private $_sitemap = null; // 当前的Silk_SitemapFile实例
    private $_indexSitemap; // sitemap_index文件的实例。
    private $_index = 0; // 统计sitemap的文件数。

    /**
     * 构造函数。
     *
     * @param string $domain sitemap文件存放的目录。
     * @param string $baseurl sitemap文件所在目录的URL路径。
     * @param boolean $createIndexFile 是否创建索引。
     * @param string $maxCount 每个sitemap文件的最大记录数目。
     * @param string $xsl sitemap文件的XSL文件的位置。
     */
    public function __construct($domain, $baseurl, $createIndexFile = false, $maxCount = 1000, $xsl = '')
    {
        $this->_domain = $domain;
        $this->_baseurl = trim($baseurl, '/') . '/';  // 保证以／结尾。
        $this->_maxCount = $maxCount;
        $this->_createIndexFile = $createIndexFile;
        $this->_xsl = $xsl;

        if($this->_createIndexFile)
        {	
			$string = '<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
</sitemapindex>';
			$this->_indexSitemap = simplexml_load_string($string);			
        }
    }

    /**
     * 保存内容。
     *
     * 每个sitemap文件会自动保存，此操作只是保存sitemap_index文件。
     *
     * @return void
     */
    public function save()
    {
        $this->_sitemap->save();

        if($this->_createIndexFile)
        {
            $s = new SaeStorage();
			$s->write ($this->_domain, 'sitemap.xml', $this->_indexSitemap->asXML());
        }
    }

    /**
     * 添加一条记录。
     *
     * @sa {@link Silk_SitemapFile::add()}
     */
    public function add($loc, $changefreq, $priority, $lastmod)
    {
        if(null === $this->_sitemap)
        {   $this->_initSitemap();  }
        elseif(count($this->_sitemap) >= $this->_maxCount && $this->_createIndexFile)
        {
            $this->_sitemap->save();
            $this->_initSitemap();
        }

        $this->_sitemap->add($loc, $changefreq, $priority, $lastmod);
    }

    /**
     * 创建一个新的sitemapfile实例，并更新索引文件的内容。
     *
     * @return void
     */
    protected function _initSitemap()
    {
        if($this->_createIndexFile)
        {
            $filename = 'sitemap_' . ++$this->_index . '.xml';
            $this->_sitemap = new Silk_SitemapFile($this->_domain, $filename, $this->_xsl);

			$sitemap = $this->_indexSitemap->addChild('sitemap');
			$sitemap->addChild('loc', $this->_baseurl . $filename);
			$sitemap->addChild('lastmod', date(DATE_W3C));		
        }else
        {
            $this->_sitemap = new Silk_SitemapFile($this->_domain, 'sitemap.xml', $this->_xsl);
        }
    }
}

