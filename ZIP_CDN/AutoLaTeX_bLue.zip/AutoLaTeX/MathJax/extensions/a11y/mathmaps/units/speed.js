[
{"category": "",
 "mappings": {
   "default": {
     "default": "knot"
     }
   },
 "key": "kt",
 "names": ["kt", "kt."]
},
{"category": "",
 "mappings": {
   "default": {
     "default": "miles per hour"
     }
   },
 "key": "mph",
 "names": ["mph"]
},
{"category": "",
 "mappings": {
   "default": {
     "default": "revolutions per minute"
     }
   },
 "key": "rpm",
 "names": ["rpm"]
},
{"category": "",
 "mappings": {
   "default": {
     "default": "kilometers per hour"
     }
   },
 "key": "kmh",
 "names": ["kmh"]
}
]
