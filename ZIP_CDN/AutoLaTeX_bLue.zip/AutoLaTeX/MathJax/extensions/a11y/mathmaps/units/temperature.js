[
{"category": "",
 "mappings": {
   "default": {
     "default": "Fahrenheit"
     }
   },
 "key": "F",
 "names": ["F", "F.", "\u00B0F"]
},
  {"category": "",
 "mappings": {
   "default": {
     "default": "Celsius",
     "alternative": "Centigrade"
     }
   },
 "key": "C",
 "names": ["C", "\u00B0C"]
},
  {"category": "",
 "mappings": {
   "default": {
     "default": "Kelvin"
     }
   },
 "key": "K",
 "names": ["K", "\u00B0K"]
}
  
]
