[
  {"category": "",
  "mappings": {
    "default": {
      "default": "dozen"
    }
  },
  "key": "doz",
  "names": ["doz", "doz."]
 },
 {"category": "",
  "mappings": {
    "default": {
      "default": "square"
    }
  },
  "key": "sq",
  "names": ["sq", "sq."]
 },
 {"category": "",
  "mappings": {
    "default": {
      "default": "hectare"
    }
  },
  "key": "ha",
  "names": ["ha"]
 }
]
