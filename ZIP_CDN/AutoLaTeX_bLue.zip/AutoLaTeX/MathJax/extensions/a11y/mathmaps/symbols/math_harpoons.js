[
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "leftwards harpoon with barb upwards",
        "short": "left harpoon with barb up"
      }
    },
    "key": "21BC"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "leftwards harpoon with barb downwards",
        "short": "left harpoon with barb down"
      }
    },
    "key": "21BD"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "upwards harpoon with barb rightwards",
        "short": "up harpoon with barb right"
      }
    },
    "key": "21BE"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "upwards harpoon with barb leftwards",
        "short": "up harpoon with barb left"
      }
    },
    "key": "21BF"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "rightwards harpoon with barb upwards",
        "short": "right harpoon with barb up"
      }
    },
    "key": "21C0"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "rightwards harpoon with barb downwards",
        "short": "right harpoon with barb down"
      }
    },
    "key": "21C1"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "downwards harpoon with barb rightwards",
        "short": "down harpoon with barb right"
      }
    },
    "key": "21C2"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "downwards harpoon with barb leftwards",
        "short": "down harpoon with barb left"
      }
    },
    "key": "21C3"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "leftwards harpoon over rightwards harpoon",
        "short": "left harpoon over right harpoon"
      }
    },
    "key": "21CB"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "rightwards harpoon over leftwards harpoon",
        "short": "right harpoon over left harpoon"
      }
    },
    "key": "21CC"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "left barb up right barb down harpoon"
      }
    },
    "key": "294A"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "left barb down right barb up harpoon"
      }
    },
    "key": "294B"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "up barb right down barb left harpoon"
      }
    },
    "key": "294C"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "up barb left down barb right harpoon"
      }
    },
    "key": "294D"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "left barb up right barb up harpoon"
      }
    },
    "key": "294E"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "up barb right down barb right harpoon"
      }
    },
    "key": "294F"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "left barb down right barb down harpoon"
      }
    },
    "key": "2950"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "up barb left down barb left harpoon"
      }
    },
    "key": "2951"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "leftwards harpoon with barb up to bar",
        "short": "left harpoon with barb up to bar"
      }
    },
    "key": "2952"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "rightwards harpoon with barb up to bar",
        "short": "right harpoon with barb up to bar"
      }
    },
    "key": "2953"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "upwards harpoon with barb right to bar",
        "short": "up harpoon with barb right to bar"
      }
    },
    "key": "2954"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "downwards harpoon with barb right to bar",
        "short": "down harpoon with barb right to bar"
      }
    },
    "key": "2955"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "leftwards harpoon with barb down to bar",
        "short": "left harpoon with barb down to bar"
      }
    },
    "key": "2956"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "rightwards harpoon with barb down to bar",
        "short": "right harpoon with barb down to bar"
      }
    },
    "key": "2957"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "upwards harpoon with barb left to bar",
        "short": "up harpoon with barb left to bar"
      }
    },
    "key": "2958"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "downwards harpoon with barb left to bar",
        "short": "down harpoon with barb left to bar"
      }
    },
    "key": "2959"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "leftwards harpoon with barb up from bar",
        "short": "left harpoon with barb up from bar"
      }
    },
    "key": "295A"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "rightwards harpoon with barb up from bar",
        "short": "right harpoon with barb up from bar"
      }
    },
    "key": "295B"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "upwards harpoon with barb right from bar",
        "short": "up harpoon with barb right from bar"
      }
    },
    "key": "295C"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "downwards harpoon with barb right from bar",
        "short": "down harpoon with barb right from bar"
      }
    },
    "key": "295D"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "leftwards harpoon with barb down from bar",
        "short": "left harpoon with barb down from bar"
      }
    },
    "key": "295E"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "rightwards harpoon with barb down from bar",
        "short": "right harpoon with barb down from bar"
      }
    },
    "key": "295F"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "upwards harpoon with barb left from bar",
        "short": "up harpoon with barb left from bar"
      }
    },
    "key": "2960"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "downwards harpoon with barb left from bar",
        "short": "down harpoon with barb left from bar"
      }
    },
    "key": "2961"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "leftwards harpoon with barb up above leftwards harpoon with barb down",
        "short": "left harpoon with barb up above left harpoon with barb down"
      }
    },
    "key": "2962"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "upwards harpoon with barb left beside upwards harpoon with barb right",
        "short": "up harpoon with barb left beside up harpoon with barb right"
      }
    },
    "key": "2963"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "rightwards harpoon with barb up above rightwards harpoon with barb down",
        "short": "right harpoon with barb up above right harpoon with barb down"
      }
    },
    "key": "2964"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "downwards harpoon with barb left beside downwards harpoon with barb right",
        "short": "down harpoon with barb left beside down harpoon with barb right"
      }
    },
    "key": "2965"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "leftwards harpoon with barb up above rightwards harpoon with barb up",
        "short": "left harpoon with barb up above right harpoon with barb up"
      }
    },
    "key": "2966"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "leftwards harpoon with barb down above rightwards harpoon with barb down",
        "short": "left harpoon with barb down above right harpoon with barb down"
      }
    },
    "key": "2967"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "rightwards harpoon with barb up above leftwards harpoon with barb up",
        "short": "right harpoon with barb up above left harpoon with barb up"
      }
    },
    "key": "2968"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "rightwards harpoon with barb down above leftwards harpoon with barb down",
        "short": "right harpoon with barb down above left harpoon with barb down"
      }
    },
    "key": "2969"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "leftwards harpoon with barb up above long dash",
        "short": "left harpoon with barb up above long dash"
      }
    },
    "key": "296A"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "leftwards harpoon with barb down below long dash",
        "short": "left harpoon with barb down below long dash"
      }
    },
    "key": "296B"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "rightwards harpoon with barb up above long dash",
        "short": "right harpoon with barb up above long dash"
      }
    },
    "key": "296C"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "rightwards harpoon with barb down below long dash",
        "short": "right harpoon with barb down below long dash"
      }
    },
    "key": "296D"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "upwards harpoon with barb left beside downwards harpoon with barb right",
        "short": "up harpoon with barb left beside down harpoon with barb right"
      }
    },
    "key": "296E"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "downwards harpoon with barb left beside upwards harpoon with barb right",
        "short": "down harpoon with barb left beside up harpoon with barb right"
      }
    },
    "key": "296F"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "left fish tail"
      }
    },
    "key": "297C"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "right fish tail"
      }
    },
    "key": "297D"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "up fish tail"
      }
    },
    "key": "297E"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "down fish tail"
      }
    },
    "key": "297F"
  }
]