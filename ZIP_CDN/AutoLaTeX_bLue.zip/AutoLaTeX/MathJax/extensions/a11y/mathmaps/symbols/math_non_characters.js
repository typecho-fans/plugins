[
  {
    "category": "Ll",
    "mappings": {
      "default": {
        "default": "mathematical italic small h over two time greek letter pi",
        "alternative": "italic small h over two pi",
        "short": "italic h over two pi"
      },
      "physics": {
        "default": "planck constant over two pi",
        "alternative": "planck constant over 2 pi"
      }
    },
    "key": "210F"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "l b bar symbol",
        "short": "l b bar"
      }
    },
    "key": "2114"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "numero sign",
        "alternative": "numero",
        "short": "numero"
      }
    },
    "key": "2116"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "sound recording copyright"
      }
    },
    "key": "2117"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "prescription take"
      }
    },
    "key": "211E"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "response"
      }
    },
    "key": "211F"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "service mark"
      }
    },
    "key": "2120"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "telephone sign",
        "alternative": "t e l symbol"
      }
    },
    "key": "2121"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "trade mark sign",
        "alternative": "trademark",
        "short": "trade mark"
      }
    },
    "key": "2122"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "versicle"
      }
    },
    "key": "2123"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "ounce sign",
        "alternative": "ounce",
        "short": "ounce"
      }
    },
    "key": "2125"
  },
  {
    "category": "Lu",
    "mappings": {
      "default": {
        "default": "ohm sign",
        "alternative": "ohm",
        "short": "ohm"
      }
    },
    "key": "2126"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "inverted ohm sign",
        "alternative": "mho",
        "short": "inverted ohm"
      }
    },
    "key": "2127"
  },
  {
    "category": "Lu",
    "mappings": {
      "default": {
        "default": "kelvin sign",
        "alternative": "degrees kelvin",
        "short": "kelvin"
      }
    },
    "key": "212A"
  },
  {
    "category": "Lu",
    "mappings": {
      "default": {
        "default": "angstrom sign",
        "alternative": "angstrom unit",
        "short": "angstrom"
      }
    },
    "key": "212B"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "estimated symbol",
        "short": "estimated"
      }
    },
    "key": "212E"
  },
  {
    "category": "Lu",
    "mappings": {
      "default": {
        "default": "turned capital f",
        "alternative": "turned f",
        "short": "turned cap f"
      },
      "mathspeak": {
        "default": "turned upper F"
      }
    },
    "key": "2132"
  },
  {
    "category": "Ll",
    "mappings": {
      "default": {
        "default": "information source"
      }
    },
    "key": "2139"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "rotated capital q",
        "short": "rotated cap q"
      },
      "mathspeak": {
        "default": "rotated upper Q"
      }
    },
    "key": "213A"
  },
  {
    "category": "So",
    "mappings": {
      "default": {
        "default": "facsimile sign"
      }
    },
    "key": "213B"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "turned sans serif capital g",
        "short": "turned sans serif cap g"
      },
      "mathspeak": {
        "default": "turned sans serif upper G"
      }
    },
    "key": "2141"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "turned sans serif capital l",
        "short": "turned sans serif cap l"
      },
      "mathspeak": {
        "default": "turned sans serif upper L"
      }
    },
    "key": "2142"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "reversed sans serif capital l",
        "short": "reversed sans serif cap l"
      },
      "mathspeak": {
        "default": "reversed sans serif upper L"
      }
    },
    "key": "2143"
  },
  {
    "category": "Sm",
    "mappings": {
      "default": {
        "default": "turned sans serif capital y",
        "short": "turned sans serif cap y"
      },
      "mathspeak": {
        "default": "turned sans serif upper Y"
      }
    },
    "key": "2144"
  }
]
