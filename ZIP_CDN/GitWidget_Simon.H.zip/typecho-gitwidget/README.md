# typecho-gitwidget

很简单的插件，用来在Typecho文章中显示Git项目小挂件，目前支持Gitee码云、Github

Github使用的是[JoelSutherland/GitHub-jQuery-Repo-Widget](https://github.com/JoelSutherland/GitHub-jQuery-Repo-Widget)

码云使用的是官方挂件。

使用方法，直接在文章中，添加`gitwidget`短代码
```
[gitwidget type='gitee' url='SimonH/typecho-gitwidget']
[gitwidget type='github' url='JoelSutherland/GitHub-jQuery-Repo-Widget']
```
相关CSS样式可以在插件配置里修改。效果可参照 [demo](http://ywy.me/archives/typecho-plugin-gitwidget.html)
