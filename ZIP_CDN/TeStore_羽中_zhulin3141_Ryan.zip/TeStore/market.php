<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$response->redirect(Typecho_Common::url(__TYPECHO_ADMIN_DIR__.'te-store/market',$options->index));
