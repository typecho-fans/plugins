### 新GitHub表格解析版插件仓库TeStore v1.1.7

以免服务端思路复活这款插件，通过读取GitHub上的专用表格实现插件仓库的搜索、下载和安装删除等功能。

- v1.1.7(26-8-25)：

1. 将镜像配置拆分为jsDelivr兼容CDN和URL前缀代理，支持内置节点及自定义HTTPS地址；

2. CDN支持cdn.jsdelivr.net、gcore.jsdelivr.net、cdn.jsdmirror.cn和cdn.jsdmirror.com，URL前缀代理支持gh-proxy.org、cdn.gh-proxy.org和box.w0x7ce.eu/proxy；

3. 信息源和插件下载统一检查HTTP状态及内容，镜像无效时自动回退原地址，插件压缩包通过完整性校验后才会安装；

4. 自动兼容旧版jsDelivr、渺软镜像和GitHub Proxy配置，其中已失效的jsd.onmicrosoft.cn迁移至cdn.jsdmirror.cn。

- v1.1.5(20-6-14)：

1. 修正直接读取GitHub源无法正确解析列表的bug，作者信息全取html代码以兼容各种文档写法；

2. 获取本地插件meta信息时过滤html标签增强准确性，列表页搜索功能现已支持按作者名称筛选。

- v1.1.4(20-6-10)：

1. 列表页面顶部增加点击标签，已安装插件可分页显示，列表附注图标更新为更清晰的SVG格式；

2. 操作按钮样式和反馈提示效果沿用系统风格，提交方式由ajax改为同步post，移除原sticky效果；

3. 安装过程增加目录检测和升级清理，移除pclzip使用PHP原生解压缩方法，data改为常规目录等。

- v1.1.3(20-6-7)：

1. 修正冗余代码增强可读性，修复非管理员用户可查看列表bug，修复同名插件只安装第一个bug；

2. 支持jsDelivr/GitCDN镜像替换raw文件地址加速，表格或zip包链接为raw文件地址时自动加速；

3. API检测ZIP_CDN目录，同步按期限缓存，镜像开启时优先下载ZIP_CDN内的raw文件加速地址。

- v1.1.2(18-8-20)：

新增curl下载方式(支持pem证书识别)，修正http源的主页链接问题，改善DOM编码的兼容性表现。

- v1.1.1(18-8-7)：

修正PHP7兼容、DOM编码和多作者链接解析问题，优化父文件夹识别、ajax报错及缺省筛选效果。

- v1.1.0(18-8-5)：（[@羽中](https://github.com/jzwalk)）

1. 使用PHP DOM解析Github社区目录下的md表格做默认源，更新缓存功能逻辑，减少读写操作；

2. 安装实现文件递归扫描和智能文件夹路径判断，更换zip库，优化ajax交互效果，增加action校验；

3. 列表加载异步化，字母排序已安装自动提前，支持分页和按简介筛选，支持图标及版本升级提醒。

- v1.0.0(14-11-13)：（[@zhulin3141](https://github.com/zhulin3141)）

正则匹配读取新浪云服务端页面，ajax方式实现下载、安装及卸载功能，列表支持缓存和名称筛选。

###### 更多详见作者博客：http://www.yzmb.me/archives/net/testore-for-typecho
###### 或可查看论坛原帖：http://forum.typecho.org/viewtopic.php?f=6&t=11097
