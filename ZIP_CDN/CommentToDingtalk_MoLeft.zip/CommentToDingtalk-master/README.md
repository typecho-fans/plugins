# CommentToDingtalk
typecho插件，可以将评论推送到钉钉

# 实测截图
![](http://www.moleft.cn/usr/uploads/2020/03/2524905473.jpg)

# 安装教程
从Github克隆重命名为CommentToDingtalk，丢到plugins目录，启用之后配置好钉钉就ok了

# 钉钉配置
教程： [点我进入](http://www.moleft.cn/post-15.html)
