<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;

class XEditor_Helper_CustomLabel extends Typecho_Widget_Helper_Layout
{
    public function __construct($html)
    {
        $this->html($html);
        $this->start();
        $this->end();
    }

    public function start()
    {
    }

    public function end()
    {
    }
}
