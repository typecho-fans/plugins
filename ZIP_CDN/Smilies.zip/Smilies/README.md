### Typecho图片表情插件Smilies
2018年6月30日更新至**v1.1.3**: 
- 增加自定义扩展表情组
- 异步扫描优化中文支持
- 正文表情改编辑器按钮
- 可关闭标准组表情输出
- 可设置评论弹窗css样式
- 可分情景设置表情尺寸
- 更换默认表情支持svg
- 配发7套混合版表情包

#### 详细说明与效果演示见blog发布地址: 
 > http://www.yzmb.me/archives/net/smilies-for-typecho