<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * Created by PhpStorm.
 * User: nura
 * Date: 2018-10-30
 * Time: 17:29
 */
class Bilibili_Action extends Typecho_Widget implements Widget_Interface_Do
{
    public function execute()
    {
    }

    public function action()
    {
        $this->on($this->request->is('do=cover'))->cover();
        $this->on($this->request->is('do=url'))->url();
    }

    private function cover()
    {
        $this->filterReferer();
        $id = $this->request->get('id');
        $cover = $this->request->get('url');
        if (preg_match('/^http/', $cover)) {
            $filename = './bilibili/cover_' . $id;
            if (!file_exists($filename)) {
                $m = get_headers($cover, true);
                if (strpos($m[0], '200')) {
                    header('Content-type: ' . $m['Content-Type']);
                    $img = file_get_contents($cover);
                    file_put_contents($filename, $img);
                    echo $img;
                } else {
                    header($m[0]);
                    exit();
                }
            } else {
                header('Content-type: ' . mime_content_type($filename));
                echo file_get_contents($filename);
            }
        }

    }

    private function url()
    {

        $url = $this->request->get('url');
        if (preg_match('/^http/', $url)) {
            $t = $this->request->get('t', 5);
            echo '<h2>您正在离开本站</h2>';
            echo '<p>' . $t . '秒后将跳转至[<a href="' . $url . '">' . $url . '</a>]</p>';
            header('Refresh:' . $t . ';Url=' . $url);
            exit();
        }
    }

    private function query($url)
    {
        $data = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'Content-Type: application/json; charset=UTF-8',
                'content' => json_encode(array(
                    'shortUrl' => $url
                ))
            )
        );
        return json_decode(file_get_contents('https://dwz.cn/admin/query', false, stream_context_create($data)))->LongUrl;
    }

    private function filterReferer()
    {
        $ref = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
        if (isset($_SERVER['HTTP_REFERER']) && !in_array($ref, array('yukimax.org', 'shosei.tk', 'shose-app.smartgslb.com'))) {
            http_response_code(403);
            die('[]');
        }
    }
}