<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * <p>视频转换<strong>直接写入视频播放页URL即可</strong>,目前支持哔哩哔哩、AcFun(待定)</p>
 * @package 哔哩哔哩转换器
 * @author 绀野木棉季
 * @version 1.4.0 beta
 * @link https://yukimax.org/
 *
 * Created by PhpStorm.
 * Author: 凉宫长门
 * Created at: 2017/12/29 13:31
 * Description: 哔哩哔哩视频url自动转换成可视化界面
 */
class Bilibili_Plugin extends Typecho_Widget implements Typecho_Plugin_Interface
{
    public static function activate()
    {
        Helper::addAction('blapi', 'Bilibili_Action');
        /** 前端输出处理接口 */
        Typecho_Plugin::factory('Widget_Abstract_Contents')->excerptEx = array('Bilibili_Plugin', 'render');
        Typecho_Plugin::factory('Widget_Abstract_Contents')->contentEx = array('Bilibili_Plugin', 'render');
    }

    public static function deactivate()
    {
        Helper::removeAction('blapi');
    }

    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $mode = new Typecho_Widget_Helper_Form_Element_Radio('mode', array(
            '0' => _t('流畅(360P)'),
            '1' => _t('高清(1080P)')
        ), '0', _t('哔哩哔哩视频清晰度'), _t('默认为流畅'));
        $form->addInput($mode);

        $rewrite = new Typecho_Widget_Helper_Form_Element_Radio('rewrite', array(
            '0' => _t('关闭重写url'),
            '1' => _t('开启重写url')
        ), '0', _t('图片与来源 链接重写开关'), _t('默认关闭'));
        $form->addInput($rewrite);

        $api = new Typecho_Widget_Helper_Form_Element_Text(
            'api',
            null,
            Typecho_Common::url('action/blapi', Helper::options()->index),
            _t('* 未开启重写时使用'),
            _t('示例：https://shosei.tk/bl/api?cover=:cover')
        );
        $form->addInput($api);
    }

    public static function personalConfig(Typecho_Widget_Helper_Form $form)
    {
    }

    public static function getInfo($url, $id)
    {
        $dir = './bilibili';
        $file = $dir . '/' . $id;
        is_dir($dir) || mkdir($dir, 0755, true);
        if (isset($_GET['del']) && $_GET['del'] == 'tmp') {
            file_exists($file) && unlink($file);
            echo '清除缓存成功!';
        }
        if (!file_exists($file)) {
            $context = stream_context_create(array(
                'http' => array(
                    'method' => 'GET',
                    'header' => 'Host: www.bilibili.com' . "\r\n" . 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36' . "\r\n"
                )
            ));
            $html = file_get_contents('compress.zlib://' . $url, false, $context);
            if (strpos($url, 'bangumi/play') !== false) {
                preg_match('/mediaInfo"\:\{"id"\:\d+\,"ssId":(?<ss_id>\d+)\,"title"\:"(?<title>.*?)"\,.*?\,"evaluate"\:"(?<desc>.*?)"\,"ssType"\:\d\,"ssTypeFormat"/', $html, $matches1);
                preg_match('/"epInfo"\:\{"loaded"\:.*?\,"id"\:(?<ep_id>\d+)\,"badge"\:".*?"\,"badgeType"\:\d\,"epStatus"\:\d+\,"aid"\:(?<aid>\d+)\,"cid"\:(?<cid>\d+)\,"from"\:".*?"\,"cover"\:"(?<cover>.*?)"\,"title"\:".*?"\,"titleFormat"\:".*?"\,"vid"\:""\,"longTitle"\:""\,"hasNext"\:.*?\,"i"\:\d\,"sectionType"\:\d\,"releaseDate"\:""\}/', $html, $matches2);
                $matches = array_merge($matches1, $matches2);
                $arr = array(
                    'aid' => $matches['aid'],
                    'cid' => $matches['cid'],
                    'ss_id' => $matches['ss_id'],
                    'ep_id' => $matches['ep_id'],
                    'title' => self::unidecode($matches['title']),
                    'cover' => self::cover(self::unidecode($matches['cover'])),
                    'desc' => self::unidecode($matches['desc'])
                );
            } elseif (strpos($url, 'video/av') !== false) {
                preg_match('/"videoData"\:\{"bvid"\:".*?"\,"aid"\:(?<aid>[0-9]{0,})\,"videos"\:[0-9]{0,}\,"tid"\:[0-9]{0,}\,"tname"\:".*?"\,"copyright"\:[0-9]{0,}\,"pic"\:"(?<cover>http.*?)"\,"title"\:"(?<title>.*?)"\,.*?"desc"\:"(?<desc>.*?)"\,.*?"pages"\:\[\{"cid"\:(?<cid>[0-9]{0,})\,"page"\:(?<page>[0-9]{0,})\,"from".*?/', $html, $matches);
                $arr = array(
                    'aid' => $matches['aid'],
                    'cid' => $matches['cid'],
                    'title' => self::unidecode($matches['title']),
                    'cover' => self::unidecode($matches['cover']),
                    'page' => $matches['page'],
                    'desc' => self::unidecode($matches['desc'])
                );
            }
            $arr['url'] = $url;
            is_numeric($arr['aid']) && file_put_contents($file, serialize($arr));
            $out = $arr;
        } else {
            $out = unserialize(file_get_contents($file));
        }

        return $out;
    }

    public static function render($text, $widget, $lastResult)
    {
        $text = empty($lastResult) ? $text : $lastResult;
        if ($widget instanceof Widget_Archive) {
            $text = preg_replace_callback('/<(p)><(a) href="(?<url>https\:\/\/www\.bilibili\.com\/(bangumi\/play|video)\/(?<id>(ep|av|ss)[0-9]{0,})(|\/\?p=[0-9]{0,}|\/))">\\3<\/\\2><\/\\1>/is', function ($matchs) {
                $id = $matchs['id'];
                $url = $matchs['url'];
                $info = self::getInfo($url, $id);

                $mode = Typecho_Widget::widget('Widget_Options')->plugin('Bilibili')->mode;
                $rewrite = Typecho_Widget::widget('Widget_Options')->plugin('Bilibili')->rewrite;
                $api = Typecho_Widget::widget('Widget_Options')->plugin('Bilibili')->api;

                $cover = ($rewrite == 1 ? $api . '?do=cover&id=' . $id . '&url=' : '') . $info['cover'];
                $source = ($rewrite == 1 ? $api . '?do=url&id=' . $id . '&url=' : '') . $info['url'];
                $mode = $mode == 1 ? 1 : 3;

                return "<p><img src=\"{$cover}\"></p><hr><iframe style=\"height:calc(9*100vw/16);width:100%\" src=\"//player.bilibili.com/player.html?aid={$info['aid']}&cid={$info['cid']}&high_quality={$mode}\" scrolling=\"no\" border=\"0\" frameborder=\"no\" framespacing=\"0\" allowfullscreen=\"true\"></iframe>" . (isset($info['desc']) ? '<p class="desc">简介: ' . $info['desc'] . '</p>' : '') . "<p><label>来源:</label><a href=\"{$source}\" target=\"_blank\">{$url}</a></p>";
            }, $text);

        }

        return $text;
    }

    private static function unidecode($str)
    {
        $json = '{"str":"' . str_replace('\\n', '<br/>', $str) . '"}';
        $arr = json_decode($json, true);
        if (empty($arr)) {
            return '';
        }
        return $arr['str'];
    }

    private static function cover($url)
    {

        return substr($url, 0, 2) == '//' ? $_SERVER['REQUEST_SCHEME'] . ':' . $url : $url;
    }
}