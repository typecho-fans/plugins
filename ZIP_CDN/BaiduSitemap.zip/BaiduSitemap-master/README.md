# BaiduSitemap

这是一款基于Typecho博客平台的百度站点地图插件，该插件将文章、分类、页面等信息以XML和HTML的形式展示给搜索引擎蜘蛛，有利于搜索引擎优化（SEO）。

注册的路由地址为`sitemap_baidu.xml`与`sitemap.html`，可在`Plugin.php`文件中修改。

站点地图效果如下：  
<http://www.milkcu.com/blog/sitemap_baidu.xml>  
<http://www.milkcu.com/blog/sitemap.html>

-EOF-
