# MoeTop 
这是一款typecho插件，一款萌萌哒的返回顶部插件。

## 食用方法 
* 点击右上角绿色的`Clone or download`按钮，`Download ZIP`, 解压文件。
* 重命名文件夹为`MoeTop`
* 将`MoeTop`文件夹上传至typecho的插件`usr/plugins`目录
* 登录后台启用`MoeTop`插件即可正确食用

## 配置说明
* 选择自己喜欢的图片模型即可。
* 支持随机模式，开启后每次刷新页面将会从插件的models文件夹中随机加载一张图片模型。

## 更新
### 1.1.0
- 添加是否在移动端显示选项。

## 效果
预览效果: [Sanakeyの小站](https://keymoe.com)

## 声明
本插件使用到的所有图片来自互联网，版权归原作者所有。


