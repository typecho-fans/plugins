<?php if(!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div class="container typecho-page-title">
    <div class="column-24">
        <h2><a href="<?php echo Helper::url('Spider%2Fpanel.php'); ?>">采集管理</a></h2>
        <p><a href="<?php $options->siteUrl(); ?>"><?php _e('查看我的站点'); ?></a></p>
    </div>
</div>