# Bomb-Typecho-Plugin
简单的 Typecho 输入爆炸特效插件，全站有效

## 安装方法
下载，解压，将文件夹重命名为 `Bomb`  
上传到 `/usr/plugins` 目录下，在后台启用即可

## 使用
启用后即刻生效

## 来源
偶尔浏览到 Atom 一个[插件](https://github.com/disjukr/activate-power-mode)，觉得挺好玩就随手封装成一个 Typecho 插件