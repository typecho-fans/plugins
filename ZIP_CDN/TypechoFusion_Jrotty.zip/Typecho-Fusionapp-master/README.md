# Typecho-Fusionapp
为Fusion app定制专属的typecho皮肤

# 使用方法
1，将TypechoFusion文件夹传到typecho插件目录下，然后打开网站后台启用插件

2，安卓手机端打开fusion app自定义ua处填写包含"fusion"字符的ua信息

3，然后就可以用fusion app定制自己的博客客户端啦！虽然并没有什么意义233

4，皮肤接口：在网址后面加入"?theme=皮肤名字"，就会加载style文件夹下的css样式文件，比如加入"?theme=night"就会引入默认的夜间模式皮肤（加载style下的night.css）

# 功能说明

1，文章无限滚动加载

2，缩略图功能，显示文章首图，没图的话会随机显示内置的二次元图片（500张）

3，模板简洁，无css框架

4，支持原生评论

5，加载了jq，方便fusion app使用js调试

6，评论头像使用gravatar.loli.net源，且对于qq邮箱用户显示qq头像

# 成品demo

https://www.lanzous.com/i2x37te

