<?php
/**
 * 列表页只显示摘要
 * 
 * @package DigestShow
 * @author WiFeng
 * @version 1.1.0
 * @link http://521-wf.com
 */
class DigestShow_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Abstract_Contents')->contentEx = array(__CLASS__, 'render');
    }
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){}
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form){
		$height = new Typecho_Widget_Helper_Form_Element_Text('height', NULL, '400', _t('摘要显示最大高度'));
        $form->addInput($height);
	}
    
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    
    /**
     * 插件实现方法
     * 
     * @access public
     * @return void
     */
    public static function render($content, $thisObj, $lastResult){
		$content = empty($lastResult) ? $content : $lastResult; //修复继承其他插件
		$typelist = array(
			'index',
			'index_page',
			'category',
			'category_page',
			'tag',
			'tag_page',
			'search',
			'search_page'
		);

		if(in_array($thisObj->parameter->type, $typelist)) {
			$pluginname = substr(__CLASS__, 0, strrpos(__CLASS__, '_'));
			$height = Typecho_Widget::widget('Widget_Options')->plugin($pluginname)->height;
			$height = intval($height);
			return '<div style="max-height:'.$height.'px;overflow:hidden;">'.$content.'</div>';
		}
		return $content;
	}
}
