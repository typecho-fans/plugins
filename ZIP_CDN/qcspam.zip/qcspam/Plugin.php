<?php

/**
 * 基于TencentCloud文字内容检测的评论过滤器
 * 
 * @package Spam for TencentCloud
 * @author Kuwaku
 * @version 1.0.0
 * @link https://qaqwq.com/
 */

class qcspam_Plugin implements Typecho_Plugin_Interface
{
	/**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {   
    	#此处作者仅做使用统计
    	$domain = $_SERVER['SERVER_NAME'];
    	file_get_contents("https://ai.qaqwq.com/txt/blog_user.php?domain=$domain&status=use");
        Typecho_Plugin::factory('Widget_Feedback')->comment = array('qcspam_Plugin', 'filter');
		return _t('评论过滤器启用成功，请自行进行测试');
    }
     
     /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate()
    {
    	#此处作者仅做使用统计
    	$domain = $_SERVER['SERVER_NAME'];
    	file_get_contents("https://ai.qaqwq.com/txt/blog_user.php?domain=$domain&status=close");
    	return _t('插件禁用成功，不再提供过滤服务，欢迎再次使用');

    }

	/* 个人用户的配置方法 */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
	{
		function tips(){
			echo "<style>.paul-info{text-align:center; margin:1em 0;} .paul-info > *{margin:0 0 1rem} .buttons a{background:#467b96; color:#fff; border-radius:4px; padding:.5em .75em; display:inline-block}</style>";
            echo "<center><h2>评论过滤 - 基于腾讯云</h2></center>";
			echo '<ol>
                      <li>插件基于腾讯云T-Sec 天御 文本内容安全接口进行开发<br>测试期间使用作者提供的接口，后期可能会进行删减，需要自行配置</li>
                      <li>文本内容接口控制台地址为：<a href "https://console.cloud.tencent.com/cms/text">Tencent Cloud</a></li>
                      <li>插件不会验证配置的正确性，请自行确认配置信息正确，否则不能正常使用。<br></li>
                      <li>接口目前限制了每分钟的调用频率，频率过高请联系作者</li>
                      <li>第一次写插件，不太会，请多包涵 <a href="https://qaqwq.com/">Kuwaku博客</a></li>
                    </ol>';
            echo "<center><h2>目前已知bug</h2></center>";
            echo '<ol>
                      <li>评论失败就直接拦截了，不会告诉你评论了什么</li>
                      <li>达到接口频率插件会无效</li>
                    </ol>';
		}
		tips();
        $desc = new Typecho_Widget_Helper_Form_Element_Text('desc', NULL, '', _t('准入密钥：'),
            _t('<p>暂时不用填写，预留位置后期可能会启用</p><p>不用做任何操作，插件已启用，可以自行测试了</p>'));
        $form->addInput($desc);
	}

    /*核心代码*/

     
    public static function filter($comment, $post)
    {
        $options = Typecho_Widget::widget('Widget_Options');
		$filter_set = $options->plugin('qcspam');
		$comm = $comment['text'];
		$res = file_get_contents("https://ai.qaqwq.com/txt/blog.php?text='$comm'");
		$opt = json_decode($res,1);
		$code = $opt["Data"]["EvilType"];
		$keyin = $opt["Data"]["Keywords"];
		//执行操作
        if ($code == '20001' || $code == '20006' || $code == '20007' || $code == '20105' || $code == '24001') {
			Typecho_Cookie::set('__typecho_remember_text', $comment['text']);
            throw new Typecho_Widget_Exception("评论失败，请重新评论。$keyin是非法词，错误码：$code");
		}
		elseif ($code == '20004' || $code == '20001') {
			$comment['status'] = 'waiting';
		}
		Typecho_Cookie::delete('__typecho_remember_text');
        return $comment;
    }
    	
}
    




   	



?>