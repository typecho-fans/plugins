# GithubStatic
1.下载插件

2.文件目录更名GithubStatic

3.启用插件，到github获取token

4.填入插件设置

5.上传图片即可

# 获取日志？
1.插件设置用开启Debug

2.到Github诊断面板开启Debug

3.在新窗口上传图片或执行异常动作

4.到原窗口关闭Debug截图反馈
# 反馈相关
Mail:946735494@qq.com
