# Highlightjs-for-typecho

> 将Highlight文件夹传到typecho插件目录即可完成插件的安装

# 其他说明

> 该插件需要加载JQ，兼容instantclick.js

# 功能说明

> 能让代码高亮，并且有行号

# 使用方法

> 如下面格式

```php
\```php
<?php echo 'hello jrotty!'; ?>
\```

删除上边代码中的\
```
