<?php
if (!defined('__TYPECHO_ROOT_DIR__') && !@include_once '../config.inc.php') {
    file_exists('../install.php') ? header('Location: ../install.php') : print('Missing Config File');
    exit;
}
date_default_timezone_set('Asia/Shanghai');
date_default_timezone_set('PRC');
$db= Typecho_Db::get();
@($pg = $_GET['pg']);
@($day = $_GET['day']);
@($type = $_GET['type']);
@($id = $_GET['id']);
@($pass = $_GET['pass']);
//无法识别的分类
$fenlei = array(
  "F1"	=> "2",
);
class Collect_Action implements Widget_Interface_Do {
    public function execute() {
        //Do nothing
    }

    public function action(){

        
        
    }
}

if ($type == "cron") {
	if($pass!==Typecho_Widget::widget('Widget_Options')->Plugin('Collect')->pass){
		echo "访问密码错误";
		return;
	}
    if ($day == '1') {
        $url = Typecho_Widget::widget('Widget_Options')->Plugin('Collect')->url . "?ac=videolist&h=24&t=" . $id . "&pg=1";
    } elseif ($day == "7") {
        $url = Typecho_Widget::widget('Widget_Options')->Plugin('Collect')->url . "?ac=videolist&h=168&t=" . $id . "&pg=1";
    } elseif ($day == "max") {
        $url = Typecho_Widget::widget('Widget_Options')->Plugin('Collect')->url . "?ac=videolist&h=&t=" . $id . "&pg=1";
    }
    $listcontent = MloocCurl($url);
    $ruleMatchDetailInList = "~<list page=\"[^>]*\" pagecount=\"(.*?)\" pagesize=\"[^>]*\" recordcount=\"[^>]*\">~";
    #正则表达式
    preg_match($ruleMatchDetailInList, $listcontent, $cjinfo);
    $zpg = $cjinfo[1];
    if($zpg>=80){
    	echo '更新数量过大,请使用手动添加模式';
    	exit();
    }
    for ($i = 0; $i < $zpg; $i++) {
    	$tt = $i + 1;
        caiji($tt ,$day, $type, $api, $db, $id, $readcontent, $okzys, $fenlei,$arr,$arr2,$arr3,$idd,$pass);
    }
}
if ($type == "add") {
	if($pass!==Typecho_Widget::widget('Widget_Options')->Plugin('Collect')->pass){
		echo "访问密码错误";
		return;
	}
    caiji($pg,$day, $type, $api, $db, $id, $readcontent, $okzys, $fenlei,$arr,$arr2,$arr3,$idd,$pass);
}

function trimall($str)//删除空格
{
    $oldchar=array(" ","　","\t","\n","\r");
$newchar=array("","","","","");
    return str_replace($oldchar,$newchar,$str);
}
function caiji($pg,$day, $type, $api, $db, $id, $readcontent, $okzys, $fenlei,$arr,$arr2,$arr3,$idd,$pass)
{
    if ($day == '1') {
        $url = Typecho_Widget::widget('Widget_Options')->Plugin('Collect')->url . "?ac=videolist&h=24&t=" . $id . "&pg=" . $pg;
    } elseif ($day == "7") {
        $url = Typecho_Widget::widget('Widget_Options')->Plugin('Collect')->url . "?ac=videolist&h=168&t=" . $id . "&pg=" . $pg;
    } elseif ($day == "max") {
        $url = Typecho_Widget::widget('Widget_Options')->Plugin('Collect')->url . "?ac=videolist&h=&t=" . $id . "&pg=" . $pg;
    }
    
    echo $url.'<br />';
    $listcontent = MloocCurl($url);
    
    $listcontent = str_replace("'","",$listcontent);
    
    $ruleMatchDetailInList = "~<list page=\"[^>]*\" pagecount=\"(.*?)\" pagesize=\"[^>]*\" recordcount=\"(.*?)\">~";
    #正则表达式
    preg_match($ruleMatchDetailInList, $listcontent, $cjinfo);
    
    $listcontent = explode("</video>",$listcontent);
    
    $xunhuan = count($listcontent);
    
    for ($i = 0; $i < $xunhuan; $i++) {
    
    $ruleMatchDetailInList = "~<last>(.*?)</last>~";
    #正则表达式
    preg_match_all($ruleMatchDetailInList, $listcontent[$i], $datex);
    //视频时间
    $ruleMatchDetailInList = "~<tid>(.*?)<\\/tid>~";
    #正则表达式
    preg_match_all($ruleMatchDetailInList, $listcontent[$i], $tid);
    //视频分类id
    $ruleMatchDetailInList = "~<id>(.*?)<\\/id>~";
    #正则表达式
    preg_match_all($ruleMatchDetailInList, $listcontent[$i], $title_id);
    //视频id
    $ruleMatchDetailInList = "~<type>(.*?)<\\/type>~";
    #正则表达式
    preg_match_all($ruleMatchDetailInList, $listcontent[$i], $category);
    $ruleMatchDetailInList = "~<name>\\<\\!\\[CDATA\\[(.*?)\\]\\]\\>\\<\\/name>~";
    #正则表达式
    preg_match_all($ruleMatchDetailInList, $listcontent[$i], $title);
    //视频名称
    $ruleMatchDetailInList = "~<des>\\<\\!\\[CDATA\\[(.*?)\\]\\]\\>\\<\\/des>~";
    #正则表达式
    preg_match_all($ruleMatchDetailInList, $listcontent[$i], $drama);
    //视频介绍
    $ruleMatchDetailInList = "~<pic>(.*?)<\\/pic>~";
    #正则表达式
    preg_match_all($ruleMatchDetailInList, $listcontent[$i], $pic);
    //视频图片
    $ruleMatchDetailInList = "~<area>(.*?)<\\/area>~";
    #正则表达式
    preg_match_all($ruleMatchDetailInList, $listcontent[$i], $area);
    //视频地区分类
    $ruleMatchDetailInList = "~<dd flag=\"[^>]*\">\\<\\!\\[CDATA\\[(.*?)\\]\\]\\>\\<\\/dd>~";
    #正则表达式
    preg_match_all($ruleMatchDetailInList, $listcontent[$i], $m3u8);
    //视频地址
    $ruleMatchDetailInList = "~<note>\\<\\!\\[CDATA\\[(.*?)\\]\\]\\>\\<\\/note>~";
    #正则表达式
    preg_match_all($ruleMatchDetailInList, $listcontent[$i], $note);
    //视频地址
    $ruleMatchDetailInList = "~<year>(.*?)<\\/year>~";
    #年代
    preg_match_all($ruleMatchDetailInList, $listcontent[$i], $year);
    //年代
    //视频地址
    $ruleMatchDetailInList = "~<tag>(.*?)<\\/tag>~";
    #标签
    preg_match_all($ruleMatchDetailInList, $listcontent[$i], $tag);
    //$cjinfo[1]  采集总页数
    //$cjinfo[1]  采集总数量
    
    if ($title[1][0] != "") {
    	
            if (stristr($category[1][0], '福利') == false || stristr($category[1][0], '伦理片') == false || stristr($category[1][0], '视讯美女') == false) {
                $msg = "";
                $dates = strtotime($datex[1][0]);
                $time = strtotime(date('Y-m-d H:i:s'));
                @($dramas = strip_tags($drama[1][0]));
                @$dramas = trimall($dramas);
                $vname = $title[1][0];
                $cjid = $title_id[1][0];
                $query= $db->select('cid')->from('table.contents')->where('slug = ?',$cjid);
                $row = $db->fetchAll($query);
                $accid = $row[0]['cid'];
                $tags = $tag[1][0];
                
                $vodurl = "";
                
                $vodurl = str_replace("#", "\r\n", $m3u8[1][0]);
                
                $msg = '';
                //判断是否完结
                /*
                if (strpos($note[1][$i + 1], '完结') !== false) {
                    $zhuangtai = "0";
                } else {
                    $zhuangtai = "1";
                }
                */
                
                //判断更新时间 小于等于 1209600秒 判断正在更新
                
                if($time - $dates <= 1209600){
                $zhuangtai = '1';
                }else{
                $zhuangtai = '0';
                }
                
                
                $years = substr($year[1][0], 0, 4);
                if ($accid == false) {
                
                
                $query = $db->select('cid')->from('table.contents')->order('cid',Typecho_Db::SORT_DESC)->limit(1);
                $row3 = $db->fetchAll($query);
                if($row3[0]['cid']==false){
                $zcid = '1';
                }else{
                $zcid = ($row3[0]['cid'] + 1);
                }
                
                
                @($insert = "INSERT INTO `typecho_contents` (`cid`, `title`, `slug`, `created`, `modified`, `text`, `order`, `authorId`, `template`, `type`, `status`, `password`, `commentsNum`, `allowComment`, `allowPing`, `allowFeed`, `parent`, `likes`, `views`) VALUES ('{$zcid}', '{$vname}', '{$appid}{$cjid}', '{$time}', '{$time}', '<!--markdown-->{$dramas}', '0', '1', NULL, 'post', 'publish', NULL, '0', '1', '1', '1', '0', '0', '3');");
                
                
                //创建新文章$db->query
                if(@$db->query($insert) == true){
                	    $msg.= $i . '.[' . $title[1][0] . "]创建成功-->";
                	    
                @($sql2 = "INSERT INTO `typecho_fields` (`cid`, `name`, `type`, `str_value`, `int_value`, `float_value`) VALUES ('{$zcid}', 'okdizhi', 'str', '{$cjid}', '0', '0'), ('{$zcid}', 'niandai', 'str', '{$years}', '0', '0'), ('{$zcid}', 'zhuangtai', 'str', '{$zhuangtai}', '0', '0'), ('{$zcid}', 'thumb', 'str', '{$pic[1][0]}', '0', '0'), ('{$zcid}', 'mp4', 'str', '{$vodurl}', '0', '0'), ('{$zcid}', 'duoji', 'str', '', '0', '0'), ('{$zcid}', 'vodupdate', 'str', '{$dates}', '0', '0'), ('{$zcid}', 'fanjubiao', 'str', 't8', '0', '0'), ('{$zcid}', 'zyz', 'str', '{$note[1][0]}', '0', '0');"); //, ('{$zcid}', 'mp4s2', 'str', 't8', '0', '0')
                //添加新文章内容
                }else{
                	$msg.= $i . '.[' . $title[1][0] . "]创建失败--><br />";
                	echo $sql;
                }
               if(@$db->query($sql2) == true){
                	$msg.= "数据库写入成功-->";
                	
               //处理分类
               $fid = Typecho_Widget::widget('Widget_Options')->Plugin('Collect')->wid;
               
               
               $flcon2 = "";
               
               $sqlz = "";
               
               preg_match_all('#('.implode('|', explode(",",Typecho_Widget::widget('Widget_Options')->Plugin('Collect')->gm)).')#', $area[1][0], $guanjianzi);
               $guanjianzi = array_unique($guanjianzi[0]);
               if(count($guanjianzi) >= 1){
               $query= $db->select()->from('table.metas')->where('name = ?', '国漫')->where('type = ?', 'category'); 
               $row = $db->fetchAll($query);
               $fid = $row[0]['mid'];
               }
               
               preg_match_all('#('.implode('|', explode(",",Typecho_Widget::widget('Widget_Options')->Plugin('Collect')->rm)).')#', $area[1][0], $guanjianzi2);
               $guanjianzi2 = array_unique($guanjianzi2[0]);
               if(count($guanjianzi2) >= 1){
               $query= $db->select()->from('table.metas')->where('name = ?', '日漫')->where('type = ?', 'category'); 
               $row = $db->fetchAll($query);
               $fid = $row[0]['mid'];
               }
               
               preg_match_all('#('.implode('|', explode(",",Typecho_Widget::widget('Widget_Options')->Plugin('Collect')->mm)).')#', $area[1][0], $guanjianzi3);
               $guanjianzi3 = array_unique($guanjianzi3[0]);
               if(count($guanjianzi3) >= 1){
               $query= $db->select()->from('table.metas')->where('name = ?', '美漫')->where('type = ?', 'category'); 
               $row = $db->fetchAll($query);
               $fid = $row[0]['mid'];
               }
               

               $flcon2= "UPDATE `typecho_metas` SET `count` = count + 1 WHERE `mid` = '{$fid}';";
               $db->query($flcon2);
               //处理分类
               
               //处理标签
               $sql_name2 = "";
               
               $apis = Typecho_Widget::widget('Widget_Options')->Plugin('Collect')->api;
               
               $tag = isset($apis) ? $apis : '';
               
               $sqlz = "";
               
               if($tag !== ''){
               	$tags = MloocCurl($tag."/api.php?type=label_get&name=".$vname."&apikey=");
               	$json = json_decode($tags);
               	$tags = $json->label;
               }else{
               	$tags = '其他';
               }
               	
               	
               if(strpos($tags,',')==true){
               	$tag_str = explode(',',$tags);
               }else{
               	$tag_str = array($tags);
               }	
               
               $flcon = '';
               
               foreach($tag_str as $value){
               	if($value == ''){
               		continue;
               	}
               	$query2= $db->select()->from('table.metas')->where('name = ?', $value)->where('type = ?', 'tag'); 
                $row = $db->fetchAll($query2);
               	if($row[0]['mid']==''){
                $insert = $db->insert('table.metas')->rows(array('mid' => null, 'name' => $value, 'slug' =>$value, 'type' =>'tag', 'description' =>null, 'count' =>'0','order'=>'0','parent' =>'0'));
               		if($db->query($insert) == true){
               			echo "【已创建标签：{$value}】";
               		}
               	}
               $row = $db->fetchAll($query2);
               $flcon.= "UPDATE `typecho_metas` SET `count` = count + 1 WHERE `mid` = '{$row[0]['mid']}' and `type` = 'tag';";
               $sqlz.="('{$zcid}', '{$row[0]['mid']}'),";
               }
               
               
               $db->query($flcon);
               
               
                @($sql3 = "INSERT INTO `typecho_relationships` (`cid`, `mid`) VALUES {$sqlz} ('{$zcid}', '{$fid}');");
                
                
                }else{
                	$msg.= "数据库写入失败--><br />";
                }
                if(@$db->query($sql3) == true){
                	$msg.= "分类成功！<br />";
                }else{
                	$msg.= "分类失败:{$sql3}<br />";
                }
                echo $msg;
                //分类和设置标签
                }elseif ($accid == true) {
                	
                $name1 = 'vodupdate';	
                	
                @$sql = "UPDATE `typecho_fields` SET `str_value` = '{$dates}' WHERE `name` = 'vodupdate' and `cid` = '{$accid}';";
                @$sql2 = "UPDATE `typecho_fields` SET `str_value` = '{$vodurl}' WHERE `name` = 'mp4' and `cid` = '{$accid}';";
                @$sql3 = "UPDATE `typecho_contents` SET `modified`='{$dates}' WHERE `cid` = '{$accid}';";
                @$sql4 = "UPDATE `typecho_fields` SET `str_value`='{$note[1][0]}' WHERE `cid` = '{$accid}' and `name` = 'zyz';";
                
                $sql24 = $db->query($sql2);
                $sql25 = $db->query($sql3);
                $sql26 = $db->query($sql4);
                if($zhuangtai == '0'){
                $sql4 = $db->update('table.fields')->rows(array('str_value'=>$zhuangtai))->where('name=?','zhuangtai')->where('cid=?',$accid);
                if($db->query($sql4) == true){
                        		$gxx = '[已标记完结]'.$note[1][0];
                }
                }
                        if ($db->query($sql) == true or $sql24  == true or $sql25 ==true  or $sql26 ==true) {

                                echo $i . '.[' . $title[1][0] . "]更新成功！".$gxx."<br />";
                        } else {
                               echo $i . '.[' . $title[1][0] . "]更新失败！<br />".$sql;
                               
                        }
                
                }	
                
                        
                        
                    
                
            }
        }
    }
        $zpg = $cjinfo[1];
        if ($pg < $zpg && $type !== "cron") {
            $pg = $pg + 1;
            $urll = '?pg=' . $pg . '&type=add&day=' . $day . '&pass=' . $pass . '&id=' . $id;
            echo '<hr /><meta http-equiv="refresh" content="3;URL='.$urll.'"><a href="'.$urll.'">3秒后跳转下一页~</a> 剩余：' . ($pg - 1) . '/' . $zpg . '页';
        }
}
function MloocCurl($url){

        $UserAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36';#设置UserAgent

        $curl = curl_init();

        curl_setopt($curl, CURLOPT_URL, $url);

        curl_setopt($curl, CURLOPT_USERAGENT, $UserAgent);

        #关闭SSL

        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);

        #返回数据不直接显示

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

        $response = curl_exec($curl);

        curl_close($curl);

        return $response;

    }