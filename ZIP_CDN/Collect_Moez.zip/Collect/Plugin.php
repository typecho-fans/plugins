<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * Moez动漫采集插件
 * 
 * @package Collect
 * @author Moez
 * @version 1.0.0
 * @link http://www.moez.cc/
 */
 
class Collect_Plugin implements Typecho_Plugin_Interface {

    public static function activate() {
        Helper::addRoute("Collect","/Collect","Collect_Action",'action');
    }

    public static function deactivate() {
        Helper::removeRoute("Collect");
    }


    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        /** 分类名称 */
        $set0 = new Typecho_Widget_Helper_Form_Element_Text('api', NULL, NULL, _t('自动分类标签API'), _t('自动分类标签API'));
        $form->addInput($set0);
        $set1 = new Typecho_Widget_Helper_Form_Element_Text('url', NULL, NULL, _t('采集站URL'), _t('仅支持M3U8'));
        $form->addInput($set1);
        $set2 = new Typecho_Widget_Helper_Form_Element_Text('pass', NULL, NULL, _t('访问密码'), _t('访问密码'));
        $form->addInput($set2);
        $set3 = new Typecho_Widget_Helper_Form_Element_Text('wid', NULL, NULL, _t('无法识别的分类ID'), _t('如果采集的时候 无法识别的分类到ID'));
        $form->addInput($set3);
        $set4 = new Typecho_Widget_Helper_Form_Element_Text('gm', NULL, '中国,大陆,内地,国漫', _t('分类【国漫】的关键字'), _t('分类【国漫】的关键字 建议不用修改，基本关键字都在里面了'));
        $form->addInput($set4);
        $set5 = new Typecho_Widget_Helper_Form_Element_Text('rm', NULL, '日本,日本国,日本岛,番剧,日漫', _t('分类【日漫】的关键字'), _t('分类【日漫】的关键字 建议不用修改，基本关键字都在里面了'));
        $form->addInput($set5);
        $set6 = new Typecho_Widget_Helper_Form_Element_Text('mm', NULL, '美国,欧美,加拿大,法国,英国,德国,俄国,俄罗斯,欧洲', _t('分类【美漫】的关键字'), _t('分类【美漫】的关键字 建议不用修改，基本关键字都在里面了'));
        $form->addInput($set6);
        
        
        $shuoming = new Typecho_Widget_Helper_Form_Element_Checkbox('shuoming', 
    array(), _t('说明'), _t('<section id="custom-field" class="typecho-post-option">
                        <label id="custom-field-expand" class="typecho-label">采集插件说明</label>
   <br /> 本次版本更新：添加后台管理、自动获取标签并分类、自动分类识别、兼容各种采集站、修复采集BUG、添加访问密码<br />
   <br />1.采集站必须使用m3u8接口<br />2.自动识别分类需要创建三个名称是： 国漫、日漫、美漫 的分类才会自动识别<br />3.以下是操作地址：<br />
    先手动添加：<br />
    Url:http://你的地址/Collect/?pg=1&type=add&day=1&id=1&pass=你的密码 (GET)<br />
    参数：<br />
    pg = 页数<br />
    type = 操作类型（add和cron）<br />
    id = 采集站上面的分类ID<br />
    pass = 插件后台设置的密码<br />
    <br />
    下面是监控地址：
    <br />
    http://你的地址/Collect/?pg=1&type=cron&day=1&id=1&pass=你的密码 (GET)
    </p>By：<a href="http://www.moez.cc/" target="_blank">Moez</a>
    </section>'));
    $form->addInput($shuoming->multiMode());
    }
    
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    
    /**
     * 插件实现方法
     * 
     * @access public
     * @return void
     */
    public static function render()
    {
    }
}
