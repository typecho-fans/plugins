**用法**
在文章里面用```<repo></repo>```套住repo名就好
**更新**
使用了新开源库（hustcc/GitHub-Repo-Widget.js），免jquery。



