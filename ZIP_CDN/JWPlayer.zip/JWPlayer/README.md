### Typecho视频播放器插件JWPlayer
2018年7月13日更新至**v1.0.9**: 
- 补充js库修正兼容性bug
- 增加url加解密播放支持
- 切换文件可自定义名称
- 参数解析支持自动置空

#### 详细说明与效果演示见blog发布地址: 
 > http://www.yzmb.me/archives/net/jwplayer-for-typecho