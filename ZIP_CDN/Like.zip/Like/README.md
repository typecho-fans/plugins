### Typecho点赞排行插件Like v1.0.1

启用后在contents表内添加likes字段，可通过`<?php Like_Plugin::theLike(); ?>`输出点赞图标(根据cookie识别重复点击)，`<?php Like_Plugin::theMostLiked(); ?>`输出文章排行。

 > 更新面板说明与文档。

###### 更多详见论坛原帖：http://forum.typecho.org/viewtopic.php?f=6&t=5363