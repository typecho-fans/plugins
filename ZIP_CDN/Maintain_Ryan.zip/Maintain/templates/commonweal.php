<?php
/**
 * 公益
 *
 * @author Ryan
 * @version 1.0.1
 * @link https://doufu.ru
 */
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
?>
<!doctype html>
<head>
<meta charset="<?php $this->options->charset();?>">
</head>
<html class="no-js">
<body>
    <h1>正在执行例行维护，请一分钟后回来</h1>
    <script type="text/javascript" src="//qzonestyle.gtimg.cn/qzone/hybrid/app/404/search_children.js" charset="<?php $this->options->charset();?>" homePageUrl="<?php $this->options->siteUrl();?>" homePageName="<?php $this->options->title();?>"></script>
</body>

</html>
