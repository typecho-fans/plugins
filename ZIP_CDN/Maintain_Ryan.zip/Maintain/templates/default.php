<?php
/**
 * 默认
 *
 * @author Ryan
 * @version 1.0.1
 * @link https://doufu.ru
 */
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
?>
<!doctype html>
<html class="no-js">

<head>
	<meta charset="<?php $this->options->charset();?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="<?php $this->options->themeUrl('style.css');?>">
    <?php $this->header('wlw=&xmlrpc=&rss2=&atom=&rss1=&template=&pingback=&generator');?>
</head>

<body>
	<table id="maintain-box">
        <tr>
            <td>
                <div class="title">维护中</div>
                <div class="text">为了能让您访问更快更稳定，同时为您提供更高品质的服务，我们正在维护系统。因此目前网站的部分功能不能使用，请稍后再回来。给您造成了不便，请谅解。</div>
            </td>
        </tr>
    </div>
    <footer>
        <style>
        html, body {
            height: 100%;
            width: 100%;
            overflow: hidden;
            background:#000;
        }
        #maintain-box {
            max-width: 1000px;
            height: 100%;
            margin: 0 auto;
        }
        #maintain-box, #maintain-box tr, #maintain-box td {
            border: 0 !important;
        }
        #maintain-box tr td {
            text-align: center;
            vertical-align: middle;
        }
        #maintain-box .title {
            font-size: 2em !important;
            color: #fff;
        }
        #maintain-box .text {
            font-size: 1.2em !important;
            color: #fff;
        }
        </style>
    </footer>
    <?php $this->footer();?>
</body>

</html>