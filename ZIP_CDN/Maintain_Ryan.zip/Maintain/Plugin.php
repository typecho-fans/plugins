<?php
/**
 * 全站维护管理插件
 *
 * @package Maintain
 * @author Ryan
 * @version 1.0.1
 * @link https://doufu.ru
 */
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
class Maintain_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     *
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Maintain_Util::activate();
        return _t('插件激活成功，点击<a href="' . Maintain_Util::getConfigUrl() . '">此处</a>进行配置');
    }

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     *
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate()
    {
        Maintain_Util::deactivate();
    }

    /**
     * 获取插件配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        echo "<style>.plugin-register input{display:none;}.theme-switch span{display:inline-block;position: relative;margin-right:0;}.theme-switch span input{position:absolute;z-index: 5;top: 11px;left: 7px;}.t-item {width: 128px;height: 128px;position: relative;display: inline-block;}.t-item img{width:128px;height:auto;}.t-item h3 {position: absolute;bottom: -16px;left: 0;right: 0;text-align: center;background-color: rgba(0,0,0,.2);color: #fff;}</style>";
        // 改这里是没用的
        $registerInfo = Maintain_Util::isRegistered() ? _t('已注册') : _t('免费版(未注册)，<a href="https://xiamp.net/archives/23.html" target="_blank">点击此处购买收费版</a>');
        $edit = new Typecho_Widget_Helper_Form_Element_Text('registered', null, null, _t('版本信息:' . $registerInfo), null);
        $edit->setAttribute('class', 'typecho-option plugin-register');
        $form->addInput($edit);
        $radio = new Typecho_Widget_Helper_Form_Element_Radio('switch', array('1' => _t('开启'), '0' => _t('关闭')), '0', _t('维护开关'), null);
        $form->addInput($radio);
        $radio = new Typecho_Widget_Helper_Form_Element_Radio('theme', Maintain_Util::templates(), 'default.php', _t('模板选择'), null);
        $radio->setAttribute('class', 'typecho-option theme-switch');
        $form->addInput($radio);
    }

    /**
     * 个人用户的配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form)
    {}
}
