# typecho-register
This is a simple regist plugin for typecho. You can install this plugin and offer a register page for others.  when needed, you can close this page ( it can be set in the setting pannel of  the plugin).

# steps
- download the plugin and rename the folder `HankRegister`
- install the plugin, then go to the setting to open the register page(it is closed default).
- when you do the up steps, the register page is : `http:www.***.com/index.php/register.html`.

>  Current version is 0.5. Enjoy it.
