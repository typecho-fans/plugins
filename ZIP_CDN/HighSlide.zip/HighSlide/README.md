### Typecho弹窗相册插件HighSlide
2018年7月16日更新至**v1.4.7**: 
- 使用5.0.0packed双内核
- 附件栏内集成缩略图模式
- 附件缩略图支持归档联动
- 优化相册的修改模式机制
- 支持4家免费云储存及API
- 增加html弹窗编辑器按钮
- 修正MD转义及检测等bug

#### 详细说明与效果演示见blog发布地址: 
 > http://www.yzmb.me/archives/net/highslide-for-typecho