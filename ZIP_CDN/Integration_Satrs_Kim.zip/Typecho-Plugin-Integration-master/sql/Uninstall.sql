DROP TABLE IF EXISTS `typecho_robots_logs`;
DROP TABLE IF EXISTS `typecho_baidusubmit`;