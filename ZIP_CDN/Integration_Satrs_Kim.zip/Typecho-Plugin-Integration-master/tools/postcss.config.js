/* eslint-disable global-require */
module.exports = {
    plugins: [
        // require('cssnano')(),
        require('autoprefixer'),
    ],
}
