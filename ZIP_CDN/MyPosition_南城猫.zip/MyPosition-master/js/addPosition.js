function addPosition(){
    console.log(posx);
    setTimeout(function(){
        addStr("[pos]"+posx+"[/pos]");
    },100);
}
