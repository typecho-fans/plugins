### 一键升级开发版插件Update v0.0.3

在导航条右上方显示升级按钮或在后台提示系统升级时附加开发版链接，可一键执行备份文件到backup子目录、下载实时zip包并解压升级等操作。

:warning:开发版可能存在未知bug，不建议在正式环境中使用。

- v0.0.3(18-7-24)：（[@羽中](https://github.com/jzwalk)）
修正文件递归扫描方式解决升级无效bug和临时目录残留问题，修正开发版检测方式，增加控制栏按钮，修正pclzip.lib兼容PHP7.0。

- 补更至v0.0.2，修正action路径。

###### 更多详见作者博客：https://imnerd.org/Update-plugin-for-typecho.html