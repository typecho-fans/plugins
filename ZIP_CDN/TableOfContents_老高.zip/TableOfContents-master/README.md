# TableOfContents
 A typecho plugin for toc

Auto generate TOC for your post!
为你的文章自动添加文章目录！