# LovelyCat
Typecho 插件

一只可爱的猫，它会跟着你的鼠标移动：

![](LovelyCat/cat.gif)。

#如何在博客中使用？
在typecho中启用此插件即可

祝你玩得开心!
