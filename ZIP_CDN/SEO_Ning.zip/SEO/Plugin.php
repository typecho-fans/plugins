<?php
/**
 * SEO 插件，需要在文章中自定义 description 和 keyword 字段
 * 
 * @package SEO
 * @author Ning
 * @version 0.0.1
 * @link http://printf.cn
 */
class SEO_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->headerOptions = array('SEO_Plugin', 'headerOptions');
    }
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){}
    
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form){

    }

    /**
     * 输出头部关键字
     * @access public
     * @return void
     */
    public static function headerOptions($allows, $archive) {
        if (!empty($archive->fields->keywords)) {
            $allows['keywords'] = $archive->fields->keywords;
        }

        if (!empty($archive->fields->description)) {
            $allows['description'] = $archive->fields->description;
        }
        return $allows;
    }
}
