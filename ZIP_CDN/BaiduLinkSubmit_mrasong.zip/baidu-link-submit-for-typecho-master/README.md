# baidu-link-submit-for-typecho
@ 2015/10/27

Auto submit blog urls to baidu for Typecho


## useage

1. Download put the plugin file `BaiduLinkSubmit.php` to your typecho plugin dir.
2. Active the it in the plugs management panel.
3. Config the site and keys with your own.
4. Enjoy it.


For more information 


PS:

 - [使用主动推送功能会达到怎样效果](http://dwz.cn/265Rcs)
 - [BaiduLinkSubmit for typecho](https://mrasong.com/a/baidu-link-submit-for-typecho)
