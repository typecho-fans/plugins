# GoTop

#【食用方法】
<br>
Download ZIP, 解压
<br>
重命名文件夹为GoTop
<br>
上传至usr/plugins目录
<br>
登录后台启用即可

#【更新日志】
1.0.0  项目完成
<br>
1.1.0  修复打开站点默认下拉的问题
<br>
1.2.0 增加动态效果

#【项目地址】

https://mikuac.com/archives/369/
