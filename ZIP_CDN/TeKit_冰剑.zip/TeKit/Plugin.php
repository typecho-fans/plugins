<?php
/**
 * Typecho日志类、评论类等多功能工具箱！
 * 
 * @package Typecho Kit
 * @author 冰剑
 * @version 2.0.0
 * @link http://www.binjoo.net
 */
class TeKit_Plugin implements Typecho_Plugin_Interface {
    public static function activate() {}
    public static function deactivate(){}
    public static function config(Typecho_Widget_Helper_Form $form){}
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
}
