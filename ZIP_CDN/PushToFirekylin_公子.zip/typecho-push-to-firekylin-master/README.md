# typecho-push-to-firekylin

The plugin can help you push your post to another blog created by [Firekylin](https://firekylin.org) when you publish your post in typecho blog.