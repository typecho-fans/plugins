# typecho百度统计插件
仿照typeGA插件编写的百度统计插件
