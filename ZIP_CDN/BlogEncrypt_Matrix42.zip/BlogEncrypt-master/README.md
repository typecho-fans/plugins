### BlogEncrypt简介

BlogEncrypt是由doudou的一个插件改写来的,感谢doudou!

BlogEncrypt是一个Typecho插件,可以在博客首页显示一个密码框,输入正确的密码才能进入博客

配合项目中的robots.txt可以把博客打造成一个私人的笔记,可以防止第三方笔记不稳定造成的笔记丢失

> robots.txt放到网站的根目录

### BlogEncrypt使用说明

1.下载后将文件夹命名为BlogEncrypt

2.将插件上传到plugins目录

3.到网站管理页面启用插件,设置密码即可

### 存在的问题

我不会响应式编程,所以页面的大小都是固定的,如果有会响应式编程的同学欢迎提交代码

### 欢迎Fork和Star