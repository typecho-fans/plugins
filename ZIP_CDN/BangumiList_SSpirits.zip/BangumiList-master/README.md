# Typecho 追番列表插件

#### 项目介绍
Bangumi 追番列表插件 Typecho 版

使用短代码 `[bangumi]` 在任何位置插入你的 Bangumi 追番列表

插件效果见此处：https://blog.sspirits.top/about.html

#### 使用方法：

  1. 在 [Release](https://github.com/ShadowySpirits/BangumiList/releases) 中下载此插件的最新版，上传至网站的/usr/plugins/目录下；
  2. 启用该插件，正确填写相关信息。
  3. 在你想展示的位置插入短代码 `[bangumi]`
