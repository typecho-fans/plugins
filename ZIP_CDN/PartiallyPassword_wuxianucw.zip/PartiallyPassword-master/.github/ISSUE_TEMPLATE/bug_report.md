---
name: Bug report
about: 上报 Bug
title: ''
labels: bug
assignees: wuxianucw

---

**Bug 描述**
<!--请在这里简要描述 Bug-->

**如何触发**
<!--请在这里详细说明触发 Bug 的方法步骤-->

**截图**
<!--（可选）Bug 发生时的截图-->

**环境信息**
 - PHP 版本：[例如：7.2]
 - Typecho 版本：[例如：1.1(20.05.15) 开发版]

-----

<!--以下可自由发挥-->
