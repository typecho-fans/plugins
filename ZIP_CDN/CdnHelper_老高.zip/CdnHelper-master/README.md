# CDNhelper
 A typecho plugin for cdn


主要功能是替换了文章中的img-src为加速后的src

功能待完善