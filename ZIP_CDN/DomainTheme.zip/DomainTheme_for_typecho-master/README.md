## 起步 ##
博客有多个用户，每人希望用自己中意的主题，想想是可以通过不同域名来调用不同主题的。于是完成了这个。虽然感觉使用人不多，可能就`typecho主题汇总网站`会用到而已，但还是分享出来吧。

## 使用方法 ##

第一步：下载本插件，放在 usr/plugins/ 目录中；
第二步：激活插件；
第三步：控制台->域名模板 进行设置；
第四步：完成。

## 预览

![20160401101859.png][1]

## 特别说明：

这个插件是为满足个人需求而编写，兼容性方面多多少少会有不完善的地方，如有需求，可根据源代码自行修改，或者与我联系。

有的模板可以设置数据，我也找不到什么好办法，用自定义数据`(json格式)`来定义，不知道写就为空吧。

域名`不包括`前面的`http://`

github开源地址：[https://github.com/hongweipeng/DomainTheme_for_typecho][2]

## 与我联系：

作者：hongweipeng
主页：[https://www.hongweipeng.com/][3]
或者通过 Emai: hongweichen8888@sina.com
有任何问题也可评论留言


  [1]: https://www.hongweipeng.com/usr/uploads/2016/04/3457184789.png
  [2]: https://github.com/hongweipeng/DomainTheme_for_typecho
  [3]: https://www.hongweipeng.com/