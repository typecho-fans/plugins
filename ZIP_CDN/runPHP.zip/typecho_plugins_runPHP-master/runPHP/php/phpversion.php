<?php echo 'phpversion:'.phpversion();?>
