# typecho网站访问统计插件

* 支持matomo
  * 安装matomo后，将地址写入配置文件格式为  `//xxx.xxx.com/`,其实就是追踪代码中的地址数据
* 支持百度统计
  * 注册后可以拿到代码,其中的随机数也就是`https://hm.baidu.com/hm.js?需要设置的code`
* 支持谷歌统计
  * 注册后即获取到一个追踪代码，设置即可
  
将statistics目录放到typecho项目的插件下即可，在项目后台进行启用与配置