### Subscriber 1.0 beta for Typecho 0.9

计划正式版分离action实现订阅权限细分等功能

详细使用说明和效果演示见blog发布地址: 
####http://www.jzwalk.com/archives/net/subscriber-for-typecho