### Html代码转Markdown格式插件Html2Text v0.1.0

为HTML内容日志批量添加Markdown解析标记或强制转换为Markdown语法格式。

启用插件后请进入“控制台”-“Html2Text”面板进行操作。

 > 更新面板说明，修正markdownify兼容PHP7.0。

:warning:转换易出现换行混乱等问题，请务必提前备份好数据库。

###### 更多详见论坛原帖：http://forum.typecho.org/viewtopic.php?f=6&t=4257