<?php

if (!defined('__TYPECHO_ROOT_DIR__')) {
	exit;
}

/**
 * 天行数据土味情话插件
 * 
 * @package TianAPISayLove_Plugin
 * @author 宇天行
 * @version 1.0.0
 * @link https://www.tianapi.com
 */
class TianAPISayLove_Plugin implements Typecho_Plugin_Interface
{
	/**
	 * 激活插件方法,如果激活失败,直接抛出异常
	 * 
	 * @access public
	 * @return void
	 * @throws Typecho_Plugin_Exception
	 */
	public static function activate(){
		
		return _t('请设置<a href="options-plugin.php?config=TianAPISayLove_Plugin">接口密钥</a>，密钥可在天行数据官网申请。');
		
	}
	
	/**
	 * 禁用插件方法,如果禁用失败,直接抛出异常
	 * 
	 * @static
	 * @access public
	 * @return void
	 * @throws Typecho_Plugin_Exception
	 */
	public static function deactivate(){}
	
	/**
	 * 获取插件配置面板
	 * 
	 * @access public
	 * @param Typecho_Widget_Helper_Form $form 配置面板
	 * @return void
	 */
	public static function config(Typecho_Widget_Helper_Form $form){ 
		
		$apikey = new Typecho_Widget_Helper_Form_Element_Text('apikey', NULL, 'dc8d1a210314bd459534e17adce87bff', '天行数据APIKEY', '请替换为你在<a href="https://www.tianapi.com/signup.html?source=ty4152177">天行数据</a>官网申请到的密钥');
		$form->addInput($apikey->addRule('required', '必须填写天行数据的API密钥即APIKEY'));
	}
	
	/**
	 * 个人用户的配置面板
	 * 
	 * @access public
	 * @param Typecho_Widget_Helper_Form $form
	 * @return void
	 */
	public static function personalConfig(Typecho_Widget_Helper_Form $form){}

	public static function buildTianAPISayLove() {
				
		//判断当前插件是否已被启用
		$options = Typecho_Widget::widget('Widget_Options');
		if (!isset($options->plugins['activated']['TianAPISayLove'])) {
			return '天行数据土味情话插件未被启用';
		}

		//获取密钥配置信息	   
		$tianapi_apikey =$options->plugin('TianAPISayLove')->apikey;	
		
        $get_tianapi=file_get_contents('http://api.tianapi.com/txapi/saylove/?key='.$tianapi_apikey);
        $saylove=json_decode($get_tianapi,true);
        $saylove_content = $saylove['code'] == 200?$saylove['newslist'][0]['content']:'数据读取失败，请检查该插件的apikey';

		return $saylove_content;
	}
	/**
	 * 插件实现方法
	 * 
	 * @access public
	 * @return void
	 */
	public static function parse()
	{
		echo TianAPISayLove_Plugin::buildTianAPISayLove();
			
	}
}



