# LivephotoKit JS Typecho 
给 Typecho 添加 Livephoto 的支持

## 使用
1. 下载后请将插件目录名请修改为 `LivephotoKit`
2. 上传至服务器，启用插件
3. 然后并根据自己的实际情况选择对是否开启 Pjax 支持进行选择
4. 在文章中插入 `[Livephoto video="" photo="" /]`
5. Enjoy ~

## 注意
1. 为了更好的了解使用情况，在插件中添加了统计代码，假如想要去除请删除 `Plugin.php` 文件中的 29～34 行与 50～53 行

## 感谢
1. LivePhotoKit JS 测试: https://c0lacan.net/article/480
