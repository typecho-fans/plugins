<?php
class Plugin_Const {
    const VERSION = '1.1.0';
    
    const GITHUB_REPO_API = 'https://api.github.com/repos/MoeLoli/LivephotoKit-Typecho/releases/latest';
}
