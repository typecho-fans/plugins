# Light-AudioPlayer-Plugin
Light-AudioPlayer For Typecho.

##使用方法
*插件文件夹名字可能必须为LightAudioPlayer*

在文章内输入`[mp3]文件地址|参数1|参数2[/mp3]`即可

可附带参数`autoplay` 自动播放,`loop` 循环播放

采用[Light-AudioPlayer](https://github.com/mikeyzm/Light-AudioPlayer)为播放器.
