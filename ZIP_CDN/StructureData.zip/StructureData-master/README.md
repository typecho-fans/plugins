# StructureData

Structure data plugin for Typecho. Using JSON-LD.

## Related

Blogpost: [Typecho StructureData 插件][blogpost]

[blogpost]: https://blog.mynook.info/post/typecho-structuredata-plugin
