# typecho-plugin
typecho插件,typecho文章打赏插件Donate<br/>
[预览](http://rootvip.cn/)
### Donate(typecho文章打赏插件)
[Donate使用文档>>](./Donate/README.md)
## License
Apache License 2.0