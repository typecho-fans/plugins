## 起步

悬浮式文章目录树，定在右侧。

## 使用方法

第一步：下载本插件，放在 `usr/plugins/` 目录中，确保文件夹名为 `MenuTree` ；
第二步：激活插件；

## 预览

![20160401112707.png][1]

github开源地址：[https://github.com/typecho-fans/plugins/tree/master/MenuTree_hongweipeng][2]

## 与我联系：

作者：hongweipeng
主页：[https://github.com/hongweipeng][3]
或者通过 Emai: hongweichen8888@sina.com
有任何问题也可评论留言


  [1]: http://note.787315.xyz/usr/uploads/2025/07/3209222143.png
  [2]: https://github.com/typecho-fans/plugins/tree/master/MenuTree_hongweipeng
  [3]: https://github.com/hongweipeng
