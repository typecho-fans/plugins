<?php
/**
 * 通知博客搜索引擎及时进行抓取、更新
 * 
 * @package Ping 
 * @author Liudon
 * @version 1.0.0
 * @link http://www.liudon.org
 */
class Ping_Plugin implements Typecho_Plugin_Interface {

    public static function activate()
    {
        Helper::addAction('contents-post-edit', 'Ping_Action');
    }

    public static function deactivate(){}

    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $servers = <<<EOF
http://blogsearch.google.com/ping/RPC2 
http://ping.baidu.com/ping/RPC2 
EOF;
        $name = new Typecho_Widget_Helper_Form_Element_Textarea('servers', NULL, $servers, _t('Ping服务URL'), _t('一行一个'));
        $form->addInput($name);
    }

    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
}