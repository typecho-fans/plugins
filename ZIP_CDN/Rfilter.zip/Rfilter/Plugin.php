<?php
/**
 * 评论验证码插件
 * @package Rfilter
 * @author Rakiy
 * @version 1.0.0
 * @link http://typecho.org http://85s.me
 */
class Rfilter_Plugin extends Typecho_Widget implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
            Typecho_Plugin::factory('Widget_Feedback')->comment = array('Rfilter_Plugin', 'filter');
            Typecho_Plugin::factory('Widget_Feedback')->trackback = array('Rfilter_Plugin', 'filter');
            Typecho_Plugin::factory('Widget_XmlRpc')->pingback = array('Rfilter_Plugin', 'filter');
       //判断是否为外部提交，摘自Captcha
        Helper::addAction('Rfilter', 'Rfilter_Action');
    }
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){}
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {}
    
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    
    public static function output()
    {
        //取值范围及其和
        $num1=rand(5,15);
        $num2=rand(5,15);
        $sum= $num1 + $num2;
        //最终网页中的具体内容
    echo "<p><input type='text' name='rcode' id='rcode' class='text' size='15' onclick='this.value=\"\"' value='". _t('请输入验证码')."' />"
        ."<label for='rcode'>$num1+$num2<span class='required'>*</span> ("._t('请输入数字')."$sum) </label></p>"
        ."<input type='hidden' name='num1' value='$num1'>"
        ."<input type='hidden' name='num2' value='$num2'>";
    }
    
    /**
     * 评论过滤器
     * 
     * @access public
     * @param array $comment 评论结构
     * @param Typecho_Widget $post 被评论的文章
     * @param array $result 返回的结果上下文
     * @param string $api api地址
     * @return void
     */
    public static function filter($comment, $post, $result)
    {
        //获取表单传来的3个值
        $sum = Typecho_Request::getInstance()->rcode;
        $num1 = Typecho_Request::getInstance()->num1;
        $num2 = Typecho_Request::getInstance()->num2;        
        switch($sum){
          //得到正确的计算结果则直接跳出
          case $num1+$num2:break;
          //未填写结果时的错误讯息        
          case null:throw new Typecho_Widget_Exception(_t('请输入验证码'));break;
          //计算错误时的错误讯息
          default:throw new Typecho_Widget_Exception(_t('验证码错误, 请重新输入'));
        }
        return $comment;
    }
}
?>
