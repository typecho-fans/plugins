<?php

class Rfilter_Action extends Typecho_Widget implements Widget_Interface_Do
{
    public function action()
    {
        /** 防止跨站 */
        $referer = $this->request->getReferer();
        if (empty($referer)) {
            exit;
        }
        
        $refererPart = parse_url($referer);
        $currentPart = parse_url(Helper::options()->siteUrl);
        
        if ($refererPart['host'] != $currentPart['host'] ||
        0 !== strpos($refererPart['path'], $currentPart['path'])) {
            exit;
        }
    }
}
