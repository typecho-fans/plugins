# Typecho-NginxHelper

Typecho NginxHelper插件，干什么用的参考Wordpress的Nginxhelper，主要是帮助nginx清理缓存


**注意！！使用之前请更改Plugin.php里$NGINX_CACHE_PATH，如果你的Nginx缓存目录不是/tmp/nginx，请更改，否则插件无法工作**
