# typechopostrate
Typecho 评分插件。原作者为：willin kan。因为原作很久没有更新，网站也没有更新了。于是优化修改了一下。

优化后效果如下：

![](http://i1166.photobucket.com/albums/q614/kuan0025/wwvrdh/wenzhang/5y.jpg)
![](http://i1166.photobucket.com/albums/q614/kuan0025/wwvrdh/wenzhang/5s.jpg)

具体使用方法插件设置内有简单的说明。
