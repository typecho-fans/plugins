### Typecho_Plugin

#### 简单实现鼠标点击效果与图标追随（图标追随默认不启用）

### 启用方法

#### git clone至plugins文件夹下，后台启用即可。