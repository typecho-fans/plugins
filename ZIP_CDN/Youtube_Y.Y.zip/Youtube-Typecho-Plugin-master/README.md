# Youtube-Typecho-Plugin 
* 当前版本: 1.1.0
* 作者   : https://84361749.com/   
* 官网   : https://84361749.com/post/typecho-youtube-embeded-plugin.html
* Github : https://github.com/ayangyuan/Youtube-Typecho-Plugin 
* 标签   : Typecho, Youtube, Vimeo, Video
* 支持: Typecho 1.1

# 说明
为 Typecho v1.1 提供 Youtube 和 Vimeo 快捷插入方式

# 日志 
### v1.1.0 2018.01.04
* 增加了对 Vimeo 的支持
* 删除了一个冗余测试文件
* 重新制作了 README.md

### v1.0.0 2017.12.13
* 正式发布



