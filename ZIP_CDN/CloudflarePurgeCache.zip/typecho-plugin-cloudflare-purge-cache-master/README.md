# typecho-plugin-cloudflare-purge-cache

用于清除 Cloudflare 缓存的 Typecho 插件，需要配合 Cloudflare 的 Page Rule 静态化使用。

下载后将 `CloudflarePurgeCache` 目录放到 Typecho 项目的 `usr/plugins/` 下启用即可。
