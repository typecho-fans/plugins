## Typecho网站右侧浮动客服插件
基于hello word插件结构 改造的插件
## 安装方法
下载后，文件夹为`Kefu`，上传放入/ usr /plugins，后台开启插件即可。
## 介绍
* 启用插件后，页面右侧即可显示浮动客服，插件后台可自定义 提示语 和 客服链接。
* 本客服插件小巧，无JS脚本 纯CSS 实现，简洁如初。欢迎使用！
* 使用的主题模板挂载点：页首钩子`<?php $this->header(); ?>`和页脚钩子`<?php $this->footer(); ?>`
## 结语
插件发布页：https://www.qqeg.cn/Typecho/19.html
