Github Card for Typecho
===================

本插件实现在Typecho中嵌入github的用户或者项目的卡片。

下载插件：

    git clone https://github.com/chekun/typecho-github-card.git /typecho-plugin-path/GithubCard

激活后使用：

```
[card]chekun[/card] //嵌入用户卡片
```

```
[card]chekun/typecho-github-card[/card] //嵌入项目卡片
```

本项目使用了 [lepture/github-cards](https://github.com/lepture/github-cards).

使用演示:

[http://me.dilicms.com/coding/github-card.html](http://me.dilicms.com/coding/github-card.html)
