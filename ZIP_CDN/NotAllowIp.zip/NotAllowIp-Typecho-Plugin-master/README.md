# NotAllowIp-Typecho-Plugin
typecho博客 后台插件-IP黑名单

##作用：
设置后禁止一些ip访问

## 安装方法
* 下载解压，将文件重名为NotAllowIp，上传到usr/plugins/目录下
* 后台激活该插件，设置IP地址
