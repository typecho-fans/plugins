/*! Project:无, Create:FWS 2020.01.08 21:48, Update:FWS 2020.01.08 21:48 */ 
module.exports={amp:"&",apos:"'",gt:">",lt:"<",quot:'"'};