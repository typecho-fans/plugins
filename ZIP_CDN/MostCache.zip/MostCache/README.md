### Mysql/SAE Memcache缓存插件MostCache v1.0.0

支持使用MySQL或在SAE(新浪云引擎)下使用Memcache缓存页面数据，可自动更新缓存并通过“控制台”-“MostCache”面板管理缓存数据与匹配规则。

 > 修正面板问题，兼容Typecho1.0+。

###### 非SAE环境使用Memcache可下载修改版：https://github.com/weicno/typecho-cache