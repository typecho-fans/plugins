# Typecho追番插件

#### 项目介绍
本插件为通过Bangumi的API来获取追番信息。适用于Typecho!  
具体使用方法相见：[https://www.wikimoe.com/?post=136](https://www.wikimoe.com/?post=136)
