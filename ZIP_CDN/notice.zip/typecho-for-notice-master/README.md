# typecho-for-notice
 > 1. 一款消息通知插件，判断来路地址输出欢迎消息。
将notice文件夹放入typecho插件目录中，然后激活该插件即可
