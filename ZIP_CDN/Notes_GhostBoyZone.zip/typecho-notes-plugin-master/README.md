# typecho-notes-plugin
基于typecho的便签插件

### 预览图

![screenshot1](https://raw.githubusercontent.com/ghostboyzone/typecho-notes-plugin/master/screenshot1.png)

![screenshot2](https://raw.githubusercontent.com/ghostboyzone/typecho-notes-plugin/master/screenshot2.png)
