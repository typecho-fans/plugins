<?php
include 'header.php';
include 'menu.php';
?>

<div class="main">
    <div class="body container">
		<?php include 'page-title.php'; ?>
        <div class="container typecho-page-main">
        </div>
    </div>
</div>

<?php
include 'copyright.php';
include 'common-js.php';
include 'table-js.php';
include 'footer.php';
?>