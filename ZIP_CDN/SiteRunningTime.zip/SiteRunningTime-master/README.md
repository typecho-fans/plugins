# 显示系统运行时长 ![download](https://img.shields.io/github/downloads/zhusaidong/SiteRunningTime/total.svg)

Typecho插件：在底部显示系统的运行时长

### 预览
![预览](http://forum.typecho.org/download/file.php?id=1128)

### 插件安装

	下载好插件
	进入typecho的usr/plugins目录
	把插件解压到里面

### 换行显示

如果你想换行在下面显示，可以在输出格式的前面加`<br />`，暂时不支持放在上面。

### 反馈
[反馈](https://github.com/zhusaidong/SiteRunningTime/issues)

