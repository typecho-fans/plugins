# 获取真实IP

如果您的服务器位于反向代理后面，获取的IP为反向代理的IP。如果要获取客户端的真实IP，则必须将代理列入白名单。


**使用方法**

1. 下载本插件，放在 usr/plugins/ 目录中
2. 登录管理后台，激活插件


**Links**

- Blog：http://blog.ponycool.com 
- Email: pony#ponycool.com(将#替换为@)
- Github: https://github.com/PonyCool
