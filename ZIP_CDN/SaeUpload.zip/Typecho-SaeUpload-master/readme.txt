首先，下载插件，将SaeUpload目录放置在Typecho根目录下的usr/plugins/目录中
其次，在控制台=>插件管理中启用SaeUpload插件，并在Sina App Engine控制面中新增Storage的Domain名称为typechoupload，同样的设置SaeUpload插件中的Domain名称为typechoupload即可

说明地址：
http://www.ccvita.com/491.html
