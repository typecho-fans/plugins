<?php

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
/**
 * 为文章增加付费阅读功能，访客需要支付设定的费用后才可阅读完整内容。
 *
 * @package paywall
 * @author calmhe
 * @version 3.0.0
 * @link https://www.zhi12.cn
 */
require_once 'func.php';
require_once 'includes/paywall_php_sdk/paywall.func.inc.php';
class paywall_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     *
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->header = array('paywall_Plugin', 'header');
        Typecho_Plugin::factory('Widget_Abstract_Contents')->excerptEx = array('paywall_Plugin', 'ReplaceContentAfterMarkdown');//摘要转换
        Typecho_Plugin::factory('Widget_Abstract_Contents')->contentEx = array('paywall_Plugin', 'ReplaceContentAfterMarkdown');//内容转换
        //Typecho_Plugin::factory('Widget_Archive')->beforeRender = array('paywall_Plugin', 'ReplaceContentBeforeMarkdown');//页面渲染前调用
        Typecho_Plugin::factory('admin/write-post.php')->option = array('paywall_Plugin', 'PaywallEdit');
        Typecho_Plugin::factory('admin/write-page.php')->option = array('paywall_Plugin', 'PaywallEdit');
        Typecho_Plugin::factory('Widget_Contents_Post_Edit')->finishPublish = array('paywall_Plugin', 'PaywallPost');
        Typecho_Plugin::factory('Widget_Contents_Page_Edit')->finishPublish = array('paywall_Plugin', 'PaywallPost');
        Typecho_Plugin::factory('Widget_Contents_Post_Edit')->finishSave = array('paywall_Plugin', 'PaywallPost');
        Typecho_Plugin::factory('Widget_Contents_Page_Edit')->finishSave = array('paywall_Plugin', 'PaywallPost');
        $db = Typecho_Db::get();
        $prefix = $db->getPrefix();
        if (!array_key_exists('paywallmod', $db->fetchRow($db->select()->from('table.contents')))) {
            $db->query('ALTER TABLE `'.$prefix.'contents` ADD `paywallmod` INT(11) DEFAULT 0;');
        }
        if (!array_key_exists('paywallfee', $db->fetchRow($db->select()->from('table.contents')))) {
            $db->query('ALTER TABLE `'.$prefix.'contents` ADD `paywallfee` float(11,2) DEFAULT 0;');
        }
    }

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     *
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate()
    {
    }

    /**
     * 获取插件配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $fyUID = new Typecho_Widget_Helper_Form_Element_Text('fyUID', null, '0', _t('UID'), _t('您在 <a href="https://www.zhi12.cn" target="_blank">zhi12.cn</a> 网站上（我的账户 > 其它）的账户UID，用于接收用户付款。'));
        $fyUID->input->setAttribute('type', 'number');
        $fyUID->input->setAttribute('class', 'w-10');
        $fyKey = new Typecho_Widget_Helper_Form_Element_Text('fyKey', null, '', _t('通讯密钥'), _t('您在 <a href="https://www.zhi12.cn" target="_blank">zhi12.cn</a> 账户下设置的通讯密钥（Secret）。'));
        $fyKey->input->setAttribute('class', 'w-40');
        $fyMod = new Typecho_Widget_Helper_Form_Element_Radio('fyMod', array(0=>_t('免费'),1=>_t('收费'),), '0', _t('默认状态'), _t('如将默认状态设置为“收费”，除单独设置的文章外，全站所有文章默认均需付费才可阅读。默认值：免费'));
        $fyFee = new Typecho_Widget_Helper_Form_Element_Text('fyFee', null, '1', _t('默认阅读费用'), _t('为文章设置默认付费金额(0-200元)。注意：仅在“默认状态”为收费时才生效。'));
        $fyFee->input->setAttribute('type', 'number');
        $fyFee->input->setAttribute('max', '200');
        $fyFee->input->setAttribute('min', '0');
        $fyFee->input->setAttribute('step', '0.01');
        $fyFee->input->setAttribute('class', 'w-10');
        $fyPer = new Typecho_Widget_Helper_Form_Element_Text('fyPer', null, '50', _t('隐藏比例%'), _t('未设置付费区域情况下，默认隐藏多少内容(10-90)？建议值：50, 60, 70'));
        $fyPer->input->setAttribute('type', 'number');
        $fyPer->input->setAttribute('max', '90');
        $fyPer->input->setAttribute('min', '10');
        $fyPer->input->setAttribute('class', 'w-10');
        $fyPop = new Typecho_Widget_Helper_Form_Element_Radio('fyPop', array(0=>_t('不启用弹窗'),1=>_t('启用弹窗'),), '0', _t('弹窗模式'), _t('为付费阅读插件增加弹窗支持，提供更好的用户使用体验，提高付费率。'));
        $fyUrl = new Typecho_Widget_Helper_Form_Element_Text('fyUrl', null, 'https://www.zhi12.cn', _t('通讯网关'), _t('通讯网关，一般情况下请勿修改。'));
        $fyUrl->input->setAttribute('class', 'w-40');
        //$fyAdm = new Typecho_Widget_Helper_Form_Element_Checkbox('fyAdm',
        //  array('administrator'=>_t('管理员'),'editor'=>_t('编辑'),'contributor'=>_t('贡献者'),'subscriber'=>_t('关注着'),'visitor'=>_t('访问者')),
        //  array('administrator','editor'), _t('不受限用户组'), _t('无需付费即可阅读的用户组'));
        $form->addInput($fyUID);
        $form->addInput($fyKey);
        $form->addInput($fyMod);
        $form->addInput($fyFee);
        $form->addInput($fyPer);
        $form->addInput($fyPop);
        $form->addInput($fyUrl);
        //$form->addInput($fyAdm->multiMode());
    }

    /**
     * 个人用户的配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form)
    {
    }

    public static function header()
    {
        $aCfg = GetCfg();
        $cssUrl = Helper::options()->pluginUrl . '/paywall/includes/paywall_php_sdk/paywall.css';
        $template = '<link rel="stylesheet" type="text/css" href="'.$cssUrl.'" />';
        echo "\r\n".$template."\r\n";
        $jsUrl = $aCfg['fyUrl'].'/sites/all/libraries/shang/shang.js';
        $template = '<script type="text/javascript" src="'.$jsUrl.'"></script>';
        echo $template."\r\n";
    }

    public static function ReplaceContentAfterMarkdown( $text, Widget_Abstract_Contents $archive){
        //file_put_contents('usr/uploads/0000.txt',$text."\r\n".print_r($archive,1));
        $aCfg = GetCfg();
        $db = Typecho_Db::get();
        $uid = intval(Typecho_Cookie::get('__typecho_uid'));
        $aUser = $db->fetchRow($db->select('group')->from('table.users')->where('uid=?', $uid));
        if ($aUser) {
            $UserGroup = $aUser['group'];
        } else {
            $UserGroup = 'visitor';
        }
        $cid = intval($archive->request->cid);
        if($cid>0){
            $ContentMode = 'full';
        }else{
            $ContentMode = 'list';
        }
        return Replace_Content($archive, $ContentMode, $archive->cid, $uid, $UserGroup, $aCfg, $text);//$ContentMode.$cid.'/'.
    }
    /**
     * 插件实现方法
     *
     * @access public
     * @param Widget_Archive $archive
     * @return void
     */
    public static function ReplaceContentBeforeMarkdown(Widget_Archive $archive)
    {
        /*
        file_put_contents('usr/uploads/0000.txt',print_r($archive,1));
        print_r($archive->title);
        replace_article($archive, false, $archive->cid, $uid, $UserGroup, $aCfg);
        foreach ($archive->stack as $index => $con) {
            if (array_key_exists('text', $con)) {
                replace_article($archive->stack[$index], true, $archive->stack[$index]['cid'], $uid, $UserGroup, $aCfg);
            }
        }
        */
    }

    public static function PaywallEdit($post)
    {
      //配置只在管理员登录时才显示?
        $db= Typecho_Db::get();
        $aFields = $db->fetchRow($db->select('paywallmod,paywallfee')->from('table.contents')->where('cid=?', intval($post->cid)));
        if ($aFields) {
            $TheMod = intval($aFields['paywallmod']);
            $TheFee = floatval($aFields['paywallfee']);
        } else {
            $TheMod = 9;
            $TheFee = 0;
        }
        echo '<section class="typecho-post-option"><label class="typecho-label">收费模式</label><p>
        <input type="radio" name="paywallmod" value="9"'.($TheMod==9?' checked':'').' /> 默认&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="radio" name="paywallmod" value="0"'.($TheMod==0?' checked':'').' /> 免费&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="radio" name="paywallmod" value="1"'.($TheMod==1?' checked':'').' /> 付费
      </p></section>';
        echo '<section class="typecho-post-option"><label class="typecho-label">付费时阅读费用</label><p>
        <input type="number" name="paywallfee" value="'.($TheFee?$TheFee:1).'" min="1" max="200" step="0.01"/>元
        <div style="font-size: smaller; color: #888;">收费内容默认按<a href="/admin/options-plugin.php?config=paywall" target="_blank">隐藏比例设置</a>自动隐藏部分内容，可使用 <code>[$][/$]</code> 手动设置付费区域。</div>
      </p></section>';
    }

    public static function PaywallPost($contents, $class)
    {
        $db= Typecho_Db::get();
        $PayWallMod = intval($_POST['paywallmod']);
        $PayWallFee = floatval($_POST['paywallfee']);
        $update = $db->update('table.contents')->rows(array('paywallmod'=>$PayWallMod,'paywallfee'=>$PayWallFee))->where('cid=?', intval($class->cid));
        $updateRows= $db->query($update);//有权修改？
    }
}
