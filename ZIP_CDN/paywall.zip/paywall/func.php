<?php

function Replace_Content(&$archive, $ContentMode, $cid, $uid, $UserGroup, $aCfg, $text='')
{
    $authorId = $archive->authorId;
    $title = $archive->title;
    $db = Typecho_Db::get();
    $aFields = $db->fetchRow($db->select('paywallmod,paywallfee')->from('table.contents')->where('cid=?', $cid));
    $TheMod = intval($aFields['paywallmod']);
    $TheFee = floatval($aFields['paywallfee']);
    if ($TheMod==1) {
        $Fee = $TheFee;
    } elseif ($TheMod==0) {
        $Fee = 0;
    } elseif ($aCfg['fyMod']==1) {
        $Fee = $aCfg['fyFee'];
    } else {
        $Fee = 0;
    }
    $FeeOk = false;//付费状态
    $IsAdm = false;//管理权限
    if (in_array($UserGroup, $aCfg['fyAdm']) || $authorId==$uid) {//管理员、作者直接授权付费
        $IsAdm = true;
        $FeeOk = true;
    } elseif ($Fee>0) {//检查是否已付费
        $FeeOk = paywall_access($aCfg);
    }
    $aConvCfg = array(
      'form' => paywall_form($cid, $title, $Fee, $uid, $aCfg),
      'amount' => $Fee,
      'percent' => $aCfg['fyPer'],
    );
    if ($Fee>0) {//非免费对象、免费文章则转换内容显示
        if ($text) {
            return paywall_content_convert($text, $aConvCfg, $FeeOk, $ContentMode);//$Fee.'/'.
        } else {
            $archive->text = paywall_content_convert($archive->text, $aConvCfg, $FeeOk, $ContentMode);
        }
    }else{
        if ($text) return $text;//$Fee.'/'.
    }
    return;
}

function paywall_form($cid, $Title, $Fee, $uid, $aCfg)
{
    //$current_url = paywall_current_url();
    $aOptions = Helper::options();
    $current_url = rtrim($aOptions->siteUrl,'/').'/usr/plugins/paywall/permalink.php?id='.$cid;
    //echo "<a href=\"{$current_url}\">{$current_url}</a>";
    $product_id = 'typecho' . $cid;
    $query = array(
        'uid' => $aCfg['fyUID'],
        'title' => preg_replace("/[\s]+/is", " ", $Title), // 移除标题中一个以上连续空格
        'url' => $current_url,
        'type' => 'paywall',
        'product_id' => $product_id,
        'amount' => $Fee,
        'version' => 3,
    );
    $query2 = array(
        'uid' => $aCfg['fyUID'],
        'url' => $current_url,
        'product_id' => $product_id,
    );
    $query['sign'] = paywall_get_sign($query, $aCfg['fyKey']);
    $query2['sign'] = paywall_get_sign($query2, $aCfg['fyKey']);
    $pay_url = $aCfg['fyUrl'] . '/paycenter/pay/widget?' . http_build_query($query);
    $codecheck_url = $aCfg['fyUrl'] . '/paywall/codecheck/widget?' . http_build_query($query2);
    $output = '';
    $output.= '<div class="paywall-toggle">';
    $output.= '  <div id="paywall-link-box">';
    $output.= '    <div><strong>本部分为付费内容，支付后可查看</strong></div>';
    $output.= '    <div><a class="btn btn-link zhi12-popup" target="_blank" href="' . $pay_url . '" rel="nofollow">支付' . $Fee . '元</a></div>';
    $output.= '    <div><a class="zhi12-popup zhi12-widget" href="' . $codecheck_url . '" target="_blank" data-box-height="300">已支付？输入手机号查看</a></div>';
    $output.= '  </div>';
    $output.= '</div>';
    return $output;
}

function paywall_access($aCfg)
{
  // Check access by URL params.
    $expire = filter_input(INPUT_GET, 'expire', FILTER_VALIDATE_INT);
    $code = filter_input(INPUT_GET, 'code');
    $sign = filter_input(INPUT_GET, 'sign');
    $_sign = paywall_get_sign($_GET, $aCfg['fyKey']);
    $now = time();
    if ($expire && $now > $expire) {//链接已失效
        throw new Typecho_Widget_Exception(_t('链接已失效'));
        return false;
    }
    if ($now <= $expire && $sign === $_sign) {
        return true;
    }
    return false;
}

function GetCfg()
{
    $aCfg = array(
    'fyUID' => Typecho_Widget::widget('Widget_Options')->plugin('paywall')->fyUID,
    'fyKey' => Typecho_Widget::widget('Widget_Options')->plugin('paywall')->fyKey,
    'fyMod' => intval(Typecho_Widget::widget('Widget_Options')->plugin('paywall')->fyMod),
    'fyFee' => floatval(Typecho_Widget::widget('Widget_Options')->plugin('paywall')->fyFee),
    'fyPer' => Typecho_Widget::widget('Widget_Options')->plugin('paywall')->fyPer,
    'fyPop' => Typecho_Widget::widget('Widget_Options')->plugin('paywall')->fyPop,
    'fyUrl' => Typecho_Widget::widget('Widget_Options')->plugin('paywall')->fyUrl,
    'fyAdm' => array('administrator','editor'),//Typecho_Widget::widget('Widget_Options')->plugin('paywall')->fyAdm,
    );
    $aCfg['fyUrl'] = trim(trim($aCfg['fyUrl']), '/');
    if (strtolower(substr($aCfg['fyUrl'], 0, 7)) != 'http://' && strtolower(substr($aCfg['fyUrl'], 0, 8)) != 'https://') {
        $aCfg['fyUrl'] = 'http://'.$aCfg['fyUrl'];
    }
    return $aCfg;
}
