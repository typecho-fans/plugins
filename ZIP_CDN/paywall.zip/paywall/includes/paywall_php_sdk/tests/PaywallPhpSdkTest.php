<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

require_once __DIR__ . "/../paywall.func.inc.php";

/**
 * PaywallPhpSDK test.
 */
final class PaywallPhpSdkTest extends TestCase {

  /**
   * Test paywall_get_sign().
   */
  public function testGetSign() {

    $secret = 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';

    $data1 = array('a' => 1);
    $data2 = array('a' => 1, 'b' => '2');
    $data3 = array('a' => 1, 'q' => '/');
    $data4 = array('a' => 1, 'q' => '/', 'sign' => 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');

    $sign1 = paywall_get_sign($data1, $secret);
    $sign2 = paywall_get_sign($data2, $secret);
    $sign3 = paywall_get_sign($data3, $secret);
    $sign4 = paywall_get_sign($data4, $secret);

    $this->assertEquals($sign1, '91c9f832aac83e17af474fc5f6299b13');
    $this->assertEquals($sign2, '99d1df0cda6686e1af8790ec2bc63697');
    $this->assertEquals($sign3, '91c9f832aac83e17af474fc5f6299b13');
    $this->assertEquals($sign4, '91c9f832aac83e17af474fc5f6299b13');
  }

}
