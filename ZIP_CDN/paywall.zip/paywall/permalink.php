<?php
/**
 * Typecho Blog Platform
 *
 * @copyright  Copyright (c) 2008 Typecho team (http://www.typecho.org)
 * @license    GNU General Public License 2.0
 * @version    $Id: index.php 1153 2009-07-02 10:53:22Z magike.net $
 */

$id = intval($_GET['id']);
if( $id<=0 ){
    echo "[id={$id}] error";
    exit;
}

/** 载入配置支持 */
if (!defined('__TYPECHO_ROOT_DIR__') && !@include_once '../../../config.inc.php') {
    print('Missing Config File');
    exit;
}

/** 初始化组件 */
Typecho_Widget::widget('Widget_Init');
//$aOptions = Helper::options();
$db = Typecho_Db::get();

$aContent = $db->fetchRow($db->select()->from('table.contents')->where('cid = ?',$id));
if($aContent){
    $aContent = Typecho_Widget::widget('Widget_Abstract_Contents')->push($aContent);
    $url = $aContent['permalink'];
    $url = str_replace('/usr/plugins/paywall/','/',$url);
    header("location:{$url}");
}else{
    echo "[id={$id}] not found";
}
exit;


