<?php

/** 载入配置支持 */
include_once '../../../config.inc.php';
require_once 'includes/paywall_php_sdk/paywall.func.inc.php';

/** 初始化组件 */
Typecho_Widget::widget('Widget_Init');

header('Content-type: application/json');

// Params.
$post_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$sign = filter_input(INPUT_GET, 'sign');
if (!$post_id || !$sign) {
    exit(json_encode(array('error' => '参数错误'), JSON_UNESCAPED_UNICODE));
}

$aCfg = array(
  'fyKey' => Typecho_Widget::widget('Widget_Options')->plugin('paywall')->fyKey,
  'fyMod' => intval(Typecho_Widget::widget('Widget_Options')->plugin('paywall')->fyMod),
  'fyFee' => intval(Typecho_Widget::widget('Widget_Options')->plugin('paywall')->fyFee),
);

$cid = $post_id;
$aFields = $db->fetchRow($db->select('title,text,authorId,status,paywallmod,paywallfee')->from('table.contents')->where('cid=?', $cid));
$TheMod = intval($aFields['paywallmod']);
$TheFee = intval($aFields['paywallfee']);
if ($TheMod==1) {
    $Fee = $TheFee;
} elseif ($TheMod==0) {
    $Fee = 0;
} elseif ($aCfg['fyMod']==1) {
    $Fee = $aCfg['fyFee'];
} else {
    $Fee = 0;
}

// Check sign.
$secret = $aCfg['fyKey'];
$sign2check = paywall_get_sign($_GET, $secret);
if ($sign !== $sign2check) {
    exit(json_encode(array('error' => '无效请求'), JSON_UNESCAPED_UNICODE));
}

$post = array(
  'id' => $cid,
  'title' => $aFields['title'],
  'content' => $aFields['text'],
  'authorId' => $aFields['authorId'],
  'status' => $aFields['status'],
);
if ($post['id'] === 0) {
    exit(json_encode(array('error' => '内容不存在'), JSON_UNESCAPED_UNICODE));
}
$amount = $Fee;
$data = array(
  'id' => $post['id'],
  'title' => $post['title'],
  'content' => $post['content'],
  'amount' => $amount,
  'post' => serialize($post), // raw post.
);
$json = json_encode($data, JSON_UNESCAPED_UNICODE);
echo $json;
