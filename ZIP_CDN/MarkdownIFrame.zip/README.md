# typecho-plugins

----

young's typecho-plugins

typecho插件安装可参照官网教程

##MarkdownIFrame

![iframe插件](https://github.com/youngzhaojia/typecho-plugins/blob/master/libs/iframe.gif)

