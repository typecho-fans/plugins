﻿# typembed

 > :warning:目前支持优酷/搜狐/腾讯和A/B站链接替换，其他包括后增的芒果TV/Dailymotion等测试已失效。

Typembed 是为 Typecho 添加对在线视频支持的一款插件（支持手机、平板等设备HTML5播放）。目前支持优酷、搜狐视频、土豆、56、腾讯视频、新浪视频、酷6、华数、乐视 等网站。

与 WordPress 支持的 oembed 可以无缝切换，换博客系统也不用担心内容不一致。

你可以直接粘贴视频播放页完整的URL到编辑器（单独一行），就可以加载视频播放器（不能在编辑器里实时渲染，文章发布之后可以看到效果）。

项目主页：http://www.fengziliu.com/typembed.html

效果展示：http://www.fengziliu.com/da-hai.html

关注微信公众号，获得更新提醒

![关注微信公众号，获得更新提醒](http://www.rifuyiri.net/wp-content/uploads/2014/08/972e6fb0794d359.jpg)
