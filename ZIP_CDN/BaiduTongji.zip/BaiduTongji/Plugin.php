<?php
/**
 * 百度统计助手
 * 只支持http协议，不支持https协议
 * 在插件的“设置”里把统计代码最后的那串随机码填入保存即可
 * 如果不开启统计，把填入的随机码清空即可
 * 设置成功后页脚会多出一个百度的小图标
 * 
 * @package 百度统计助手
 * @author 勾三股四
 * @version 1.0.0
 * @link http://jiongks.name/
 */
class BaiduTongji_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->footer = array('BaiduTongji_Plugin', 'render');
    }
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){}
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        /** 统计参数 */
        $inputPn = new Typecho_Widget_Helper_Form_Element_Text('pn', NULL, '', _t('http://hm.baidu.com/h.js?'));
        $form->addInput($inputPn);
    }
    
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    
    /**
     * 插件实现方法
     * 
     * @access public
     * @return void
     */
    public static function render()
    {
        $pn = Typecho_Widget::widget('Widget_Options')->plugin('BaiduTongji')->pn;
        if (strlen($pn) > 0) {
            echo '我是百度统计：<script src="http://hm.baidu.com/h.js?'.$pn.'"></script>';
        }
    }
}
