# Image-Box-Typecho-Plugin
A typecho plugin for Image-Box https://github.com/kirainmoe/Image-Box

## 介绍
一个简单的、基于jQuery的图片灯箱插件。

## 安装方法
Download ZIP, 解压，将其中的 ImageBox 文件夹放入你博客中的 /usr/plugins 目录，在后台启用即可

## 使用方法
一般情况下不需要进行额外的设置，若有需要请至后台参照说明进行调整

## 效果
![demo](https://dn-imjad.qbox.me/Image-Box_demo.png)

## LICENSE

APL © [journey.ad](https://github.com/journey-ad/)
