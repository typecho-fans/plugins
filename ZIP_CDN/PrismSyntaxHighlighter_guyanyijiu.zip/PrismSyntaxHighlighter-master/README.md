# PrismSyntaxHighlighter
一个用于 Typecho 博客系统的基于 prism.js 的语法着色插件

# 安装方式
将代码放在博客项目的 `usr/plugins` 目录里，在后台插件管理中启用即可

# 删除方式
直接从 `usr/plugins` 目录里删除代码即可
