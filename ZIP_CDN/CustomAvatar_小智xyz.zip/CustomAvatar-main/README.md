# 🎨  `CustomAvatar` —— 自定义头像插件 🌟

> 💬 让你的 Typecho 博客评论区更生动，为 **博主** 和 **访客** 自定义专属头像！  
✨ 支持随机头像、固定头像、批量管理，上传即用，简洁高效！
![CustomAvatar](https://socialify.git.ci/xyz66882/CustomAvatar/image?font=Raleway&forks=1&issues=1&name=1&owner=1&pattern=Plus&pulls=1&stargazers=1&theme=Auto)

<p align="center">
  <!-- 创建日期 --><img alt="GitHub Created At" src="https://img.shields.io/github/created-at/xyz66882/CustomAvatar?logo=github&label=%E5%88%9B%E5%BB%BA%E6%97%A5%E6%9C%9F">
  <!-- 下载量 --><a href="https://github.com/xyz66882/CustomAvatar/releases"><img src="https://img.shields.io/github/downloads/xyz66882/CustomAvatar/total?logo=github&label=%E4%B8%8B%E8%BD%BD%E9%87%8F"></a>
  <!-- 贡献者 --><a href="https://github.com/xyz66882/CustomAvatar/graphs/contributors"><img src="https://img.shields.io/github/contributors-anon/xyz66882/CustomAvatar?logo=github&label=%E8%B4%A1%E7%8C%AE%E8%80%85"></a>
  <!-- 最新版本 --><a href="https://github.com/xyz66882/CustomAvatar/releases/"><img src="https://img.shields.io/github/release/xyz66882/CustomAvatar?logo=github&label=%E6%9C%80%E6%96%B0%E7%89%88%E6%AC%A1"></a>
  <!-- 问题数 --><a href="https://github.com/xyz66882/CustomAvatar/issues"><img src="https://img.shields.io/github/issues-raw/xyz66882/CustomAvatar?logo=github&label=%E9%97%AE%E9%A2%98"></a>
  <!-- 讨论数 --><a href="https://github.com/xyz66882/CustomAvatar/discussions"><img src="https://img.shields.io/github/discussions/xyz66882/CustomAvatar?logo=github&label=%E8%AE%A8%E8%AE%BA"></a>
  <!-- 仓库大小 --><a href="https://github.com/xyz66882/CustomAvatar"><img src="https://img.shields.io/github/repo-size/xyz66882/CustomAvatar?logo=github&label=%E4%BB%93%E5%BA%93%E5%A4%A7%E5%B0%8F"></a>
</p>

***

## 📦 插件简介

`CustomAvatar` 是一款专为 Typecho 打造的轻量级头像管理插件。  
告别 Gravatar 的等待与屏蔽，**本地化头像存储**，让评论加载更快、体验更佳！🚀

- ✅ 博主可设「固定头像」或「随机头像」
- ✅ 访客自动分配随机头像（按邮箱哈希）
- ✅ 支持 JPG / PNG / GIF / WEBP 格式
- ✅ 可视化上传、预览、删除、批量操作
- ✅ 防重复分配机制，同一页面不重复
- ✅ 自动缓存 + 清理，性能无忧

***

## ⚙️ 功能详解

### 1️⃣ 博主头像设置

- **固定头像开关** 🔘  
  可开启/关闭，选择是否使用固定头像。
- **选择固定头像** 🖼️  
  从 `bozhu/fixed_pool` 中选择一张作为博主唯一展示头像。
- **博主随机池** 🎲  
  若关闭固定头像，系统将从此目录随机分配（每次刷新可能不同）。

### 2️⃣ 访客头像设置

- **访客随机池** 👥  
  所有未登录访客将根据邮箱哈希值，从此目录中分配一个随机头像。  
  同一用户每次评论看到的头像一致 ✅

### 3️⃣ 头像管理面板 🛠️

- **上传功能** 📤  
  支持多选文件上传，自动重命名避免冲突：  
  `原文件名_YYYYMMDD.扩展名`（如：`小猫.jpg_20250918.jpg`）
- **删除功能** ❌  
  单个删除或批量勾选后一键清除。
- **选择为固定头像** ✅  
  在 `fixed_pool` 中点击按钮，快速设为博主固定头像（需保存设置）。
- **文件名显示优化** 🏷️  
  下拉框中自动去除日期后缀，只显示原始文件名，清爽易选！

***

## 🧹 缓存与性能

- 使用 `$_SESSION` 缓存用户头像映射，确保一致性。
- 页面内防重复：避免同一页面多个评论使用相同头像。
- 文件操作后自动清理缓存，保证即时生效。
- URL 加时间戳防 CDN 缓存，上传即可见 💥

***

## 🔐 安全保障

- 严格路径校验，防止目录穿越。
- MIME 类型检测，杜绝非法文件上传。
- 删除前双重确认，避免误操作。
- 所有文件存于插件私有目录，隔离安全。

***

## 📁 文件结构

````
CustomAvatar/
├── assets/
│   └── avatars/
│       ├── bozhu/               ← 博主随机头像
│       │   └── 小帅_20250918.jpg
│       ├── bozhu/fixed_pool/    ← 博主固定头像候选
│       │   └── 固定头像_20250918.png
│       └── fangke/              ← 访客随机头像
│           ├── 可爱猫.gif_20250918.gif
│           └── 萌兔.webp_20250918.webp
└── Plugin.php
````

***

## 🎁 使用小贴士

- 💡 建议上传 100×100 ~ 200×200 的方形图片，显示更佳。
- 🧼 定期清理不用的头像，保持整洁。
- 🔄 修改设置后记得点击「保存设置」哦！
- 🌈 多上传几张，让评论区更丰富多彩吧！🎉

***

## 🖼️ 效果图预览

<img width="1912" height="1693" alt="6666" src="https://github.com/user-attachments/assets/42cb0fe0-62e9-499e-8b2c-01a1866e9b70" />
<img width="1201" height="774" alt="88" src="https://github.com/user-attachments/assets/ace4f47c-d70a-4bf4-9378-57c831a42077" />


***

## 🙌 致谢

感谢 Typecho 社区 🌱 与所有使用者的支持！  
有任何建议欢迎反馈～我们一起让博客更有趣！💌

> 📢 插件作者：小智xyz  
🔗 官网链接：https://github.com/xyz66882/CustomAvatar
> 
📅 当前版本：`v1.0.5` | 更新日期：2025年9月18日

***

✨ **让每一条评论，都有“脸”可见。** ✨  
👉 立即安装 `CustomAvatar`，开启你的个性化博客之旅吧！🚀🌈

# 🚀 贡献者

<a href="https://github.com/xyz66882/CustomAvatar/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=xyz66882/CustomAvatar" />
</a>
<br /><br />


# ⭐️ 收藏 历史

<a href="https://www.star-history.com/#xyz66882/CustomAvatar&Date">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=xyz66882/CustomAvatar&type=Date&theme=dark" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=xyz66882/CustomAvatar&type=Date" />
   <img alt="Star History Chart" src="https://api.star-history.com/svg?repos=xyz66882/CustomAvatar&type=Date" />
 </picture>
</a>
