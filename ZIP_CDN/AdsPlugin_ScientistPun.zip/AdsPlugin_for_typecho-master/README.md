## 相关说明
### 功能描述
1. 本插件用于博客的广告位管理
2. 提供三种方式的广告位管理，分别为：单图片展示、轮播图和代码块

# 文档
https://doc.koalilab.top/typecho_adsplugin/
