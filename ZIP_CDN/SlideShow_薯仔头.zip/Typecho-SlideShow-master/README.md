# Typecho-SlideShow
根据typecho的热门文章用滑动幻灯片的形式在相应页面展示出来

# 原理
是基于TePostView插件生成热门文章，然后整合carousel.min.js等达到幻灯片滑动播放的效果。

# 食用方法
1. 文件夹命名为`SlideShow` 

2. 在相应的页面/首页需要展示的地方填上 `<?php SlideShow_Plugin::outputSlideShow() ?> `即可

3. 文章需要设置`thumb` 自定义字段，这里需要填写图片地址，要不然会显示不了，出现空白的情况。

   如：自定义字段 thumb ：　https://xxxx.com/bg.png 

# 效果图
![](https://raw.githubusercontent.com/chinobing/Typecho-SlideShow/master/demo.png)

# 网址
展示网站：[薯仔投 - 上市资讯网](https://shuzaitou.com/)

更新网站： [柯西君_BingWong](https://bingwong.org/2019/10/31/Typecho-SlideShow.html)
