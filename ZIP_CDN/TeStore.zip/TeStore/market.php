<?php !defined('__TYPECHO_ROOT_DIR__') and exit();

$response->redirect($options->index . __TYPECHO_ADMIN_DIR__ . 'te-store/market');
