# Typecho Friends Card Plugin

Example: https://blog.indexyz.me/friends.html

## Usage

Create page or archive with

```
# Kugelblitz is the BEST!   <-- remove this line -->
[friends]
{   
    "name": "Event Horizon",
    "descp": "A Certain Scientific Event Horizon",
    "url": "https://blog.kugelblitz.co/", 
    "image": "https://publish.indexyz.me/images/banner-kgblz.png"
}
[/friends]
```
