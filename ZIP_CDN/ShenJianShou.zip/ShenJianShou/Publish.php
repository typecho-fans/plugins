<?php

class Publish extends Typecho_Widget implements Widget_Interface_Do
{
    private $db;
    private $options;

    public function getUserInfo($user)
    {
        $struct = array(
            'user_id' => $user->uid,
            'email' => $user->mail,
            'nickname' => $user->screenName,
            'url' => $user->url,
            'display_name' => $user->screenName,
            'roles' => $user->group
        );
        return $struct;
    }

    public function getAllRelationships()
    {
        //判断目录名是否已经存在
        $db = $this->db;
        $result = $db->query($db->select('cid', 'mid')->from('table.relationships'));
        if ($result) {
            $cidmid = array();
            $resource = $db->fetchAll($result);
            if ($resource) {
                return $resource;
            }
        }
        return false;
    }

    public function getAllCate()
    {
        $categories = null;
        $this->widget('Widget_Metas_Category_List')->to($categories);
        $categories_arr = array();
        if ($categories->have()) {
            $next = $categories->next();
            while ($next) {
                $mid = $next['mid'];
                $catename = $next['name'];
                $count = $next['count'];
                $parentmid = $next['parent'];
                array_push($categories_arr, array($mid, $catename, $count, $parentmid));
                $next = $categories->next();
            }
        }
        return $categories_arr;
    }

    public function getAllTag()
    {
        $tags = null;
        Typecho_Widget::widget('Widget_Metas_Tag_Admin')->to($tags);    //$tags 在进行引用传递
        $diytag = array();
        while ($tags->next()) {
            array_push($diytag, array($tags->mid, $tags->name, $tags->count));
        }
        return $diytag;
    }

    /**
     * @param $cate
     * @param $midNameIndexArr
     * @return bool
     * 通过目录名判断是否已存在
     */
    public function metaCateEixt($cate, $midNameIndexArr)
    {
        foreach ($midNameIndexArr as $m) {
            if ($m[1] == $cate) {
                return $m;
            }
        }
        return false;
    }

    /*
     * 判断$tag是否存在$meta_tags中
     */
    public function tag_exists($tag, $meta_tags)
    {
        foreach ($meta_tags as $t) {
            if ($t[1] == $tag) {
                return $t;
            }
        }
        return false;
    }

    //添加新用户//虚拟库中的用户名
    public function addNewUser($md5author)
    {
        $exitUid = $this->userNameExit($md5author);
        if (!$exitUid) {
            $hasher = new PasswordHash(8, true);
            $randString6 = Typecho_Common::randString(6);
            $user = array(
                'name' => $md5author,
                'url' => '',
                'group' => 'contributor',
                'created' => $this->options->gmtTime,
                'password' => $randString6
            );
            $user['screenName'] = empty($user['screenName']) ? $user['name'] : $user['screenName'];
            $user['password'] = $hasher->HashPassword($user['password']);
            $authCode = function_exists('openssl_random_pseudo_bytes') ? bin2hex(openssl_random_pseudo_bytes(16)) : sha1(Typecho_Common::randString(20));
            $user['authCode'] = $authCode;
            /** 插入数据 */
            try {
                $insertId = $this->db->query($this->db->insert('table.users')->rows($user));
            }catch (Exception $e){
                ta_fail(TA_ERROR_ERROR,"user insert failed","插入用户失败");
            }
            if ($insertId) {
                return $insertId;
            }
        } else {
            return $exitUid;
        }
        return false;
    }

    //判断用户名是否存在
    public function userNameExit($md5author)
    {
        $user = $this->db->fetchRow($this->db->select('uid')->from('table.users')->where('name = ?', $md5author)->limit(1));
        $uid = $user["uid"];
        if ($uid) {
            return $uid;
        } else {
            return false;
        }
    }

    /**
     * @param     $authorId
     * @param     $post_id
     * @param     $pub_time
     * @param     $content
     * @param     $authorName
     * @param int $parent_id
     * @return bool
     */
    public function insertComments($authorId, $post_id, $pub_time, $content, $authorName, $parent_id = 0)
    {
        /**
         * 通过文章id找到对应的作者id
         */
        $post = $this->db->fetchRow($this->db->select('authorId', 'commentsNum')->from('table.contents')->where('cid = ?', $post_id)->limit(1));
        $ownerId = $post["ownerId"];
        $commentsNum = $post['commentsNum'];
        if (!$ownerId) {
            $ownerId = 1;
        }
        $comment = array(
            'cid' => $post_id,
            'created' => $pub_time,
            'agent' => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10 (.NET CLR 3.5.30729)',
            'ip' => ta_random_ip(),
            'ownerId' => $ownerId,
            'authorId' => $authorId,
            'type' => 'comment',
            'author' => $authorName,
            'mail' => '12313@qq.com',
            'url' => 'http://www.baidu.com',
            'parent' => $parent_id,
            'text' => $content,
            'status' => 'approved'
        );
        try{
            $commentId = $this->db->query($this->db->insert('table.comments')->rows($comment));
        }catch (Exception $e){
            ta_fail(TA_ERROR_CHARSET,$e->getMessage(),"插入评论失败，该评论内容中存在emoji等特殊字符，请将comments表的text字段编码设置为 utf8mb4 后再进行发布");
        }
        //更新文章评论数
        $this->db->query($this->db->update('table.contents')->rows(array('commentsNum' => $commentsNum + 1, 'parent' => $parent_id))->where('cid = ?', $post_id));
        if ($commentId) {
            return $commentId;
        }
        return false;
    }

    public function getPostUrl($index_url, $cid, $slug, $category, $time)
    {
        $today = date("Y-m-d", $time);
        $todayArr = explode('-', $today);
        $year = $todayArr[0];
        $month = $todayArr[1];
        $day = $todayArr[2];
        $rule = Typecho_Widget::widget('Widget_Options')->routingTable['post']['url'];
        $rule = preg_replace("/\[([_a-z0-9-]+)[^\]]*\]/i", "{\\1}", $rule);
        $part_url = str_replace(array('{cid}', '{slug}', '{category}', '{directory}', '{year}', '{month}', '{day}', '{mid}'),
            array($cid, $slug, $category, '[directory:split:0]',
                $year, $month, $day, 1), $rule);
        $part_url = ltrim($part_url, '/');
        $siteurl = $index_url;
        if (!Typecho_Widget::widget('Widget_Options')->rewrite) {
            $siteurl = $siteurl . 'index.php/';
        }
        $post_url = $siteurl . $part_url;
        return $post_url;
    }

    public function action()
    {
        include_once "CommonBiz.php";
        // 报告 E_NOTICE 之外的所有错误
        error_reporting(E_ALL & ~E_NOTICE);
        $this->db = Typecho_Db::get();
        $wpdb = $this->db;
        $request_data = mergeRequest();
        if ($_GET["__ta"] == "post") {
            $this->verifyPassword($request_data['__sign']);

            $title = $request_data["article_title"];
            $content = $request_data["article_content"];
            if (empty($content) && empty($title)) {
                ta_fail(TA_ERROR_MISSING_FIELD, "article_content and article_title are both empty", "文章内容和标题不能都为空");
            }
            /**
             * 直接发布还是存为草稿
             */
            $postStatus = 'publish';
            if (isset($request_data["postStatus"]) && in_array($request_data["postStatus"], array('publish', 'post_draft'))) {
                $postStatus = $request_data["postStatus"];
            }
            /**
             * 文章访问密码
             */
            $postPassword = NULL;
            if (isset($request_data["accessword"]) && $request_data["accessword"]) {
                $postPassword = $request_data["accessword"];
            }
            if (!empty($title)) {
                $title = htmlspecialchars_decode($title);
            }
            if (!empty($content)) {
                $content = "<!--markdown-->" . htmlspecialchars_decode($content);
            }
            /**
             * 是否允许评论
             */
            if (!isset($request_data['allowComment'])) {
                $request_data['allowComment'] = 1;
            }
            $index_url = Helper::options()->siteUrl;
            /**
             * 标题去重判断
             */
            $ta_unique = Typecho_Widget::widget('Widget_Options')->plugin('ShenJianShou')->duplicate;
            if (!is_null($ta_unique) && !empty($title)) {
                $post = $wpdb->fetchRow($wpdb->select()->from('table.contents')->where('title = ?', $title));
                if ($post) {
                    $postId = $post['cid'];
                    $relationships = $wpdb->fetchAll($wpdb->select()->from('table.relationships')->where('cid = ?', $postId));
                    $re = array_pop($relationships);
                    $cate = $wpdb->fetchRow($wpdb->select()->from('table.metas')->where('mid = ?', $re['mid']));
                    $lastCategory = $cate['name'];
                    $slug = $post['slug'];
                    $time = $post['created'];
                    $post_url = $this->getPostUrl($index_url, $postId, $slug, $lastCategory, $time);
                    ta_success(array("url" => $post_url));
                }
            }
            /**
             * 发布时间
             */
            $publish_time = Helper::options()->gmtTime;
            if (!empty($request_data["article_publish_time"])) {
                $time = $request_data["article_publish_time"];
                if (preg_match('/\d{10,13}/', $time)) {
                    $time = intval($time);
                } else {
                    $time = intval(strtotime($time));
                }
//                    $publish_time = date("Y-m-d H:i:s", intval($request_data["article_publish_time"]));
                $publish_time = $time;
            }
            /**
             * 用户存在性质判断
             */
            $authorId = 1;
            $author = htmlspecialchars_decode($request_data["article_author"]);
            if (!empty($author)) {
                if ($author == "author_existing_users") {
                    $users = null;
                    Typecho_Widget::widget('Widget_Users_Admin')->to($users);   //$users 在进行引用传递
                    $uid = array();
                    while ($users->next()) {
                        $uid[] = $users->uid;
                    }
                    $index = rand(1, count($uid));
                    $user_id = $uid[$index];
                } else if ($author == "author_web_master") {
                    $user_id = 1;
                } else {
                    //添加虚拟用户
                    $md5author = substr(md5($author), 8, 16);
                    $user_id = $this->addNewUser($md5author);
                }
                if ($user_id) {
                    $authorId = $user_id;
                }
            }
            /**执行添加文章操作
             * 构建插入结构
             */
            $insertStruct = array(
                'title' => !isset($title) ? '' : $title,
                'created' => $publish_time,
                'modified' => time(),
                'text' => !isset($content) ? '' : $content,
                'order' => empty($request_data['order']) ? 0 : intval($request_data['order']),
                'authorId' => $authorId,
                'template' => empty($request_data['template']) ? NULL : $request_data['template'],
                'type' => !isset($request_data['type']) ? 'post' : $request_data['type'],
                'status' => $postStatus,
                'password' => $postPassword,
                'commentsNum' => 0,
                'allowComment' => !empty($request_data['allowComment']) && 0 == $request_data['allowComment'] ? 0 : 1,
                'allowPing' => !empty($request_data['allowPing']) && 1 == $request_data['allowPing'] ? 1 : 0,
                'allowFeed' => !empty($request_data['allowFeed']) && 1 == $request_data['allowFeed'] ? 1 : 0,
                'parent' => empty($request_data['parent']) ? 0 : intval($request_data['parent'])
            );
            try {
                $post_id = $wpdb->query($wpdb->insert('table.contents')->rows($insertStruct));
            }catch (Exception $e){
                ta_fail(TA_ERROR_CHARSET,$e->getMessage(),"文章插入失败，该文章内容中存在emoji等特殊字符，请将contents表的text字段编码改成 utf8mb4 再进行发布");
            }
            /** 更新缩略名 */
            $slug = $post_id;
            if ($post_id > 0) {
                $randSlug = Typecho_Common::randString(6);
                $slug = empty($request_data['slug']) ? $randSlug : $request_data['slug'];
                $slug = Typecho_Common::slugName($slug, $post_id);
                $this->db->query($this->db->update('table.contents')->rows(array('slug' => $slug))
                    ->where('cid = ?', $post_id));
            } else {
                ta_fail(TA_ERROR_ERROR, "Empty Post ID", "插入系统失败");
            }
            /**
             * 文章分类
             */
            $article_categories = $request_data["article_categories"];
            $lastCategory = "default";
            if (!empty($article_categories)) {
                //所有文章，包括分类名自字段
                $posts = Typecho_Widget::widget('Widget_Contents_Post_Admin');
                $rawCates = stripslashes($article_categories);//去掉html中来的\
                $cates = json_decode($rawCates);
                if (is_array($cates)) {
                    $cates = array_unique($cates);
                    //获得所有的目录id=>名称
                    $midNameIndexArr = $this->getAllCate();
                    $first_catemid = null;
                    for ($c = 0; $c < count($cates); $c++) {
                        $lastCategory = $cates[$c];
                        //判断目录是否存在，如果不存在就创建一个
                        $meta_cate = $this->metaCateEixt($cates[$c], $midNameIndexArr);
                        $cate_id = $meta_cate[0];
                        if (!$meta_cate) {
                            //创建一个目录
                            $cate_id = $wpdb->query($wpdb->insert('table.metas')
                                ->rows(array(
                                    'name' => $cates[$c],
                                    'slug' => Typecho_Common::slugName($cates[$c]),
                                    'type' => 'category',
                                    'count' => 1,
                                    'order' => 1,
                                    'parent' => 0
                                )));
                        } else {
                            //更新目录使用数
                            $update = $wpdb->update('table.metas')->rows(array('count' => ($meta_cate[2] + 1)))->where('mid=?', $meta_cate[0]);
                            $updateRows = $wpdb->query($update);
                        }
                        if(is_null($first_catemid)){
                            $first_catemid = $cate_id;
                        }
                    }
                    try {
                        //关联分类和文章
                        $wpdb->query($wpdb->insert('table.relationships')->rows(array('cid' => $post_id, 'mid' => $first_catemid)));
                    }catch (Exception $e){
                        ta_fail(TA_ERROR_ERROR,array($post_id,$first_catemid),$e->getMessage());
                    }
                }
            } else {
                //获得所有的目录id=>名称
                $midNameIndexArr = $this->getAllCate();
                $lastCategory = $midNameIndexArr[0][1];
                $defaultMid = $midNameIndexArr[0][0];
                $lastrelation = $wpdb->query($wpdb->insert('table.relationships')
                    ->rows(array(
                        'cid' => $post_id,
                        'mid' => $defaultMid
                    )));
            }
            /**
             * 文章标记
             */
            $article_topics = $request_data["article_topics"];
            if (!empty($article_topics)) {
                $rawTags = stripslashes($article_topics);
                $tags = json_decode($rawTags);
                if (is_array($tags)) {
                    //最好能过滤一下重复的$tags;
                    $newtagmidarr = array();
                    $meta_tags = $this->getAllTag();
                    foreach ($tags as $tag) {
                        $meta_tag = $this->tag_exists($tag, $meta_tags);
                        if (!$meta_tag) {
                            //执行插入一个新的tag
                            $lastInsertTagMid = $wpdb->query($wpdb->insert('table.metas')
                                ->rows(array(
                                    'name' => $tag,
                                    'slug' => Typecho_Common::slugName($tag),
                                    'type' => 'tag',
                                    'count' => 1,
                                    'order' => 0,
                                    'parent' => 0
                                )));
                            array_push($newtagmidarr, $lastInsertTagMid);
                        } else {
                            array_push($newtagmidarr, $meta_tag[0]);
                            $update = $wpdb->update('table.metas')->rows(array('count' => ($meta_tag[2] + 1)))->where('mid=?', $meta_tag[0]);
                            $updateRows = $wpdb->query($update);
                        }
                        //创建目录和标记的关系
                        foreach ($newtagmidarr as $mid) {
                            $lastrelation = $wpdb->query($wpdb->insert('table.relationships')
                                ->rows(array(
                                    'cid' => $post_id,
                                    'mid' => $mid
                                )));
                        }
                    }
                }
            }
            /**
             * 插入文章评论
             */
            $comment_json = preg_replace("/[\r\n\t]/", '', $request_data['article_comment']);
            $article_comment = json_decode($comment_json, true);
            if ($post_id && is_array($article_comment)) {
                foreach ($article_comment as $comment) {
                    //如何判断这个$comment是否具有子评论呢？
                    $comment_content = $comment["article_comment_content"];
                    if (!empty($comment_content)) {
                        //内容不是空
                        $pub_time = $comment["article_comment_publish_time"];
                        if (empty($pub_time)) {
                            $pub_time = time();
                        }
                        $cauthor = $comment["article_comment_author"];
                        //直接增加一个虚拟
                        if (!empty($cauthor)) {
                            $cmd5author = substr(md5($cauthor), 8, 16);
                            try {
                                $cuser_id = $this->addNewUser($cmd5author);
                            } catch (Exception $e) {
                                $cuser_id = 0;
                            }
                        } else {
                            $cuser_id = 0;
                            $cauthor = 'Typecho';
                        }
                        $this->insertComments($cuser_id, $post_id, $pub_time, $comment_content, $cauthor, $parent_id = 0);
                    }
                }
            }
            $post_url = $this->getPostUrl($index_url, $post_id, $slug, $lastCategory, $insertStruct['created']);
            ta_success(array("url" => $post_url));
        } else if ($_GET["__ta"] == "details") {
            $this->verifyPassword($request_data['__sign']);
            $categories = $this->getAllCate();
            $cates = [];
            foreach ($categories as $category){
                array_push($cates,array(
                    'mid'=>$category[0],
                    'value'=>$category[1],
                    'text'=>$category[1],
                    'count'=>$category[2],
                    'parent_mid'=>$category[3]
                ));
            }
            ta_success($cates);
        } else if ($_GET["__ta"] == "version") {
            ta_success(array("os"=>PHP_OS,"phpVersion"=>PHP_VERSION,"typechoVersion"=>$this->options->Version,"plugVersion"=>"1.0.3"));
        } else if ($_GET["__ta"] == "refer") {
            //图片转发逻辑
            $url = urldecode($_GET["url"]);
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            $img = curl_exec($ch);
            curl_close($ch);
            header("Content-type: image/jpeg");
            die($img);
        } else {
            ta_success(array("url" => '插件安装合适'));
        }
    }

    public function verifyPassword($sign){
        $this->options = Typecho_Widget::widget('Widget_Options')->plugin('ShenJianShou');
        if(empty($sign) || $sign != $this->options->publish_password){
            ta_fail(TA_ERROR_INVALID_PWD, "password is wrong", "发布密码验证错误");
        }
    }
}