<?php

/**
 * 神箭手数据发布插件<Br />由<a href="https://www.wamuban.com" title="挖模板 收集网站模板">挖模板</a>整理收集
 * @package ShenJianShou
 * @author 神箭手云
 * @version 4.2.4
 * @link http://www.shenjian.io/
 *
 * 历史版本
 * version 1.0.0 at 2017-6-15
 * 修正Typecho 1.0下数组不能直接使用[]的BUG
 */
class ShenJianShou_Plugin implements Typecho_Plugin_Interface
{
    public static $plug_version = "4.2.4";
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     *
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('index.php')->begin = array('ShenJianShou_Plugin', 'post');
    }

    public static function post()
    {
        $uri = $_SERVER['REQUEST_URI'];
        if(strpos($uri,"sjs-data?__ta=") !== false){
            require_once ( __DIR__."/Publish.php");
            $publish = @new Publish(Typecho_Request::getInstance(),Typecho_Response::getInstance());
            $publish->action();
        }
    }
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     *
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate()
    {
//        Helper::removeRoute("sjs_data");
        Helper::removeAction("sjs-data");
    }

    /**
     * 获取插件配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        /**
         * 发布网址
         */

        $index_url = Helper::options()->siteUrl;
        $pattern = "/.*192\.168\.\d{1,3}.\d{1,3}.*/";
        $publish_url_label = new Typecho_Widget_Helper_Layout("label", array(
            'class' => 'typecho-label',
            'style' => 'margin-top:50px;'
        ));
        $publish_url_label->html('您网站发布地址');
        $publish_url = new Typecho_Widget_Helper_Layout("input",
            array(
                "disabled" => true,
                "readOnly" => true,
                "value" => $index_url,
                'type' => 'text',
                'class' => 'text',
                'style' => "width:100%;height:100%;"
            )
        );

        $rootDiv = new Typecho_Widget_Helper_Layout();

        $urldiv = new Typecho_Widget_Helper_Layout();
        $urldiv->setAttribute('class', 'typecho-option');
        $publish_url_label->appendTo($urldiv);
        $publish_url->appendTo($urldiv);
        if (preg_match($pattern, $index_url)) {
            $publish_url_p = new Typecho_Widget_Helper_Layout('p', array(
                'class' => "description"
            ));
            $publish_url_p->html("(当前页面是通过内网访问，无法获取当前公网IP或域名，神箭手不支持发布到内网，请切换至外部网络获取网站发布地址)");
            $publish_url_p->appendTo($publish_url);
        }
        $form->addItem($urldiv);

        $publish_password = new Typecho_Widget_Helper_Form_Element_Text('publish_password', null, 'shenjian.io', _t('发布密码'), "(建议修改成自己的常用密码，并填入神箭手后台 typecho 发布选项中的发布密码输入框内, 请勿使用特殊字符或汉字)");

        /**
         *  标题去重选项
         */
        $duplicateOptions = array(
            'no_duplicate' => _t('是否标题去重<span style="font-size: 12px;color: #999;">（不重复插入相同标题）</span>')
        );
        $duplicateOptionsValue = array('no_duplicate');
        $is_title_to_no_duplicate = new Typecho_Widget_Helper_Form_Element_Checkbox('duplicate', $duplicateOptions,
            $duplicateOptionsValue, _t('标题去重'));

        $form->addInput($publish_password);
        $form->addInput($is_title_to_no_duplicate->multiMode());

        /**
         * 底部说明
         */
        $explain_layout = new Typecho_Widget_Helper_Layout();
        $info_one_p = new Typecho_Widget_Helper_Layout('span', array(
            'style' => "floal:left;display:block;clear:left;margin-top:20px;"
        ));
        $info_one_p->html("说明：");
        $info_one_ul = new Typecho_Widget_Helper_Layout('ul');
        $info_one_ul->setAttribute('class', 'typecho-option');
        $info_one_li0 = new Typecho_Widget_Helper_Layout('li');
        $info_one_li0->setAttribute('class', 'description')->html('神箭手typecho数据发布插件，可以将神箭手上爬虫采集的数据、购买的数据、导入的数据、清洗后的数据、机器学习的数据等一键发布到该网站。只需要简单的配置即可实现自动化批量发布，功能丰富强大！');
        $info_one_li1 = new Typecho_Widget_Helper_Layout('li');
        $info_one_li1->setAttribute('class', 'description')->html('1、数据采集爬取请在神箭手官网操作（<a href="http://docs.shenjian.io/overview/guide/collect.html">如何爬取数据</a>），采集的数据可以通过该插件发布到wp网站');


        $info_one_li2 = new Typecho_Widget_Helper_Layout('li');
        $text = '2、神箭手<a href="http://www.shenjian.io/index.php?r=market/productList">大数据市场</a>内有很多热门网站的爬虫（包括'.
            ' <a href="http://www.shenjian.io/index.php?r=market/search&keyword=%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7">微信公众号文章采集</a>、 '.
            ' <a href="http://www.shenjian.io/index.php?r=market/search&keyword=%E5%BE%AE%E5%8D%9A">微博采集</a>、'.
            ' <a href="http://www.shenjian.io/index.php?r=market/search&keyword=%E4%BB%8A%E6%97%A5%E5%A4%B4%E6%9D%A1">今日头条采集</a>、'.
            ' <a href="http://www.shenjian.io/index.php?r=market/search&keyword=%E7%BE%8E%E5%9B%A2">美团采集、'.
            ' <a href="http://www.shenjian.io/index.php?r=market/search&keyword=%E6%B7%98%E5%AE%9D">淘宝</a>等电商采集等），您可以免开发直接使用';
        $info_one_li2->setAttribute('class', 'description')->html($text);
        $info_one_ul->addItem($info_one_li0);
        $info_one_ul->addItem($info_one_li1);
        $info_one_ul->addItem($info_one_li2);

        $version = new Typecho_Widget_Helper_Layout('span');
        $version->html("当前版本： <a href='http://www.shenjian.io/index.php?r=index/download'>" . self::$plug_version . "</a>");

        $tech = new Typecho_Widget_Helper_Layout('span', array(
            'style' => "float:right;clear:right;display:inline-block;"
        ));
        $tech->html("相关教程：<a href='http://docs.shenjian.io/overview/guide/pub.html'>如何发布数据</a>");

        $explain_layout->addItem($version);
        $explain_layout->addItem($tech);

        $explain_layout->addItem($info_one_p);
        $explain_layout->addItem($info_one_ul);

        $form->addItem($explain_layout);
        $form->appendTo($rootDiv);

    }

    /**
     * 个人用户的配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form)
    {
    }

}
