# LaTeXTypecho
Typecho的LaTeX支持插件

Beta Version

用mathjax进行渲染
