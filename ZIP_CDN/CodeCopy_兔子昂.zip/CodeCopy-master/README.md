# CodeCopy

## 介绍

这是一个 用于Typecho的 复制代码 的插件

<a href="https://www.tuziang.com/combat/1800.html">CodeCopy —— 用于Typecho 复制代码 插件 - 兔子昂</a>

<img src="https://www.tuziang.com/usr/uploads/2019/04/558354113.gif" />

## 使用教程

1. Download ZIP 下载本插件
2. 解压，把 CodeCopy-master 目录重命名为 CodeCopy (注意大写) 上传至博客的 /usr/plugins 目录下
3. 在插件页面启用本插件
