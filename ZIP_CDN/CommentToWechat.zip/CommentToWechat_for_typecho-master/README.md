## 功能

借助 server酱 实现评论（typecho原生评论）实时推送到微信。

> 「[Server酱][1]」，英文名「ServerChan」，是一款「程序员」和「服务器」之间的通信软件。
> 
> 说人话？就是从服务器推报警和日志到手机的工具。

## 配置

1. 首先到[Server酱][1]绑定微信并获取到 SCKEY

2. 在后台插件配置中填写 SCKEY

## 安装

[下载文件][2]，解压后请将文件夹**重命名**为CommentToWechat。再上传至`usr/plugins/下`。

## 演示


![IMG_0844.PNG][3]


  [1]: http://sc.ftqq.com/3.version
  [2]: https://github.com/lscho/CommentToWechat_for_typecho/archive/master.zip
  [3]: https://static.lscho.com/usr/uploads/2017/03/2176765394.png
