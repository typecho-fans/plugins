<?php
header('Content-Type: text/html; charset=UTF-8');

define( "WB_AKEY" , '1642726886' );
define( "WB_SKEY" , 'e99a05edc476cf35b4a31b631f54b2a9' );
define( "WB_CALLBACK_URL" , 'https://typecodes.com/weibo' );
