<?php
//请不要修改本文件，以免检查更新失败
define('Article_Poster_Service_Version','1.0.0');
?>