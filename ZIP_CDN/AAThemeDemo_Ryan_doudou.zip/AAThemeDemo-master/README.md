# AAThemeDemo
来自于 doudou 的 ThemeDemo2 插件。

ThemeDemo2 插件是不兼容 Typecho 1.2 的，所以我迁移到 Typecho 1.2，采用新的便携方式，不兼容老版本的 Typecho，并改名 AAThemeDemo 用于甄别。

## License

Copy as you want.