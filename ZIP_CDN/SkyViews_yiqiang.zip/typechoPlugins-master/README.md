# typecho插件集

|名称|链接|备注|
|-|-|-|
|文章浏览量|[点击下载](https://github.com/yiqiangking/typechoPlugins/releases/download/1.0.0/SkyViews.rar)|在post.php中需要显示的地方加入`<?php $this->views(); ?>`|
