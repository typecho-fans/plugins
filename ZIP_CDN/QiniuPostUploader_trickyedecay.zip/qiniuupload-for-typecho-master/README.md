# qiniuupload-for-typecho
typecho 插件 - 上传文件到七牛

# 使用方法
1. 下载所有文件并把所有文件放在名为 **QiniuPostUploader** 的文件夹内
2. 将上述文件夹放在typecho的插件目录即可
3. 在typecho后台启用插件
4. 进行设置相关就可以使用啦

# 依赖
在这个插件里面依赖了部分js插件:

1. jquery (这个插件中没有自行引入)
2. moxie.js
3. plupload.js
4. qiniu.js
5. font-awesome.css
6. ZeroClipboard.js
(如果产生冲突可以从代码中移除相关引入)
