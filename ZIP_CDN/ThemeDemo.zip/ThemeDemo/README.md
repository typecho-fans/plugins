## 插件说明 ##

此插件为Typecho主题演示插件，基于cookie记忆所选主题，使用方法如下：

切换成 xx 主题:

    任意URL + ?theme=xx

恢复默认主题: (提交参数theme为空)

    任意URL + ?theme
