# UrlSpam
[![](https://data.jsdelivr.com/v1/package/gh/soxft/Urlspam/badge)](https://www.jsdelivr.com/package/gh/soxft/Urlspam)
<a href="http://www.apache.org/licenses/LICENSE-2.0.html"> 
<img src="https://img.shields.io/github/license/soxft/UrlSpam.svg" alt="License"></a>
<a href="https://github.com/soxft/UrlSpam/stargazers"> 
<img src="https://img.shields.io/github/stars/soxft/UrlSpam.svg" alt="GitHub stars"></a>
<a href="https://github.com/soxft/UrlSpam/network/members"> 
<img src="https://img.shields.io/github/forks/soxft/UrlSpam.svg" alt="GitHub forks"></a> 

A typecho plugin which can prevent you from receive spam comments
## 介绍
1.一款防止垃圾评论的插件,支持通过调用腾讯网址检测api来防止垃圾网站评论。<br />
2.支持垃圾评论telegram bot推送.
## 使用
下载本仓库后解压至 /usr/plugins文件夹并重命名为`UrlSpam`
