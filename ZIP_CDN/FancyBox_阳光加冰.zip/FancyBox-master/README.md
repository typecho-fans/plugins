# FancyBox


## Introduction

一个简单的typecho图片灯箱插件

## Features

- 自动解析
- 自定义过滤标签

## Usage

下载本插件到typecho插件目录然后启用即可

## LICENSE
GPL2.0(懒得改你们就当MIT吧)





