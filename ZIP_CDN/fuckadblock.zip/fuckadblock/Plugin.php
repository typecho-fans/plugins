<?php
/**
 * 一款反广告过滤插件的插件,基于fuckadblock.js（https://fuckadblock.sitexw.fr/）的3.2.1版本制作
 * 
 * @package FuckAdBlock
 * @author 泽泽社长
 * @version 3.2.1
 * @link http://qqdie.com/
 */
class fuckadblock_Plugin implements Typecho_Plugin_Interface
{ 
 public static function activate()
	{
        Typecho_Plugin::factory('Widget_Archive')->footer = array('fuckadblock_Plugin', 'footer');
    }
	/* 禁用插件方法 */
	public static function deactivate(){}
    public static function config(Typecho_Widget_Helper_Form $form){

$jinggao = new Typecho_Widget_Helper_Form_Element_Textarea('jinggao', NULL, 
'',_t('自定义警告脚本'), _t('默认为<code>alert("请针对本站关闭广告过滤插件谢谢！");<code>'));
        $form->addInput($jinggao);
    }
    
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    public static function footer(){
if(Helper::options()->plugin('fuckadblock')->jinggao){
$jingshi=Helper::options()->plugin('fuckadblock')->jinggao;
}else{
$jingshi='alert("请针对本站关闭广告过滤插件谢谢！");';
}
                                    
?>
<script>
function adBlockNotDetected() {
}
function adBlockDetected() {
<?php echo $jingshi; ?>
}
if(typeof fuckAdBlock !== 'undefined' || typeof FuckAdBlock !== 'undefined') {
adBlockDetected();
} else {
var importFAB = document.createElement('script');
importFAB.onload = function() {
fuckAdBlock.onDetected(adBlockDetected)
fuckAdBlock.onNotDetected(adBlockNotDetected);
};
importFAB.onerror = function() {
adBlockDetected(); 
};
importFAB.integrity = 'sha256-xjwKUY/NgkPjZZBOtOxRYtK20GaqTwUCf7WYCJ1z69w=';
importFAB.crossOrigin = 'anonymous';
importFAB.src = 'https://cdn.bootcss.com/fuckadblock/3.2.1/fuckadblock.min.js';
document.head.appendChild(importFAB);
}
</script>
 <?php
    }

}
