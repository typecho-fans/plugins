<?php
	if(!isset($_FILES))	die(json_encode(array('code'=> '404')));
	include_once './ftp.php';
	$config = array('hostname' => $_GET['domain'],'username' => $_GET['username'],'password' => $_GET['password'],'port' => $_GET['port']);

	$document = $_GET['folder'];
	$file = $document.date('Y-m-d-H-i').urlencode($_FILES['file']['name']);
	$url = (substr($_GET['domain'], 0, 7) != 'http://') ? 'http://'.$_GET['domain'] : $_GET['domain'];
	$url .= '/'.$file;
	
	$ftp = new Ftp();
	$ftp->connect($config);
	$list = $ftp->filelist();
	$res = $ftp->upload($_FILES['file']['tmp_name'], $file);
	if($res) echo json_encode(array('code' => '200', 'url' => $url));
?>
