<?php
/**
 * FTP上传插件
 *
 * @package FtpUpload
 * @version 1.0
 * @author 怡红公子
 * @link http://zh.eming.li/#ftpupload
 */
 
 class FtpUpload_Plugin implements Typecho_Plugin_Interface {

    /**
     * 插件版本号
     * @var string
     */
    const _VERSION = '1.0';

    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     *
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate() {
		Typecho_Plugin::factory('admin/write-post.php')->richEditor = array('FtpUpload_Plugin', 'Insert');
		Typecho_Plugin::factory('admin/write-page.php')->richEditor = array('FtpUpload_Plugin', 'Insert');
    }

	public static function Insert() {
		$options         = Helper::options();
		$config          = $options->plugin('FtpUpload');
        $cssUrl          = Typecho_Common::url('FtpUpload/style.css' , $options->pluginUrl);
        $uploadUrl		 = Typecho_Common::url('FtpUpload/up.php' , $options->pluginUrl);
        $uploadJs		 = Typecho_Common::url('FtpUpload/up.js', $options->pluginUrl);

        echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"{$cssUrl}\" />";
?>
		<script type="text/javascript" src="http://lib.sinaapp.com/js/jquery/1.9.1/jquery-1.9.1.min.js"></script>
		<script type="text/javascript">
			textEditor = document.getElementById('text');
			textEditor.setContent = function(text, id) {
				 //IE support
				  if (document.selection) {
				    textEditor.focus();
				    sel = document.selection.createRange();
				    sel.text = text;
				    sel.select();
				  }
				  //MOZILLA/NETSCAPE support
				  else if (textEditor.selectionStart || textEditor.selectionStart == '0') {
				    var startPos = textEditor.selectionStart;
				    var endPos = textEditor.selectionEnd;
				    // save scrollTop before insert
				    var restoreTop = textEditor.scrollTop;
				    textEditor.value = textEditor.value.substring(0, startPos) + text + textEditor.value.substring(endPos, textEditor.value.length);
				    if (restoreTop > 0) {
				      // restore previous scrollTop
				      textEditor.scrollTop = restoreTop;
				    }
				    textEditor.focus();
				    textEditor.selectionStart = startPos + text.length;
				    textEditor.selectionEnd = startPos + text.length;
				  } else {
				    textEditor.value += text;
				    textEditor.focus();
				  }
			}
		    /** 这两个函数在插件中必须实现 */
		    var insertImageToEditor = function (title, url, link, cid) {
		        textEditor.setContent('<a href="'+link+'" title="'+title+'"><img src="'+url+'" alt="'+title+'" /></a>', '');
		    };
		    
		    var insertLinkToEditor = function (title, url, link, cid) {
		        textEditor.setContent('<a href="' + url + '" title="' + title + '">' + title + '</a>', '');
		    };
		</script>
		<script type="text/javascript">
		jQuery.noConflict();
		jQuery('#text').before('<a href=\"#\" id=\"UploaderTool\" style=\"font-size:14px;font-weight:bold;\">插入文件</a>');
		jQuery('#UploaderTool').click(function() {
			if(jQuery('#Upload').length != 0)	return false;
			jQuery('body').append('<div id=\"Upload\"></div>');
			jQuery('#Upload').html('<form action=\"<?php echo $uploadUrl; ?>?domain=<?php echo $config->domain; ?>&username=<?php echo $config->username; ?>&password=<?php echo $config->password; ?>&port=<?php echo $config->port; ?>&folder=<?php echo $config->folder; ?>\" target=\"fileUpLoadIframe\" method=\"post\" id=\"FtpUploadForm\" enctype=\"multipart/form-data\"><input type=\"file\" name=\"file\" id=\"file\" value=\"\" /><div id=\"FtpBtn\" onclick="up();">上传</div></form><div class=\"close\" onclick=\"jQuery(\'#Upload\').remove();\">X</div>');
		});
		function up() {
			var form = jQuery('#FtpUploadForm'), IFRAME_NAME = form.attr('target'), IFRAME = '<iframe name="'+IFRAME_NAME+'" id="'+IFRAME_NAME+'" style="display:none"><iframe>';
			if(jQuery('#'+IFRAME_NAME).length != 0) jQuery('#'+IFRAME_NAME).remove();
			jQuery('#Upload').append(IFRAME);
			jQuery('#'+IFRAME_NAME).load(function() {
				var response = jQuery(this)[0].contentWindow.document.body.innerHTML, d = jQuery.parseJSON(response);
				if(d.code == '200') {
					jQuery('#Upload').remove();
					var t = '<a href="'+d.url+'" target="_blank" title=""><img src="'+d.url+'" alt="" /></a>';
					jQuery('#text').val(jQuery('#text').val()+t);
					editor(t);
				}
			});
			form.submit();
		}
		function editor(c) {
			if (window.frames.length > 0) {
				if (fck = window.frames['text___Frame']) var _c = fck.document.getElementsByTagName('iframe')[0].contentDocument.body;
				else if (mce = window.frames['text_ifr']) var _c = mce.document.body;
				else if (kin = document.getElementsByClassName('ke-edit-iframe')[0]) var _c = kin.contentDocument.body;
				else if (cke = document.getElementsByClassName('cke_wysiwyg_frame')[0]) var _c = cke.contentDocument.body;
				_c.innerHTML = _c.innerHTML + c
			}
		}
		//jQuery('body').on('keydown', '#FtpBtn', function(e){	if(jQuery(this).is(':focus') && jQuery(this).val() != '' && e.keyCode == '13') search();});
		</script>
<?php
    }

    /**
     * 插件配置面板
     *
     * @param Typecho_Widget_Helper_Form $form
     * @static
     * @access public
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form) {
	    $domain = new Typecho_Widget_Helper_Form_Element_Text('domain', NULL, NULL, _t('服务器'), _t('FTP IP地址，可以是域名'));
	    $form->addInput($domain->addRule('required', _t('服务器地址是必须填写的')));

	    $username = new Typecho_Widget_Helper_Form_Element_Text('username', NULL, NULL, _t('用户名'), NULL);
	    $form->addInput($username->addRule('required', _t('用户名是必须填写的')));

	    $password = new Typecho_Widget_Helper_Form_Element_Password('password', NULL, NULL, _t('密码'), NULL);
	    $form->addInput($password->addRule('required', _t('密码是必须填写的')));

	    $port = new Typecho_Widget_Helper_Form_Element_Text('port', NULL, '21', _t('端口'), _t('一般为21'));
	    $form->addInput($port->addRule('required', _t('端口号是必须填写的')));

	    $folder = new Typecho_Widget_Helper_Form_Element_Text('folder', NULL, './', _t('上传位置'), _t('请填写文件上传的位置，默认是根目录，填写的文件夹请务必存在'));
	    $form->addInput($folder->addRule('required', _t('上传位置是必须填写的，填写的文件夹请务必存在')));
    }

    /**
     * 个人用户的配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     *
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){} 
 }