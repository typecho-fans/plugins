# BackToTop

- 简单 
- 轻量级

随机三款东方样式,刷新页面改变

## 【食用方法】

Download ZIP, 解压

重命名文件夹为BackToTop

上传至usr/plugins目录

登录后台启用即可

如果主题模板已加载jquery，可以在插件设置内禁用加载jquery

## 【更新日志】
2018.4.2  1.0  项目完成

2018.5.31  修复开启JQ插件后报错bug

## 【插件声明】

插件代码借用`Gotop插件`

>Gotop项目地址:https://github.com/xiamuguizhi/GoTop

>样式来自：https://www.mokeyjay.com

[![样式一](https://wx2.sinaimg.cn/large/006eY07Igy1fpya477yfvj30lj0jljtl.jpg "样式一")](https://wx2.sinaimg.cn/large/006eY07Igy1fpya477yfvj30lj0jljtl.jpg "样式一")

[![样式二](https://wx2.sinaimg.cn/large/006eY07Igy1fpya4jew27j30j40fugm2.jpg "样式二")](https://wx2.sinaimg.cn/large/006eY07Igy1fpya4jew27j30j40fugm2.jpg "样式二")

[![样式三](https://wx2.sinaimg.cn/large/006eY07Igy1fpya4r8f92j30i90h83yy.jpg "样式三")](https://wx2.sinaimg.cn/large/006eY07Igy1fpya4r8f92j30i90h83yy.jpg "样式三")
