# EditorAdv 插件

Typecho自带Markdown编辑器的增强插件

## 插件功能

1.文章编辑栏中加入“添加代码”按钮

2.支持代码高亮，移植自大名鼎鼎的SyntaxHighlighter
