<?php
/**
 * 随机显示一句话
 * 
 * @package RandomNonsense
 * @author 清浅
 * @version 1.0.0
 * @update: 2020.03.18
 * @link https://ftm.moe/
 */
class RandomNonsense_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->___showNonsense = array('RandomNonsense_Plugin', 'show');

    }

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){}
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $nonsense = new Typecho_Widget_Helper_Form_Element_Textarea('nonsense', NULL, "Test\nHello World", _t('一行一句'), _t('设置完成后，在模板合适的地方加上$this-&gt;showNonsense();即可'));
        $form->addInput($nonsense);

    }

    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    /**
     * 随机选择一句话并显示
     * 
     * @access public
     * @param object $archive
     * @return string
     */
    public static function show($archive)
    {
        $nonsense = Typecho_Widget::widget('Widget_Options')->plugin('RandomNonsense')->nonsense;
        $nonsense = trim($nonsense);
        if (!$nonsense) return;
        $nonsense = explode("\n", $nonsense);
        if (!$nonsense) return;

        $total = sizeof($nonsense) - 1;
        $index = mt_rand(0, $total);
        return _t($nonsense[$index]);
        
    }

}
