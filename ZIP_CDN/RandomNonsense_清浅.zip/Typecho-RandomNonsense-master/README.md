# Typecho-RandomNonsense
一个简单的Typecho插件，在页面的任何位置随机显示一句话
