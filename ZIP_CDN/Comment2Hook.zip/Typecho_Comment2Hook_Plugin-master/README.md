## Typecho_Comment2Hook_Plugin

### 使用方法：

- 请把`Comment2Hook`整个目录拷贝到 Typecho 安装路径的`usr/plugins/`下
- 登录进入 Typecho 博客后台，进行设置，否则不能使用
- 设置的时候，必须填入 webhook 的 url，例如，Server 酱会给你一个 url，类似这样：https://sc.ftqq.com/<"server chan key">.send
- 目前只支持 Server 酱，其他通道会后续增加

### 特别感谢

- 本插件基本是魔改了这个[Comment2IFTTT 插件](https://github.com/Tsuk1ko/Comment2IFTTT)

### 联系我，提需求，报告 bug， 以下均可：

- guiyumin@yahoo.com
- github issue
- 没有 QQ 群，也没有微信群

### LICENSE

- MIT
