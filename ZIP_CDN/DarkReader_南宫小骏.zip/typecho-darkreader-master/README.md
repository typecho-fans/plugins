# DarkReader 

## 插件说明
本插件的作用就是将 [Dark Reader](https://darkreader.org/) 引入到 typecho 中。

## 当前版本
    1.0.0

## 历史更新
- 1.0.0
    首次发布