# Simditor For Typecho

这是一款 Typecho 非常好用的HTML编辑器插件，可替换掉 Typecho 内置的 Markdown 编辑器。另外本编辑器插件支持直接使用 Typecho 文件上传功能且内置了 Prism 代码高亮库及 ecode（易语言代码高亮库）。


# 使用方法

1、下载本插件后改名为 `Simditor`，放在 `/usr/plugins/` 目录中；

2、进入插件管理后激活插件；

3、根据您的需求设置是否启用 代码高亮 显示行号 引入jQuery库 等配置；

4、完成。


# 特别说明

因本人不喜欢用 Markdown 编辑器所以本插件主要是为了满足个人需求而编写的，兼容性方面可能会存在不完善的地方，如您在使用的时候遇到问题，可根据源代码自行修改，或者与我联系。

# License

Open sourced under the MIT license.
