﻿CKEDITOR.editorConfig = function( config ) 
{ 
config.language = 'zh-cn';
config.width = 710;
config.skin='v2';
config.tabSpaces = 4;
config.toolbarCanCollapse = true;
config.resize_maxWidth = 710;
config.resize_minWidth = 710;
//config.startupFocus = true;
config.extraPlugins = 'syntaxhighlight'; //加载代码高亮插件，如不需要此功能请注释此行 by QFisH
//这里修改表情包
config.smiley_images = ['1.gif','2.gif','3.gif','4.gif','5.gif','6.gif','7.gif','8.gif','9.gif','10.gif','11.gif','12.gif','13.gif','14.gif','15.gif','16.gif','17.gif','18.gif','19.gif','20.gif','21.gif','22.gif','23.gif','24.gif','25.gif','26.gif','27.gif','28.gif','29.gif','30.gif','31.gif','32.gif','33.gif','34.gif'];
config.toolbar = [['Source','Maximize','Code'],['Bold','Italic','Underline','Strike','FontSize','TextColor','BGColor'],['NumberedList','BulletedList','Outdent','Indent','JustifyLeft','JustifyCenter','JustifyRight','Link','Unlink','Image','Flash','Smiley','Table','RemoveFormat']];
};