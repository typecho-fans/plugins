# RobotsLogs

## Robots Logs Plugin For Typecho

Record spider crawl logs and Display.

### Lastest Update Description

* Description Optimization

### Notice

* When the plugin update, please disable the plugin before updating.
* Please change the plugin directory name to RobotsLogs.

### Support

- [Baidu](https://www.baidu.com/)
- [Sogou](https://www.sogou.com/)
- [360](https://www.so.com/)
- [Youdao](http://www.youdao.com/)
- [SOSO](http://soso.com/)
- [Bing](https://www.bing.com/)
- [Google](https://www.google.com/)
- [Yahoo](https://www.yahoo.com/)
- [DuckDuckGo](https://duckduckgo.com/)

### Author

[@Shion](https://github.com/Shion)

[@YoviSun](https://github.com/YoviSun)

[@Ryan](https://github.com/Ryan)

[@Cain](https://github.com/Vndroid)