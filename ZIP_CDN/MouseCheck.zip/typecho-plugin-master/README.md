# typecho-plugin  
刚接触typecho，根据示例学习制作插件(仅在typecho 1.1上测试)。  
- `MouseCheck`：鼠标点击时按顺序显示设置的文字，颜色从设置中随机获取。  
- ...

## 预览  
在线演示：[caorui.top/ddblog](caorui.top/ddblog)  
github地址：[https://github.com/caoruichn/typecho-plugin](https://github.com/caoruichn/typecho-plugin)

## 使用方法  
以MouseCheck为例：
1. 下载需要的插件后，会得到`MouseCheck`目录，确认目录中包含`Plugin.php`文件；  
2. 将MouseCheck目录拷贝到typecho根目录中`usr/plugins/`下，此时文件路径应该为：`usr/plugins/MouseCheck/Plugin.php`；  
3. 登录管理后台，在【控制台-插件】中激活插件即可；  
4. 可选择设置显示文字、颜色；  

## 其他
新手入门，请多指教。
