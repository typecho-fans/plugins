# Comment2Slack

> Typecho 插件——新评论slack通知 

## 感谢

参考着 https://github.com/YianAndCode/Comment2Wechat 这个改的

## 使用方法

下载后将文件夹改名为Comment2Slack，然后上传到typecho的插件目录下，之后开启。  

配置说明：

webhook：slack的webhook地址

channel：带着#或者@的slack channel


## License

do what u want

