### Typecho HTMLCompress Plugin

#### 简介
Typecho HTML Compression 是一款最简单但最实用的插件，它的主要作用是——删除前端页面所有空行和制表符等不必要的内容、简化代码，从而实现加速**(并不是)** Typecho 的效果。你甚至不需要做任何设置，下载，安装，启用。不要小看页面中的空行，删去后可以节省大量载入时间，这也就是为什么 jQuery、Bootstrap 等文件要提供“Uncompressed”和“Compressed”版的原因。

#### 使用说明
* 请将插件目录重命名为HTMLCompress
* 此版本仅支持PHP>=5.4，以下版本请用[1.2版](https://github.com/kokororin/typecho-plugin-HTMLCompress/tree/1.2)