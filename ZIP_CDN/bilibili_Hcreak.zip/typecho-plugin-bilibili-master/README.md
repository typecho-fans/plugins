Typecho Plugin Bilibili
===================

本插件实现在Typecho中嵌入bilibili的HTML代码标签。

下载插件：

    git clone https://github.com/Hcreak/typecho-plugin-bilibili.git /typecho-plugin-path/bilibili
    注意： 插件文件夹名必须为bilibili

激活后使用：

```
[bilibili]av(id)[/bilibili] //嵌入HTML代码标签
```

av号可在b站视频页URL中获取

