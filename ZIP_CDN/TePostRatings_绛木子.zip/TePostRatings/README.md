#TePostRatings
