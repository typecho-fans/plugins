=== MemorialDay ===
Contributors: shenyanzhi
Donate link: https://qq52o.me/sponsor.html
Tags: mourning, nanjing, 1213, 918
Requires at least: 4.6
Tested up to: 6.8
Requires PHP: 5.6.0
Stable tag: 1.1.0
License: Apache 2.0
License URI: http://www.apache.org/licenses/LICENSE-2.0.html

「特殊节日使用」在国家公祭日、全国哀悼日时网站增加灰色滤镜

== Description ==

「特殊节日使用」在国家公祭日、全国哀悼日时网站增加灰色滤镜

## 作者博客

[沈唁志](https://qq52o.me "沈唁志")

== Installation ==

1. Upload the folder `MemorialDay` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. That's all

== Screenshots ==

1. 设置页面

== Changelog ==

= 1.0.4 =
* Support preview

= 1.0.3 =
* Support WordPress 5.6

= 1.0.1 =
* Fix time zone setting

= 1.0.0 =
* First version
