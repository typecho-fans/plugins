﻿CKEDITOR.plugins.setLang("exportpdf","en",{documentReady:"Document is ready!",error:"Error occurred.",processingDocument:"Processing PDF document...",toolbar:"Export to PDF"});
