﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'zh-cn', {
	button: '模板',
	emptyListMsg: '(没有模板)',
	insertOption: '替换当前内容',
	options: '模板选项',
	selectPromptMsg: '请选择要在编辑器中使用的模板：',
	title: '内容模板'
} );
