## RandomDescription

A plugin that make your site's description changes randomly.

License: [WTFPL][1]

## How to use

### First

edit /theme/yourtheme/header.php

replace `$this->options->description()` to `$this->random()`

### Second

Install this plugin

Done

 [1]: http://www.wtfpl.net/