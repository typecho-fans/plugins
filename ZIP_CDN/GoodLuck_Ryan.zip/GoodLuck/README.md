# GoodLuck
文章很多时，读者不知道该看哪篇文章，我们可随机给读者跳转一篇文章，类似于Google的手气不错

## 使用方法
下载本git到typecho插件目录并且把目录名修改成`GoodLuck`，然后在后台启用插件即可通过`域名/goodluck`查看插件效果。

## 预览
https://blog.iplayloli.com/goodluck
