PlayAtWill
==========


##### 描述
这是一款用于Typecho的音乐播放器插件，支持播放地址包括站内和在线的mp3、mp4等音乐。


##### 教程和反馈
插件使用教程和反馈地址：[音乐播放器PlayAtWill for typecho插件（移植自wordpress）](https://typecodes.com/web/typechomp3player.html '音乐播放器PlayAtWill for typecho插件（移植自wordpress）')。
