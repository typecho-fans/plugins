# CatClaw
CatClaw，是一款纯免费的typecho影视采集插件，适用于typecho影视1号与影视2号模板。感谢Moez制作的Collect插件，让我少走了一些弯路。

**功能介绍**

- 采集视频资源默认同名自动略过，同名连载状态自动更新内容 

- 支持多分类绑定 支持设置发布文章的用户 

- 支持免登录采集【指无需登陆，实际是代码中做了临时登陆】

- 支持适配autoup插件 

- 支持手动采集与服务器定时任务监控采集


视频演示地址：https://www.bilibili.com/video/BV1QK411n7qX?p=4

影视一号模板：https://qqdie.com/archives/typecho-video-template.html

影视二号模板：https://qqdie.com/archives/typecho-film-theme.html



**PS：** 插件代码中含有typecho发布文章的接口代码，如果你是开发者，如果想做采集插件的话，可以参考里面的代码哦！

# 插件升级方式
禁用删除旧版插件，上传启用配置新版插件
