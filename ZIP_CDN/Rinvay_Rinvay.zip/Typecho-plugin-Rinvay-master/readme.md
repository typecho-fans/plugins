## Rinvay Theme plugin

![](https://www.rinvay.cc/usr/themes/Rinvay/screenshot.jpg)

**主题介绍**

Rinvay是一款基于pinghsu主题的修改版，📰<a href="https://www.linpx.com/p/more-detailed-pinghsu-theme-set-tutorial.html/comment-page-7" target="_blank">pinghsu</a>,更新详见Github📰<a href="https://github.com/uouuou" target="_blank">Github</a>和我的Blog📰<a href="https://www.rinvay.cc" target="_blank">Rinvay.H</a>

**下载地址**

https://github.com/uouuou/Typecho-theme-Rinvay

**主题预览**

https://www.rinvay.cc
