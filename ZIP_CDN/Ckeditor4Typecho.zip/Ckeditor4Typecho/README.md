CkEditor4Typecho
================

## 插件说明 ##
 - 插件名称：CkEditor4Typecho
 - 功能描述: typecho上带图片上传功能的ckeditor插件
 - 开发作者：[zhulin3141](http://zhulin31410.blog.163.com)

 ## 使用帮助 ##

 1. 下载插件
 2. 将插件上传到 `/usr/plugins/` 这个目录下
 3. 登陆后台，在“控制台”下拉菜单中进入“插件管理”
 4. 启用相关插件
 5. 设置插件
