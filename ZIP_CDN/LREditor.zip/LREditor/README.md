### Markdown左右预览插件LREditor v0.0.4

让系统默认的Markdown编辑器支持左右分屏实时预览。

- 补更至v0.0.4。

###### 更多详见作者博客：http://imnerd.org/lreditor-plugin-for-typecho.html