# BilibiliEcho
Bilibili 动态同步到 Typecho 的插件。

**如果觉得不错，右上角给个 Star 哦~**

# 特性

- 支持缓存
- 自定义显示条数
- 正则表达式定制
  - 可以用于定制选取规则忽略规则
- 自定义是否显示转发内容

# 使用教程

详见：https://www.pluvet.com/archives/bilibili-echo-publish.html
