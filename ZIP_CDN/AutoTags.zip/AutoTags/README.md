# [AutoTags](https://dt27.org/php/autotags-for-typecho/)

**标签自动生成插件 For Typecho**

关键词提取 API：[玻森](http://bosonnlp.com/)

## Features

* [x] 新建及编辑文章时自动提取标签, 默认生成5个
* [x] 当已存在标签或已手动设置标签时不再自动生成
* [x] 优先匹配博客内现有标签
* [ ] 对已发布文章批量提取

## License

> Copyright © 2016 [DT27](https://dt27.org)
> License: [GNU General Public License v3.0](http://www.gnu.org/licenses/gpl-3.0.html)