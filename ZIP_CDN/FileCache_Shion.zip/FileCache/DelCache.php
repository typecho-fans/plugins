<?php
/**
 * ����ļ�����
 * 
 * @package FileCache
 * @author Shion
 * @version 1.0.0
 * @link http://www.shionco.com
 */
function delcache($cache)
{
    $fh = opendir($cache);
    while (($file = readdir($fh)) !== false) {
            if($file!=".."&&$file!=".") {
                if(is_dir($cache."/".$file)) {
                    delcache($cache."/".$file);
                } else {
                    unlink($cache."/".$file);
                }
            }
        }
    closedir($fh);
}
delcache(dirname(__FILE__).'/Cache');
