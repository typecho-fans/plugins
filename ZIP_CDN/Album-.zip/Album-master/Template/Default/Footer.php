
            
        </div><!-- end .colgroup -->
    </div>
</div><!-- end #body -->

<footer id="footer"  role="contentinfo">
	<div class="container">
    &copy; <?php _e(date('Y')); ?> <a href="<?php _e($siteUrl); ?>"><?php _e($title); ?></a> | 
    <?php _e('Plugin by <a href="https://plsYou.com">plsYou</a> '); ?> | 
    <?php _e( ' Run in '.$run_time.'s'); ?>
  </div>
</footer><!-- end #footer -->
</body>
</html>
