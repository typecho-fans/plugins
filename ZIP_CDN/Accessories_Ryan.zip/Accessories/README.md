## Accessories

从 Attachment 插件增强而来。

- 修改附件短码[attach]id[/attach]
- 从 Attachment 改名
- 点击附件按钮自动填写[attach]id[/attach]
- 增加原文件名下载**(隐藏真实路径)**
- 增加内置统计功能(带开关)
- 支持 CDN 路径替换