<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * Clso.Fun - Typecho Plus <br/>
 * 一个用于增强Typecho权限系统，Markdown解析功能的实用插件！<br/>
 * 具体用法请参阅<a href="https://blog.clso.fun/posts/2019-04-27/typecho-plus.html" target="_blank">我的博客</a>。
 *
 * @package ClsoFun
 * @author 二笔青年
 * @version 0.5.3
 * @link https://blog.clso.fun/
 */

Class ClsoFun_Plugin implements Typecho_Plugin_Interface {

    public static $ubbBlock = array(
        'hide',
        'login',
        'notify',
        'picbox'
    );

    private static $ubbLineTag = 'align|center|right|url|img|color|bgcolor|font|size|face|safe|vod|movie|mov|mp3|audio|music|download|ruby';

    // https://www.w3schools.com/colors/colors_names.asp
    private static $ubbColor = 'red|green|blue|white|purple|yellow|violet|brown|black|pink|orange|gold';




    /**
     * 启用插件方法,如果启用失败,直接抛出异常
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate(){
        Typecho_Plugin::factory('Widget_Archive')->header = array(__CLASS__, 'header');
        Typecho_Plugin::factory('Widget_Archive')->footer = array(__CLASS__, 'footer');
        Typecho_Plugin::factory('admin/footer.php')->end = array(__CLASS__, 'adminfooter');

        Typecho_Plugin::factory('Widget_Archive')->handleInit = array(__CLASS__, 'handleFilter');

        Typecho_Plugin::factory('Widget_Abstract_Contents')->content = array(__CLASS__, 'content');
        Typecho_Plugin::factory('Widget_Abstract_Contents')->excerpt = array(__CLASS__, 'content');

        Typecho_Plugin::factory('Widget_Contents_Post_Edit')->getDefaultFieldItems = array(__CLASS__, 'setlayout');
        Typecho_Plugin::factory('Widget_Contents_Page_Edit')->getDefaultFieldItems = array(__CLASS__, 'setlayout');

        return _t('插件已激活，现在可以对插件进行设置！');
    }

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){
        return "插件被卸载";
    }

    /**
     * 获取插件配置面板
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form){

        $usejquery= new Typecho_Widget_Helper_Form_Element_Radio('usejquery',
            array('true' => '是', 'false' => '否'),
            'false', '是否引入JQuery','本插件依赖JQuery库，如果您的站点并未引用，请开启此选项自动引用！');
        $form->addInput($usejquery);

        $jqueryUrl = new Typecho_Widget_Helper_Form_Element_Text('jqueryUrl',null, '//cdn.staticfile.org/jquery/1.12.4/jquery.min.js', 'JQuery路径', '加载JQuery的版本与路径，请自行选择合适的版本与CDN。<br/> 有关JSCDN可以查看本人的 <a href="https://blog.clso.fun/posts/2019-03-08/js-libs-cdn.html" target="_blank">这篇文章</a>。');
        $form->addInput($jqueryUrl);

        $todoCss = new Typecho_Widget_Helper_Form_Element_Radio('todoCss',
            array('yes' => '使用CSS样式', 'no' => '不使用CSS样式'),
            'yes', 'TODO 样式', '是否使用CSS图片，或者使用浏览器的默认控件');
        $form->addInput($todoCss);

        $optimize = new Typecho_Widget_Helper_Form_Element_Radio('optimize',
            array('true' => '是', 'false' => '否'),
            'true', '是否优化后台','优化后台Textarea控件，让其随着输入自动调整大小。（仅影响自定义字段与模板外观设置）<br />
改变发布按钮位置，添加Ctrl+Enter异步提交功能');
        $form->addInput($optimize);

        $tplay =  new Typecho_Widget_Helper_Form_Element_Radio('tplay',
            array('true' => '是', 'false' => '否'),
            'true', '是否使用 Typecho-Plus 布局','去除文章内的 &lt;p&gt; 标签，全部改用 &lt;br&gt; 来代替，开启才能更好地兼容 TypechoPlus 的块级UBB功能！<a href="https://blog.clso.fun/posts/2019-04-27/typecho-plus.html">更多说明</a>');
        $form->addInput($tplay);

        $tpubb =  new Typecho_Widget_Helper_Form_Element_Radio('tpubb',
            array('true' => '是', 'false' => '否'),
            'true', '是否使用 Typecho-Plus 的块级UBB功能','块级UBB功能或多或少与Typecho默认的文章排版系统有冲突，如果您不想使用块级代码，则可以使用此选项关闭它！<br />
如 [hide]、[login]、[notify] 等功能将失效，但文章内部的UBB代码还是相对安全的，请放心使用！');
        $form->addInput($tpubb);

        $tpinubb =  new Typecho_Widget_Helper_Form_Element_Radio('tpinubb',
            array('true' => '是', 'false' => '否'), 'true', '是否使用文章内部的UBB功能', '如果你不想在文章内使用UBB解析，请选择“否”，一般不用改动此项。');
        $form->addInput($tpinubb);


        $mutilines =  new Typecho_Widget_Helper_Form_Element_Radio('mutilines',
            array('true' => '是', 'false' => '否'), 'false', '是否允许解析多行 BR',
            'Tyoecho 默认会将多个换行符合并为至多两个换行，而此项开启后将会按照您文章内的换行符进行换行，而不会进行换行简化。<br/>注意：此功能只在启用了 <b>Typecho-Plus 布局</b> 之后才会生效！');
        $form->addInput($mutilines);


        $hostChk = new Typecho_Widget_Helper_Form_Element_Text('hostChk', null, '', '域名检测', '输入你的主域名，若链接指向其他域名，则会给链接添加安全跳转属性！<br />
留空则不处理，仅影响 Markdown 链接，对UBB的 [url] 标签无效！');
        $form->addInput($hostChk);


        $imgErr = new Typecho_Widget_Helper_Form_Element_Text('imgErr', null, '', '图片错误处理', '输入一个URL地址，自动将加载错误的图片指向该图片，留空则不处理！<br/><span style="background-color: yellow">切记不要输入错误的图片地址，否则有可能会导致浏览器陷入死循环。</span>');
        $form->addInput($imgErr);

        $safeUrl = new Typecho_Widget_Helper_Form_Element_Text('safeUrl', null, '', '安全地址检查', '所有的 [safe]...[/safe] 链接都会指向一个用于检测目标链接是否安全的地址，格式为 [safeURL] + urlencode(URL)<br/>请自行添加安全检查地址的查询参数，插件会自动将目标URL编码后传递给安全检查地址！');
        $form->addInput($safeUrl);

    }

    /**
     * 个人用户的配置面板
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}



    /**
     * 自定义字段
     * @param Typecho_Widget_Helper_Layout $layout
     */
    public static function setlayout($layout){
        $postType = new Typecho_Widget_Helper_Form_Element_Text('postType', NULL, NULL, _t('文章类型'), _t(
            '不填写则无限制，1=不在首页显示，2=仅限登录会员浏览，4=在索引页向游客隐藏。<br/>
        数值相加可以组合功能，如3=不在首页显示且仅限会员浏览，5=不在首页显示且向游客隐藏！'));
        $postType->input->setAttribute('class', 'w-100');
        $layout->addItem($postType);

        $zhaiyao = new Typecho_Widget_Helper_Form_Element_Textarea('zhaiyao', NULL, NULL, _t('文章摘要'), _t(
            '如果你指定了文章摘要，则会使用你指定的内容输出摘要！（支持Markdown和HTML）'));
        $zhaiyao->input->setAttribute('class', 'w-100');
        $layout->addItem($zhaiyao);
    }

    public static function header() {
        $cssPath =  Helper::options()->pluginUrl.'/ClsoFun/res/typechoplus.css';

        $opts = Helper::options()->plugin('ClsoFun');

        $usejquery =  ($opts->usejquery == 'true');
        if($usejquery){
            $jqurl  =  $opts->jqueryUrl;
            echo "<script src='$jqurl'></script>";
        }
        echo "<link rel=\"stylesheet\" type=\"text/css\" href=\" $cssPath\" />\n";

        $imgerr = $opts->imgErr;
        if(!empty($imgerr)){
            echo '<script>function imgerr(p){if(!p.getAttribute("data-src")){p.setAttribute("data-src",p.src);p.src="'.$imgerr.'";p.title="图挂了 QAQ";p.onclick=function(){var u=this.getAttribute("data-src");this.removeAttribute("data-src");this.src=u;};}}</script>';
        }
    }

    public static function footer() {
        $jsPath =  Helper::options()->pluginUrl.'/ClsoFun/res/typechoplus.js';
        echo <<<HTML
<script src="$jsPath" ></script>
<script type="text/javascript">
// Typecho-Plus by http://clso.fun
$('footer, #footer, .footer').first().append('<div>本站<del>自嚎</del>、自豪地采用<a href="https://blog.clso.fun/posts/2019-04-27/typecho-plus.html" target="_blank"> Typecho-Plus </a>插件</div>');
</script>
HTML;
    }

    public static function adminfooter() {
        $opts = Helper::options()->plugin('ClsoFun');
        $optimize =  ($opts->optimize == 'true');

        if($optimize) {
            $jsPath =  Helper::options()->pluginUrl.'/ClsoFun/res/autosize.min.js';
            echo <<<HTML
<script src="$jsPath" ></script>
<script type="text/javascript">
// Typecho-Plus by http://clso.fun
autosize($(".typecho-option textarea, #custom-field textarea"));
if(location.pathname.indexOf('/write-post.php') !== -1 || location.pathname.indexOf('/write-page.php') !== -1){
    $("p.title:first").after($(".submit").css({"float":"right", "margin": "0 0 5px 0"}));
    $(function(){ $("#wmd-button-bar").css("clear","both"); });
    $("#btn-submit").attr("title","在编辑器中按 Ctrl+Enter 可以异步提交哦！");
}
$(".typecho-post-area form textarea, .typecho-post-area form input[type='text']").on("keydown",function(event) {
    if( (event.keyCode === 13) && event.ctrlKey ){
    	var qs = document.location.search.split('+').join(' ');
    	var params = {}, tokens, re = /[?&]?([^=]+)=([^&]*)/g;
    	while ((tokens = re.exec(qs))){ params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]); } 
        if(!params.cid){ $("#btn-submit").click(); return; }
        
        var form = $('.typecho-post-area form:first');
        $("#text").attr("readonly", "readonly");
        $.post(form.attr("action"), form.serialize(), function(result, status, xhr){
            //console.log(result);
            alert(status);
            $("#text").removeAttr("readonly");
        });
    }
});

function insertText(tarTag, insText) {
    if(!tarTag || !insText) return;
    if(tarTag.jquery || tarTag.length) tarTag = tarTag[0];
    if (document.selection) {
        tarTag.focus();
        var sel = document.selection.createRange();
        sel.text = insText;
        sel.select();
    } else if (tarTag.selectionStart || tarTag.selectionStart == '0') {
        var startPos = tarTag.selectionStart;
        var endPos = tarTag.selectionEnd;
        var beforeValue = tarTag.value.substring(0, startPos);
        var afterValue = tarTag.value.substring(endPos, tarTag.value.length);
        tarTag.value = beforeValue + insText + afterValue;
        tarTag.selectionStart = startPos + insText.length;
        tarTag.selectionEnd = startPos + insText.length;
        tarTag.focus();
    } else {
        tarTag.value += insText;
        tarTag.focus();
    }
}
</script>
HTML;
        }
    }


    /**
     * 全局查询过滤
     * @param Widget_Archive $widget
     * @param Typecho_Db_Query $select
     * @return  Typecho_Db_Query
     */
    public static function handleFilter($widget, $select, $unkown){
        //$select = empty($unkown) ? $select : $unkown; //也许?
        $partype = $widget->parameter->type;

        if( in_array( $partype, [ 'page', 'post', 'single', 'comment_page', '404', 'attachment', 'comment' ] )){
            return $select;
        }

        $isindex = in_array($partype, ['index', 'index_page']);
        $hasLogin = Typecho_Widget::widget('Widget_User')->hasLogin();

        if(!$isindex && $hasLogin){
            return $select;
        }

        $select = $select->join('table.fields', 'table.fields.cid = table.contents.cid AND table.fields.name = "postType"', 'left');
        if($isindex){ 
            $select = $select->where('(table.fields.str_value is null) OR (table.fields.str_value & 1 <> 1)');
        }
        if(!$hasLogin){ 
            $select = $select->where('(table.fields.str_value is null) OR (table.fields.str_value & 4 <> 4)');
        }

        return $select;
    }



    /**
     * 内容解析
     * @param string $content
     * @param Widget_Abstract_Contents $widget
     * @param string $lastResult
     * @return string
     */
    public static function content($content, $widget, $lastResult){
        $content = empty( $lastResult ) ? $content : $lastResult;

        $postType = is_numeric($widget->fields->postType) ? (int)$widget->fields->postType : 0;
        $needLogin = (2 === ($postType & 2));
        $hasLogin = Typecho_Widget::widget('Widget_User')->hasLogin();
        if( $needLogin && !$hasLogin ) {
            return '<div class="tplus-unreg">该文档仅限会员浏览，<a href="'. __TYPECHO_ADMIN_DIR__ . 'login.php?referer=' . urlencode($widget->permalink)  .'">请先登录！</a></div>';
        }

        if( $widget->is('index') OR $widget->is('archive') ){
            $zhaiyao = $widget->fields->zhaiyao;
            if(!empty($zhaiyao)){
                $zhaiyao = preg_replace('/\<!\s*?--\s*?more\s*?--\s*?>/i','', $zhaiyao);
                $content = $zhaiyao;
            }
        }

        $content = $widget->isMarkdown ? self::markdownPlus($content) : $widget->autoP($content);

        return $content;
    }

    /**
     * Markdown+UBB解析
     * @param string $text <p>内容文本</p>
     * @return  string html
     */
    public static function markdownPlus($text){
        static $parser;

        if (empty($parser)) {
            include_once __DIR__ . '/HyperDownPlus.php';
            $parser = new HyperDownPlus();

            $parser->hook('afterParseCode', function ($html) {
                return preg_replace("/<code class=\"([_a-z0-9-]+)\">/i", "<code class=\"lang-\\1\">", $html);
            });

            $parser->enableHtml(true);
        }

        $opts = Helper::options()->plugin('ClsoFun');
        $parser->_todoCss = ($opts->todoCss == 'yes');
        $parser->_imgErr = $opts->imgErr;
        $tplay =  ($opts->tplay == 'true');
        $parser->_tplay = $tplay;
        $hostChk = $opts->hostChk;
        if(!empty($hostChk)) $parser->_urlhost = preg_quote($hostChk, '/');

        $parser->_tpinubb = ($opts->tpinubb == 'true');
        $parser->_mutilines = ($opts->mutilines == 'true');

        $tpubb =  ($opts->tpubb == 'true');

        if($tpubb){
            self::$uniqid = md5(uniqid('', true));
            self::$inxid = 0;
            self::$holders = array();
            $key = self::makeHolder('\[');
            $text = str_replace('\[', $key, $text );
            $text = self::preUbb($text);
        }

        $ubbTag = explode('|', self::$ubbLineTag);
        $parser->_ubbParser = [];
        foreach ($ubbTag as $utag){
            $parser->_ubbParser[$utag] = array(__CLASS__, $utag.'Parser');
        }
        $ubbTag = explode('|', self::$ubbColor);
        foreach ($ubbTag as $utag){
            $parser->_ubbParser[$utag] = array(__CLASS__, 'spanColorParser');
        }

        $ret = str_replace('<p><!--more--></p>', '<!--more--><br />', $parser->makeHtml($text));
        $ret = str_replace('<!--more-->', '<!--more--><br />', $ret);

        if($tpubb){
            self::$holders[$key] = '[';
            $ret = self::releaseHolder($ret);
        }

        return $ret;
    }


    private static $uniqid;
    private static $inxid;
    private static $holders;
    private static function makeHolder($str) {
        $key = '▧' . self::$uniqid . self::$inxid . '▨';
        self::$inxid++;
        self::$holders[$key] = $str;
        return $key;
    }
    private static function releaseHolder($text, $clearHolders = true) {
        $text = str_replace(array_keys(self::$holders), array_values(self::$holders), $text);
        if ($clearHolders) self::$holders = array();
        return $text;
    }

    private static function safePack($matches){
        return self::makeHolder($matches[1]) . $matches[4] . self::makeHolder($matches[5]);
    }




    public static function preUbb($text){

        $text = preg_replace_callback(
            "#(\[(\w+)(?:\=([^\[]+))?\])(.+?)(\[/\\2\])#is",
            function ($matches){
                $utag = strtolower( $matches[2] );
                if(! in_array($utag, self::$ubbBlock )) return $matches[0];
                $pars = array();
                if(isset($matches[3])){
                    $pars = explode(',', $matches[3]);
                    array_map('trim', $pars);
                }
                $content = trim($matches[4]);
                
                $args = array($utag, $pars, $content, $matches);
                $ret = call_user_func_array( 'self::'.$utag.'BlockParser' , $args );

                return empty($ret) ? $matches[0] : $ret;
            },
            $text
        );

        return $text;
    }



    public static function notifyBlockParser($utag, $pars, $content){
        $title = empty($pars[0]) ? '通知' : $pars[0];
        $style = empty($pars[1]) ? '' : "style=\"$pars[1]\"";


        $header = "<div class=\"tplus-notify\" $style><div class=\"tplus-notify-title\">$title</div><div class=\"tplus-notify-content\">";
        $footer = "</div></div>";

        return self::makeHolder($header) . $content ."\n".  self::makeHolder($footer) ;
    }

    public static function hideBlockParser($utag, $pars, $content){
        $title = '点击展开隐藏内容（可能涉及剧透、隐私，请谨慎）';
        if(!empty($pars[0])) $title = $pars[0];

        $header = '<div class="tplus-hide"><a class="tplus-hide-title">'.$title.'</a><div class="tplus-hide-content" style="display: none">';
        $footer = '</div></div>';
        return self::makeHolder($header) . $content ."\n".  self::makeHolder($footer) ;
    }



    private static $loginUser = array(
        0 => 'administrator',
        1 => 'editor',
        2 => 'contributor',
        3 => 'subscriber',
        4 => 'visitor'
    );
    private static $userID = array(
        'administrator' => 0,
        'admin' => 0,
        'editor' => 1,
        'contributor' => 2,
        'subscriber' => 3,
        'visitor' => 4,
        'user' => 4
    );
    private static $loginUserName = array(
        0 => '管理员',
        1 => '编辑',
        2 => '贡献者',
        3 => '关注者',
        4 => '访问者'
    );

    public static function loginBlockParser($utag, $pars, $content){
        $pid = 4;
        if(is_numeric($pars[0])){
            $pid = (int)$pars[0];
            $pid = ($pid < 0 || $pid > 4) ? 4 : $pid;
        } else {
            $upar = $pars[0];
            if(isset(self::$userID[$upar])){
                $pid = self::$userID[$upar];
            }
        }

        $user = Typecho_Widget::widget('Widget_User');
        $upn = $user->pass( self::$loginUser[$pid] , true );
        $uname = self::$loginUserName[$pid];

        if(!$upn){
            $widget = Typecho_Widget::widget('Widget_Archive');
            $url = __TYPECHO_ADMIN_DIR__ . 'login.php?referer=' . urlencode($widget->permalink);
            $content = "<div class=\"tplus-unreg tplus-login-deny\">您无权浏览此文章，请退出当前帐号并 <a href=\"$url\">重新登录！</a></div>";
        }

        $header = "<div class=\"tplus-login\"><div class=\"tplus-login-title\">以下内容需要 <b>$uname</b> 以上权限才能浏览：</div><div class=\"tplus-login-content\">";

        $footer = "</div></div>";

        return self::makeHolder($header) . $content ."\n".  self::makeHolder($footer) ;
    }

    public static function picboxBlockParser($utag, $pars, $content){
        $content = str_replace("\r",'', trim($content));
        $lines = array_filter( explode( "\n", $content) );
        $pbhide = (isset($pars[1]) && !empty($pars[1])) ? ' style="display:none"' : '';

        $title = '图片集';
        $noborder = '';
        if(!empty($pars[0])){
            $title = $pars[0];
        } else {
            $noborder = ' tplus-noborder';
        }

        $ret = '';
        $imgerr = Helper::options()->plugin('ClsoFun')->imgErr;
        $imgerr = (!empty($imgerr)) ? ' onerror="imgerr(this)"' : '';
        foreach ($lines as $line){
            $matchs=[];
            if( preg_match('/^\!\[.*\]\(\s*(.+)\s*\)/i', $line, $matchs) ) {
                $line = $matchs[1];
            } elseif( preg_match('/^\[img(?:\=.+?)?\]\s*(.+?)\s*\[\/img\]/i', $line, $matchs) ) {
                $line = $matchs[1];
            }
            if( ! preg_match('/(^https?)|(\.(jpe?g|png|gif|webp|bmp)$)/i', $line) ) continue;

            $ret = $ret . '<img class="tplus-pbimg" src="' . $line . '"' . $imgerr . ' />';
        }
        if($ret === '') $ret = '<span>图集为空</span>';

        $header = '<div class="tplus-picbox'.$noborder.'"><a class="tplus-picbox-title" title="点击切换图集显示">'.$title.'</a><div class="tplus-picbox-content"'.$pbhide.'>';
        $footer = '</div></div>';
        return self::makeHolder($header . $ret . $footer) ;
    }




    public static function centerParser($utag, $pars, $content){
        return '<span style="display:block;text-align:center">' . $content .'</span>';
    }
    public static function rightParser($utag, $pars, $content){
        return '<span style="display:block;text-align:right">' . $content .'</span>';
    }
    public static function alignParser($utag, $pars, $content){
        if( count($pars) > 0 ){
            $pars[0] = htmlspecialchars($pars[0]);
            return '<span style="display:block;text-align:'.$pars[0].'">' . $content .'</span>';
        }
    }

    public static function urlParser($utag, $pars, $content){
        $pars = array_map('htmlspecialchars', $pars);

        $argn = count($pars);
        if($argn == 0){
            $turl = htmlspecialchars($content);
            return "<a href=\"$turl\">$turl</a>";
        } elseif ($argn == 1){
            return "<a href=\"$pars[0]\">$content</a>";
        }elseif ($argn == 2){
            return "<a href=\"$pars[0]\" target=\"_$pars[1]\">$content</a>";
        }elseif ($argn == 3){
            return "<a href=\"$pars[0]\" target=\"_$pars[1]\" rel=\"$pars[2]\">$content</a>";
        }elseif ($argn >= 4){
            $outpars = htmlspecialchars_decode($pars[3]);
            return "<a href=\"$pars[0]\" target=\"_$pars[1]\" rel=\"$pars[2]\" $outpars>$content</a>";
        }
    }

    public static function safeParser($utag, $pars, $content){
        $pars = array_map('htmlspecialchars', $pars);
        $safeurl = Helper::options()->plugin('ClsoFun')->safeUrl;
        $turl = isset($pars[0]) ? $pars[0] : $content;
        if(!empty($safeurl))
            $turl = $safeurl . urlencode($turl);

        return "<a class=\"tplus-safeurl\" href=\"$turl\" target=\"_blank\" rel=\"external nofollow noopener\">$content</a>";
    }

    public static function imgParser($utag, $pars, $content, $matches){
        $content = htmlspecialchars($content);
        $pars = array_map('htmlspecialchars', $pars);
        $imgerr = Helper::options()->plugin('ClsoFun')->imgErr;
        if ( !empty( $imgerr) ){
            $imgerr = 'onerror="imgerr(this)"';
        } else {
            $imgerr = '';
        }
        // 这里写得太屎，以后再改吧
        if(count($pars) == 0){
            return "<img src=\"$content\" $imgerr />";
        } elseif (count($pars) == 1){
            $wh = str_replace(array(' ','-',':'), 'x', $pars[0]);
            $wh = explode('x', $wh);
            if(count($wh) == 1){
                return "<img src=\"$content\" width=\"$wh[0]\" $imgerr/>";
            }elseif (count($wh) == 2){
                return "<img src=\"$content\" width=\"$wh[0]\" height=\"$wh[1]\" $imgerr />";
            }
        } elseif (count($pars) == 2){
            return "<img src=\"$content\" width=\"$pars[0]\" height=\"$pars[1]\" $imgerr />";
        } elseif (count($pars) >= 3){
            return "<img src=\"$content\" width=\"$pars[0]\" height=\"$pars[1]\" style=\"$pars[2]\" $imgerr />";
        }

        return self::safePack($matches) ;
    }

    public static function colorParser($utag, $pars, $content, $matches){
        if(empty($pars[0])) return self::safePack($matches);
        $pars = array_map('htmlspecialchars', $pars);
        return "<span style=\"color:$pars[0]\">$content</span>";
    }
    public static function spanColorParser($utag, $pars, $content){
        return "<span style=\"color:$utag\">$content</span>";
    }

    public static function bgcolorParser($utag, $pars, $content, $matches){
        if(empty($pars[0])) return self::safePack($matches);
        $pars = array_map('htmlspecialchars', $pars);
        return "<span style=\"background-color:$pars[0]\">$content</span>";
    }

    public static function fontParser($utag, $pars, $content){
        $pars = array_map('htmlspecialchars', $pars);
        $face = ''; $size =''; $color='';
        if(!empty($pars[0])) $face = " face=\"$pars[0]\"";
        if(!empty($pars[1])) $size = " size=\"$pars[1]\"";
        if(!empty($pars[2])) $color = " color=\"$pars[2]\"";
        return "<font$face$size$color>$content</font>";
    }
    public static function sizeParser($utag, $pars, $content){
        $pars = array_map('htmlspecialchars', $pars);
        $size = '';
        if(!empty($pars[0])) $size = " size=\"$pars[0]\"";
        return "<font$size>$content</font>";
    }
    public static function faceParser($utag, $pars, $content){
        $pars = array_map('htmlspecialchars', $pars);
        $face = '';
        if(!empty($pars[0])) $face = " face=\"$pars[0]\"";
        return "<font$face>$content</font>";
    }


    public static function vodParser($utag, $pars, $content){
        return self::movieParser($utag, $pars, $content);
    }
    public static function movParser($utag, $pars, $content){
        return self::movieParser($utag, $pars, $content);
    }
    public static function movieParser($utag, $pars, $content){
        $content = htmlspecialchars($content);
        $pars = array_map('htmlspecialchars', $pars);
        $vol = (!empty($pars[0])) ? $pars[0] : '0.25';
        return "<video class=\"tplus-video\" src=\"$content\" volume=\"$vol\" controls></video>";
    }

    public static function mp3Parser($utag, $pars, $content){
        return self::audioParser($utag, $pars, $content);
    }
    public static function musicParser($utag, $pars, $content){
        return self::audioParser($utag, $pars, $content);
    }
    public static function audioParser($utag, $pars, $content){
        $content = htmlspecialchars($content);
        $pars = array_map('htmlspecialchars', $pars);
        $vol = (!empty($pars[0])) ? $pars[0] : '0.25';
        return "<audio class=\"tplus-audio\" src=\"$content\" volume=\"$vol\" controls></audio>";
    }

    public static function downloadParser($utag, $pars, $content){
        $content = htmlspecialchars($content);
        $pars = array_map('htmlspecialchars', $pars);
        if(empty($pars[0])) return '<span style="text-decoration: underline">错误的下载链接('.$content.')</span>';

        return "<a href=\"$pars[0]\" download='$content'>$content</a>";
    }

    public static function rubyParser($utag, $pars, $content){
        $content = htmlspecialchars($content);
        $pars = array_map('htmlspecialchars', $pars);
        if(empty($pars[0])) $pars[0] = '缺少注音';

        return "<ruby>$content<rp>（</rp><rt>$pars[0]</rt><rp>）</rp></ruby>";
    }

}