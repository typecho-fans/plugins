# TinyPNG_for_Typecho
[Key API](https://tinypng.com/developers) configuration can be used after.

Please rename the folder after download: TinyPNG

If any questions welcome feedback

Presentation feedback: [www.moyu.win](http://www.moyu.win)


----------


[申请Key API](https://tinypng.com/developers) 后配置即可使用。

下载后请改名文件夹为：TinyPNG 使用

如有问题 欢迎反馈

演示 反馈：[www.moyu.win](http://www.moyu.win)