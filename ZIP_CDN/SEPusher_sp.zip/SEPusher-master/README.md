# SEPusher
一款typecho搜索引擎推送插件。
这个版本只做了百度的推送。