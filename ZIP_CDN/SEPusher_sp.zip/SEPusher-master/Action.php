<?php
header("Content-type: text/plain");
echo file_get_contents(join(DIRECTORY_SEPARATOR, [__DIR__, 'status']));
