<?php

/**
 * 搜索引擎主动推送，这个版本只做了百度<br>
 * 插件启用后请点击设置按钮配置推送地址<br>
 * 推送成功右上角会出现PUSH:√<br>
 * 若推送失败，请检查推送地址配置。
 *
 * @package SEPusher
 * @author sp
 * @version 1.0.1
 * @link https://index.php/cross.html
 */
class SEPusher_Plugin implements Typecho_Plugin_Interface
{
  //启用时
  public static function activate()
  {
    Typecho_Plugin::factory('Widget_Contents_Post_Edit')->finishPublish = array(__CLASS__, 'Push');
    Typecho_Plugin::factory('Widget_Contents_Page_Edit')->finishPublish = array(__CLASS__, 'Push');
    Typecho_Plugin::factory('admin/menu.php')->navBar = array(__CLASS__, 'Tip');
  }
  //禁用时
  public static function deactivate()
  {
  }
  //设置面板
  public static function config(Typecho_Widget_Helper_Form $form)
  {
    $PushAddress = new Typecho_Widget_Helper_Form_Element_Text('PushAddress', null, 'http://baidu.cn/#这里要换成你的推送地址', _t('百度资源站长平台推送地址:'));
    $form->addInput($PushAddress->addRule('required', _t('不能为空！')));
  }
  //主函数
  public static function Push($content, $post)
  {
    $opt = Typecho_Widget::widget('Widget_Options')->plugin('SEPusher');
    $pushAddress = $opt->PushAddress;
    $permalink = $post->stack[0]['permalink'];
    $title = $post->stack[0]['title'];
    $fetch = Typecho_Http_Client::get();
    if ($fetch) {
      $res = $fetch
        ->setData(implode("\n", [$permalink]))
        ->setHeader('Content-Type', 'text/plain')
        ->setTimeout(30)
        ->send($pushAddress);
    } else {
      throw new Typecho_Plugin_Exception(_t('请开启php_curl扩展，否则无法使用本插件。'));
    }
    $status = strpos($res, 'success') ? '√' : '×';
    file_put_contents(join(DIRECTORY_SEPARATOR, [__DIR__, 'status']), "PUSH:{$title}{$status}");
    return true;
  }
  /**tip */
  public static function Tip()
  {
    $link = Helper::options()->pluginUrl . '/SEPusher/Action.php';
    echo
      "
<span id='SEPusherTip' style='color: #bbbbbb;'></span>
<script type='text/javascript'>
  fetch('$link').then(res=>{
    return res.text();
  }).then(status=>{
    document.getElementById('SEPusherTip').innerHTML=status;
    });
</script>
    ";
  }
  //华丽配置面板
  public static function personalConfig(Typecho_Widget_Helper_Form $form)
  {
  }
}
