# Beblank

使Typecho的超链接在新的标签页打开,优化阅读体验

可选所有链接都在新标签页打开或仅外链链接在新标签页打开


## 使用插件前

![old.gif](https://i.loli.net/2019/02/22/5c6fc6465d8c4.gif)

## 使用插件后

![new.gif](https://i.loli.net/2019/02/22/5c6fc6ad766fd.gif)

## 使用方法

克隆本项目到本地,解压并修改文件夹名称为`Beblank`,上传至 `/usr/plugins` 目录下,在后台启动即可 

## 最后

欢迎 `sar / fork / issue`







