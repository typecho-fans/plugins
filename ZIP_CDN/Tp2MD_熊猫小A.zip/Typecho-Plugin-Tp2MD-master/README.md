# Tp2MD

> 📃 导出 Typecho 内容至 Markdown 文件

支持丰富的 metadata，包括自定义字段、slug、分类、标签、日期等等，以 YAML front-matter 形式存储在文件顶部。可无痛转移至 Hexo 等。

支持将文章按分类导出到不同的文件夹。

## 使用

下载插件，解压后文件夹重命名为 Tp2MD，上传至插件目录并启用，然后按说明操作。

## 日志

**Version 1.1**

* 支持导出自定义字段
* 修复文件名错误

**Version 1.0**

开始旅程

## Author

[熊猫小A | AlanDecode](https://github.com/AlanDecode)

## 捐助

如果这个项目有帮助到你，请考虑向我捐助：

![](https://wx1.sinaimg.cn/large/0060lm7Tly1g0c4cbi71lj30sc0iv453.jpg)

## LICENSE

MIT.
