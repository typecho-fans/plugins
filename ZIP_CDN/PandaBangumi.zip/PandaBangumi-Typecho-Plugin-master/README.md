# PandaBangumi-Typecho-Plugin

![](https://cdn.imalan.cn/img/site/IMG_1676.JPG)

为你的 Typecho 博客增加追番列表显示功能。

演示：**[我的追番 - 熊猫小A的博客](https://blog.imalan.cn/bangumi/)**

介绍：**[熊猫追番 (PandaBangumi) for Typecho 发布！ - 熊猫小A的博客](https://blog.imalan.cn/archives/128/)**
