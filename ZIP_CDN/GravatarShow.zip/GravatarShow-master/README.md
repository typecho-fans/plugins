# GravatarShow
一款基于Typecho的Gravatar头像显示插件

---
# 插件优点

免配置直接启用，无需更改Typecho系统文件，方便Typecho升级，免去升级后需要再次修改！
采用未被屏蔽的官方Gravatar头像地址(https)，稳定好用！
无其他插件的头像缓存功能，单纯的将原被墙地址换为未被屏蔽的地址，非常纯净！

---
# 使用方法

下载GravatarShow.php，上传至/usr/plugins文件夹内
登录Typecho博客后台，顶部导航栏-控制台-插件-找到GravatarShow-启用
大功告成！试试Gravatar头像能否显示了吧！
