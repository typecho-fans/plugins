<?php
/**
 * 使用Lightbox2.5.1制作的图片弹框效果。
 * @package Lightbox
 * @author AC Yang
 * @version 2.5.1
 * @link http://acyang.onshow.net
 */
class Lightbox_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     *
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->header = array('Lightbox_Plugin', 'headlink');
        Typecho_Plugin::factory('Widget_Abstract_Contents')->contentEx = array('Lightbox_Plugin', 'Lightboxclass');
        Typecho_Plugin::factory('Widget_Abstract_Contents')->excerptEx = array('Lightbox_Plugin', 'Lightboxclass');
    }
   
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     *
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){
	}
   
    /**
     * 获取插件配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form){
	}

    /**
     * 个人用户的配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}   
   
    /**
     * 自动替换图片链接
     *
     * @access public
     * @param string $content
     * @return void
     */
    public static function Lightboxclass($content, $widget, $lastResult) {
        $Archive = Typecho_Widget::widget('Widget_Archive');
    	$content = empty($lastResult) ? $content : $lastResult;
    	if ( $widget instanceof Widget_Archive && $Archive->is('index') || $Archive->is('post') || $Archive->is('archive') ) {
    	$pattern = "/<a(.*?)href=('|\")([^>]*).(bmp|gif|jpeg|jpg|png)('|\")(.*?)>(.*?)<\/a>/i";
    	$replacement = '<a$1href=$2$3.$4$5 rel="lightbox" $6>$7 </a>';
    	$content = preg_replace($pattern, $replacement, $content);
    	}
        return $content;
    }
    

    /**
     * 头部插入CSS
     *
     * @access public
     * @param unknown $headlink
     * @return unknown
     */
    public static function headlink($cssUrl) {
        $Lightbox_ul = Helper::options()->pluginUrl .'/Lightbox/';
		$cssUrl = '<link rel="stylesheet" type="text/css" media="all" href="'.$Lightbox_ul.'lightbox.css" />';
		$link = '<script src="'.$Lightbox_ul.'jquery-1.7.2.min.js"></script>';
		$links = '<script src="'.$Lightbox_ul.'lightbox.js"></script>';
		echo $cssUrl,$link,$links;
    }
}