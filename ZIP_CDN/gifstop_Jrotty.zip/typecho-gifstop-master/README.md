# typecho-gifstop

将gifstop文件夹上传至typecho插件目录下即可
