<!DOCTYPE HTML>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<title>限制提醒</title>
<link rel="shortcut icon" href="favicon.ico">
</head>

<body>
<div class="box">


<div class='newContent'>			<p><br/></p><p><br/></p><p><br/></p><p><br/></p><p><br/></p>			<p style='text-align:center;'><img src='<?php echo Helper::options()->pluginUrl.'/Soso/404.png'; ?>' alt=''></img></p>			<div style='text-align:center; font-size:16px; line-height:30px; color:#333333;'><?php echo $txt; ?></div>			<a href='<?php echo Helper::options()->rootUrl; ?>' style='text-align:center; color:#333; font-size:13px; text-decoration:none; width:100px; height:32px; line-height:32px; border:1px solid #E3E2E8; display:block; margin:30px auto;'>返回首页</a>			<p><br/>		</p></div>


</div>
</body>
</html>