# Typecho set password by category plugin

* 使用：
1. 下载所有文件到usr/plugins/SetCategoryPwd目录下
2. 管理员登陆后台在控制台下插件管理下开启SetCategoryPwd插件。
3. 点击后台菜单栏管理下面的分类设置密码进入设置页面。
