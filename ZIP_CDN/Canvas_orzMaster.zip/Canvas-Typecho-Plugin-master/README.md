# Canvas-Typecho-Plugin
A nest backgroud of website draw on canvas.

## 介绍
一个非常好看的网页粒子背景插件，不需要依赖任何第三方库即可运行，提供额非常炫酷的背景。

## 声明
本作品仅供个人学习研究使用，请勿将其用作商业用途。 

## 安装
  1. 在本页面右上角点击 Download ZIP 下载压缩包
  2. 上传到 /usr/plugins 目录
  3. **修改文件夹名为 Canvas**
  4. 后台启用插件
  
更多问题可以通过 issue 页面提交，或者通过 Telegram、邮件向我反馈

## LICENSE
Canvas-Typecho-Plugin is under the MIT license.
