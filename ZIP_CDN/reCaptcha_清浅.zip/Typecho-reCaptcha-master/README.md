# Typecho-reCaptcha
Typecho的reCaptcha评论验证码插件。网上找了一个不能用，自己做一个好了……

### 使用方法：

1、网站根目录/usr/plugins 下新建reCaptcha目录，放入Plugins.php

2、去recaptcha官网 https://www.google.com/recaptcha 注册站点，**注意类型选择v2复选框**，取得sitekey和secret key

3、博客后台激活插件，在插件设置中输入上一步获得的sitekey和secret key

4、在评论模板的适当位置加入 `<?php $this->reCaptcha(); ?>`

