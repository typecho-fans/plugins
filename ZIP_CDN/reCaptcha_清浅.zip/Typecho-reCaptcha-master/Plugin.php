<?php
/**
 * reCaptcha验证码插件
 * 设置完成后，在评论模板的合适位置加入$this-&gt;reCaptcha();
 *
 * @package reCaptcha
 * @author 清浅
 * @version 1.0.0
 * @update: 2020.04.20
 * @link https://ftm.moe/
 */
class reCaptcha_Plugin implements Typecho_Plugin_Interface {
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate() {
        Typecho_Plugin::factory('Widget_Archive')->___reCaptcha = array('reCaptcha_Plugin', 'show');
        Typecho_Plugin::factory('Widget_Feedback')->comment = array('reCaptcha_Plugin', 'verify');
        Typecho_Plugin::factory('Widget_Feedback')->trackback = array('reCaptcha_Plugin', 'verify');
        Typecho_Plugin::factory('Widget_XmlRpc')->pingback = array('reCaptcha_Plugin', 'verify');
    }
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate() {
    }
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form) {
        $sitekey = new Typecho_Widget_Helper_Form_Element_Text('sitekey', NULL, NULL, _t('在这里填写你的sitekey'), _t('在您的网站提供给用户的 HTML 代码中使用此网站密钥。'));
        $form->addInput($sitekey);
        $secret = new Typecho_Widget_Helper_Form_Element_Text('secret', NULL, NULL, _t('在这里填写你的secret key'), _t('此密钥用于您的网站和 reCAPTCHA 之间的通信。'));
        $form->addInput($secret);
    }
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form) {
    }
    /**
     * 验证response
     *
     * @access public
     * @param array $comment 评论结构
     * @param Typecho_Widget $post 被评论的文章
     * @param array $result 返回的结果上下文
     * @return $comment
     */
    public static function verify($comment, $post, $result) {
        $tag = 'g-recaptcha-response';
        $v = Typecho_Request::getInstance()->$tag;
        if (empty($v)) {
            throw new Typecho_Widget_Exception(_t('请输入验证码'));
        }
        $secret = Typecho_Widget::widget('Widget_Options')->plugin('reCaptcha')->secret;
        if(empty($secret)) throw new Typecho_Widget_Exception(_t('secret未配置，请检查！'));
        $postdata = Array(
            'secret' => $secret,
            'response' => $v
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 20);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
        $re = curl_exec($ch);
        curl_close($ch);
        $re = json_decode($re, true);
        if(empty($re)){
            throw new Typecho_Widget_Exception(_t('response校验失败，无法解析返回数据'));
        }
        if ($re['success']) return $comment;
        throw new Typecho_Widget_Exception(_t('验证码错误或失效。错误代码：'.json_encode($re['error-codes'])));
    }
    /**
     * 在评论区显示验证码
     * 
     * @access public
     * @param object $archive
     * @return string 验证码html代码
     */
    public static function show($archive) {
        if($sitekey = Typecho_Widget::widget('Widget_Options')->plugin('reCaptcha')->sitekey) {
            $text = '<script src="https://recaptcha.net/recaptcha/api.js" async defer></script><div class="g-recaptcha" data-sitekey="'.$sitekey.'"></div>';
        }else{
            $text = 'sitekey未配置，请检查！';
        }
        return $text;
    }
}
