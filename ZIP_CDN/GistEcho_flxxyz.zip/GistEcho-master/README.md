# GistEcho
typecho 显示gist插件

## 安装
1. 前往 [releases](https://github.com/flxxyz/GistEcho/releases) 下载最新的版本
2. 解压**GistEcho.zip**压缩包
3. 到typecho后台的插件管理**启用**即可

## 使用
直接将gist地址书写成以下格式即可
```

[gist https://gist.github.com/flxxyz/ae3ef071dc4ffb0c55daedc7f0740611]

```
