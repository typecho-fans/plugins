介绍
--

>PushToWeixin是一款Typecho插件，利用[Server酱][1]提供的推送服务，把博客中的新评论推送到微信中

安装
----

 1. 下载项目，上传至`/usr/plugins`目录下，解压 
 2. 到[Server酱][1]那免费申请`SCKEY`
 3. 启动插件吗，在设置中输入`SCKEY`
 4. 评论测试插件是否正常

注意
----
使用Github的下载时，请删除文件名中的`-master`再解压

**感谢[Server酱][1]免费提供微信推送服务**
----------------------------

  [1]: http://sc.ftqq.com/3.version