﻿使用方法很简单，下载插件解压后，将其上传至/usr/plugins/目录下，先在后台启用插件，并根据设置说明做相关设置，然后编辑摸板，在评论的表单位置也就是comments的form标签之间的任何你认为合适的地方，加上如下代码

<p><?php FancyCaptcha_Plugin::output(); ?></p>


m4补充：已经下载了jq和jqui文件，直接后台激活即可。