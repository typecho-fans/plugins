<?php
/* 
  captcha.php
  jQuery Fancy Captcha
  www.webdesignbeach.com
  
  Created by Web Design Beach.
  Copyright 2009 Web Design Beach. All rights reserved.
*/
@session_start();
$rand = rand(0,4);
$_SESSION['captcha'] = $rand;
echo $rand;

?>