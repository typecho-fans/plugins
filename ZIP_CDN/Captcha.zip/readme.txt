Typecho专用验证码插件，支持中文、支持SAE
