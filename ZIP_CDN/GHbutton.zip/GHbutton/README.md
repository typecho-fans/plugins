### Typecho的Github项目按钮插件GHbutton
2018年6月25日更新至**v1.0.4**: 
- 新增模版钩子与编辑器按钮
- 修正MD下的标签转义问题
- 修正版本依赖及W3C等bug

#### 详细说明与效果演示见blog发布地址: 
 > http://www.yzmb.me/archives/net/github-btn-typecho