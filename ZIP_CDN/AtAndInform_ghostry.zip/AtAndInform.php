<?php
/**
 * 给博客增加提到功能,在写文章是使用"@人名 ",如果此人曾在你博客评论过,那么就可以在发布文章时发送邮件通知他,并且会添加去往他网站的链接.(重名使用查到的第一个)--SAE版
 * 
 * @package AtAndInform
 * @author ghostry
 * @version 1.0.0
 * @link http://ghostry.cn
 */

class AtAndInform implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
     	Typecho_Plugin::factory('Widget_Contents_Post_Edit')->write = array('AtAndInform', 'DoCheck');
     	return _t('设置后才能使用~');
    }
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){}
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        /** 分类名称 */
     	$sendmail = new Typecho_Widget_Helper_Form_Element_Radio('sendmail',
                array( 0 => '否',1 => '是'),'0', '是否邮件通知');
     	$nofollow = new Typecho_Widget_Helper_Form_Element_Radio('nofollow',
                array( 0 => '否',1 => '是'),'1', '是否使用nofollow属性');
        $form->addInput($sendmail);
        $form->addInput($nofollow);
        $cfg_host = new Typecho_Widget_Helper_Form_Element_Text('cfg_host', NULL, 'smtp.',
                _t('SMTP地址'), _t('请填写 SMTP 服务器地址'));
        $form->addInput($cfg_host->addRule('required', _t('必须填写一个SMTP服务器地址')));

        $cfg_port = new Typecho_Widget_Helper_Form_Element_Text('cfg_port', NULL, '25',
                _t('SMTP端口'), _t('SMTP服务端口,一般为25。'));
        $cfg_port->input->setAttribute('class', 'mini');
        $form->addInput($cfg_port->addRule('required', _t('必须填写SMTP服务端口'))
                ->addRule('isInteger', _t('端口号必须是纯数字')));

        $cfg_user = new Typecho_Widget_Helper_Form_Element_Text('cfg_user', NULL, NULL,
                _t('SMTP用户'),_t('SMTP服务验证用户名,一般为邮箱名如：youname@domain.com'));
        $form->addInput($cfg_user->addRule('required', _t('SMTP服务验证用户名')));

        $cfg_pass = new Typecho_Widget_Helper_Form_Element_Password('cfg_pass', NULL, NULL,
                _t('SMTP密码'));
        $form->addInput($cfg_pass->addRule('required', _t('SMTP服务验证密码')));

/*        $cfg_validate=new Typecho_Widget_Helper_Form_Element_Checkbox('cfg_validate',
                array('validate'=>'服务器需要验证',
                    'ssl'=>'ssl加密'),
                array('validate'),'SMTP验证');
        $form->addInput($cfg_validate);
*/
        $cfg_title = new Typecho_Widget_Helper_Form_Element_Text('cfg_title',NULL,"{site}:{author} 在《{title}》一文中提到了您",
                _t('邮件标题'));
        $form->addInput($cfg_title);
		
        $cfg_nr = new Typecho_Widget_Helper_Form_Element_Textarea('cfg_nr',NULL,"<div>
   <table style='border: 1px solid rgb(0, 0, 0);' width='750' align='center' border='0' cellpadding='0' cellspacing='0'>
    <tbody>
      <tr>
          <td style='padding: 10px;' bgcolor='#cccccc'><font style='font-size: 18px;'>{site}:{author} 在《{title}》一文中提到了您</font></td>   
      </tr>
        <tr>
            <td style='padding: 5px;'>时间：{time}</td>
       </tr>   
       <tr>
           <td style='padding: 5px;'>链接：<a href='{permalink}' target='_blank'>{permalink}</a></td>
       </tr>      
       <tr>            
           <td style='padding: 5px;'>内容:<br/><div style='padding: 10px;'>{text}</div></td>           
      </tr>
    <tr>
    <td align='right'><font style='font-size: 10px; font-family: Arial,Helvetica,sans-serif;' color='#999999'>本邮件为{site}自动发送，请勿回复！</font></td>
  </tr>
   </tbody>
  </table>
</div>",
                _t('邮件内容'),_t('可用变量:{site}站名,{title}标题,{author}作者,{permalink}站点链接,{time}时间,{text}内容(强制100字以内)'));
        $form->addInput($cfg_nr);

    }
    
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    
    /**
     * 插件实现方法
     * 
     * @access public
     * @param $content
     * @return $content
     */
    public static function DoCheck($content)
    {
     	//判断是不是文章编辑
		//print_r($content);
		//读取配置,初始化数据
     	$config = Helper::options()->plugin('AtAndInform');
        $db = Typecho_Db::get();
		//检查文章内容是否有@人,
		if(preg_match_all("/@([^. ]+) /",$content['text'].' ', $matches)){
			$in=false;
			//print_r($matches);
			foreach($matches[1] as $key=>$uss){
				$select=$db->select('author','mail','url')
                    	->from('table.comments')
                    	->where('author LIKE ?', $uss)
						->limit(1);
            	$result = $db->query($select);
				$at=$db->fetchRow($result);
				if($at){
					$in=true;
				}
				//print_r($at);
				//检查@的人是否存在,检查评论表和用户表
				if($in){
					//print_r($at);
					//已存在并且有网址就替换为<a>标签,
					if($at['url']){
						if($config->nofollow){
							$nofollow='rel="external nofollow"';
						}
						$content['text']=str_replace($matches[0][$key],"<a  href=\"".$at['url']."\" ".$nofollow." target=\"_blank\" title=\"".$uss."\">".$uss."</a> ",$content['text'].' ');
					}
					//已存在并且有邮箱发送邮件
					if($at['mail']&&$config->sendmail){
						//默认参数
						date_default_timezone_set('Asia/Chongqing');
        				$options = Typecho_Widget::widget('Widget_Options');
						//取得服务器参数
						$smtp['to']=	$at['mail'];
						$smtp['site']=$options->title;
        				/**获取SMTP设置*/
        				$smtp['user'] = $config->cfg_user;
        				$smtp['pass'] = $config->cfg_pass;
        				$smtp['host'] = $config->cfg_host;
        				$smtp['port'] = $config->cfg_port;

						//取得邮件参数
                		/**取得标题格式*/
                    	$email['title']=$config->cfg_title;
						$email['nr']=$config->cfg_nr;
        				$user = Typecho_Widget::widget('Widget_User');
						$email['author']=$user->screenName;
						$email['permalink']=$options->siteUrl;
//						$email['time']=$content['modified']?$content['modified']:$content['created'];
						$email['time']=date('Y-m-d H:i:s');
						//摘要
						if(strpos($content['text'], '<!--more-->')  !== false ){
							$more_t = explode('<!--more-->', $content['text']);
							list($text) = $more_t;
							$text = Typecho_Common::fixHtml(Typecho_Common::cutParagraph($text));
							$text = Typecho_Common::subStr(strip_tags($text), 0, 120, '...');
						}else{
							$text = $content['text'];
							$text = Typecho_Common::fixHtml(Typecho_Common::cutParagraph($text));
							$text = Typecho_Common::subStr(strip_tags($text), 0, 120, '...');
						}
						$email['text']=	$text;
                		$search1=array('{site}','{title}','{author}','{permalink}','{text}','{time}');
                		$replace1=array($smtp['site'],$content['title'],$email['author'],$email['permalink'],$email['text'],$email['time']);
                		$smtp['body']=str_replace($search1, $replace1, $email['nr']);
                		$smtp['subject']=str_replace($search1, $replace1, $email['title']);
						//print_r($email);
                		self::SendMail($smtp);
					}
				}
			}
		}

		//返回数据
       	return $content;
    }
     /**
     * 发送邮件
     *
     * @access public
     * @param $smtp 邮件参数,数组
     * @return void
     */
    public static function SendMail($smtp) {

       $mail = new SaeMail();
              $opt = array(
                //'from'          => $smtp['site'].'<'.$smtp['user'].'>' ,
                'from'          => 'ghostry'.'<'.$smtp['user'].'>' ,
                                'to'            => $smtp['to'] ,
                                'smtp_host'     => $smtp['host'] ,
                                'smtp_port'     => $smtp['port'] ,
                                'smtp_username' => $smtp['user'] ,
                                'smtp_password' => $smtp['pass'] ,
                                'subject'       => $smtp['subject'] ,
                                'content'       => $smtp['body'] ,
                                'content_type'  => "HTML"
                        );
        
        
        $mail->setOpt( $opt );
        $ret = $mail->send();
      if ($ret === false){
        var_dump($mail->errno(), $mail->errmsg());
      }
    }
}
