##backtotop##<br>
这个是typecho博客插件<br>
typecho 返回顶部插件<br>
下载后重命名为backtotop放到插件目录启用即可<br>
