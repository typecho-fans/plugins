typecho
=======

Typecho下的插件集合

    Ping - 利用插件机制实现发表文章后自动通知搜索引擎，提高收录速度。
    Statistics - 利用插件机制实现页面输出统计代码。