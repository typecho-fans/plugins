<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * 页脚图标动画
 *
 * @package footeranimation
 * @author  jyzb02
 * @version 1.0
 * @link http://www.ezboke.com/typecho/
 */

class footeranimation_Plugin implements Typecho_Plugin_Interface
{
    public static function activate(){
	Typecho_Plugin::factory('Widget_Archive')->footer = array('footeranimation_Plugin', 'footer');       
       return '插件安装成功';
}

    public static function deactivate(){}

    public static function config(Typecho_Widget_Helper_Form $form){
}

    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    public static function footer(){
	$cssUrl = Helper::options()->pluginUrl . '/footeranimation/css/style.css';
         
              
	      echo '<link rel="stylesheet" href="' . $cssUrl . '">';            
              echo '
 <div class="dandelion">
    <span class="smalldan"></span>
    <span class="bigdan"></span>
</div>';                                                 		
}
}
