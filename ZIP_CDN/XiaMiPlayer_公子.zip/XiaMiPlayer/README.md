### 迷你版虾米点播插件XiaMiPlayer v3.1.4

通过编辑器按钮在线搜索虾米歌曲或输入mp3链接组成列表插入文章，采用jplayer迷你多彩播放器，支持快捷键。

:warning:由于原服务端lyric.php缺失暂时无法显示歌词。

- v3.1.4(18-7-25)：（[@羽中](https://github.com/jzwalk)）
使用短代码替换兼容Typecho1.1+版Markdown解析，修正虾米地址自动替换和编辑区焦点定位等问题。

- v3.1.3复活版(17-2-16)：
整合[XiamiMusicAPI](https://github.com/metowolf/XiamiMusicAPI)内置action调用核心功能。

- 补更至v3.1.2。

###### 更多详见作者博客：http://imnerd.org/XiaMiPlayer-Plugin-for-typecho-0-9.html