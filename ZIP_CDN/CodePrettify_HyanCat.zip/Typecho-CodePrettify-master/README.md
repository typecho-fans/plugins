Typecho-CodePrettify
====================

基于Google Code Prettify的Typecho代码高亮插件

插件激活直接生效。

依赖于jquery。