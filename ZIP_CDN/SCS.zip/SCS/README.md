新浪云存储(SCS) for Typecho插件
======================================================


## 1 描述
这是一款用于Typecho的新浪云储存(SCS)插件。可以自动将上传的附件储存在新浪云SCS中。

## 2 版本更新说明
##### 2.1 版本v1.0.0 ~ v1.0.4 (2014.09.08)
    1、初始化版本；
    2、自动将typecho附件上传至新浪云存储SCS；
    2、支持自定义上传路径；支持附件修改；
    3、支持新浪云平台（SAE）；
    4、同步typecho附件状态至新浪云储存SCS（例如删除、修改等）。

本版本详细说明：[新浪云存储(SCS) for Typecho 插件](https://typecodes.com/web/scsfortypecho.html '新浪云存储(SCS) for Typecho 插件')。

##### 2.2 版本v1.1.0 (2014.09.12)
    1、更新SDK文件；
    2、优化自定义路径方式，用户能更自由定义SCS存储路径；
    3、新增SCS域名绑定功能，用户可以自由选择是否使用该功能；
    4、优化文章上传后附件显示的路径，更为简洁。

本版本详细说明：[更新新浪云存储(SCS) for Typecho 插件版本V1.1.0](https://typecodes.com/web/scsfortypechov110.html '更新新浪云存储(SCS) for Typecho 插件版本V1.1.0')。

##### 2.3 版本v1.1.1 (2014.09.20)
    1、更新官方SDK文件；
    2、增加SCS存储路径参数配置，用户能更自由定义SCS存储路径；
    3、取消SCS附件的Unix time stamp格式的名称，以原附件名称替代。

本版本详细说明：[更新新浪云存储(SCS) for Typecho 插件版本V1.1.1](https://typecodes.com/web/scsfortypechov111.html '更新新浪云存储(SCS) for Typecho 插件版本V1.1.1')。

