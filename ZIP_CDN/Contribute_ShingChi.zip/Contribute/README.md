## 插件说明 ##

 - 版本: v1.0.0
 - 作者: [ShingChi](https://github.com/shingchi)
 - 主页: <https://github.com/typecho-fans/plugins/tree/master/Contribute>

实现前台免注册在线编辑投稿，后台可审查通过为草稿或自动发布。  
具体说明请查看插件目录[README](/plugins/Contribute/README.md)

 > 修正稿件预览接口，兼容Typecho1.0+。

## 使用方法 ##

 1. 把 `plugins/Contribute` 文件夹上传到插件目录
 2. :warning:把 `themes/contribute.php` 文件上传到当前使用的模板文件夹下
 3. 启用插件，并设置使用插件

###### 更多详见论坛原帖：http://forum.typecho.org/viewtopic.php?f=6&t=5134