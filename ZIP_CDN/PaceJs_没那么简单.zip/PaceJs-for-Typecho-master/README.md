# PaceJs-for-Typecho
typecho页面进度条加载插件。<br />
原项目来自typecho页面进度条加载插件：https://blog.csdn.net/oahz4699092zhao/article/details/53101813?locationNum=10&fps=1<br />
这里将所有文件配置好，只需下载源码上传到服务器，将文件夹名字改为PaceJs启插件即可。
