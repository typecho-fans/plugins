# PasteImage
为 Typecho 自带编辑器增加粘贴图片上传功能

## 安装方法
1. Download ZIP 下载本插件最新版本
2. 解压，把 `PasteImage-master` 目录重命名为 `PasteImage` 上传至博客的 `/usr/plugins` 目录下
3. 在插件页面启用本插件
