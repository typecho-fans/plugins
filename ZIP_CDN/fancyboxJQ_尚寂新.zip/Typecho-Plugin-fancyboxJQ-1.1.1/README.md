<h2>插件使用说明</h2><p>jQuery 选择器：默认为<code>body</code>，但方法过于粗暴。请根据您主题的情况，使选择器更精准的选择到你文章输出的位置上所包裹的HTML标签！</p><p>是否加载 jQuery：为了防止重复引用 jQuery，给站点带来不必要的加载开销，所以设置此功能。如果你已经在主题内或者是其他插件已经加载过 jQuery，那就无需再次加载。</p><p><strong>注：fancyboxJQ 相关资源引入依赖于 jsdelivr CDN</strong></p>
<strong>下载完后，请务必将本插件的文件夹的名字改为<code>fancyboxJQ</code>，否则会出错！！</strong>
