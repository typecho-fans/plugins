# upimgchr-for-typecho
为typecho后台编辑器添加图过图床的远程上传插件，插件会自动追踪textarea文本框增加一个上传的按钮。

## 安装方法
1. Download ZIP 下载本插件最新版本
2. 解压，把目录重命名为 `upimgchr` 上传至博客的 `/usr/plugins` 目录下
3. 在插件页面启用本插件
