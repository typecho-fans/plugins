rsync -cr --progress ./Filter vps:/home/he0119/nginx/typecho/usr/plugins/
