# Typecho Filter

过滤插件

## 使用

```bash
cd typecho/usr/plugins
git clone https://github.com/he0119/typecho-filter.git Filter
```
