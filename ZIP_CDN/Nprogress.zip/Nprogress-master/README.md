# Nprogress

## Progress Plugin For Typecho

Show Progress in the frontpages.

### Lastest Update Description

* Add CDN File Support.

### Notice

* When the plugin update, please disable the plugin before updating.
* The plugin directory name must be 'Nprogress'.

### Features

- Multiple Colors.
- Use Net jQuery Source.

### Author

[@Cain](https://github.com/Vndroid)