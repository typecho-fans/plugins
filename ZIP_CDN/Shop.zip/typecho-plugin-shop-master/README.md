# typecho-plugin-shop
typecho线上主题商店

# 使用
* 使用说明 将插件下载到usr/plugins下，启用即可，更多内容会尽快更新
* 提交主题 https://lichaoxi.com/shop-add 提交主题
