var domain = "2012.pro"
var name = "成都第七帅"
var API_SECRET = "xxx"

export default {
    getdomain: domain,
    getname: name,
    getapisecret: API_SECRET
}