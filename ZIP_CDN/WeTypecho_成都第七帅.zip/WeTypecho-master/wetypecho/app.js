const Towxml = require('/towxml/main');
App({
  Data:{
    userInfo: null,
    zaned: false
  },
  towxml:new Towxml(),
})