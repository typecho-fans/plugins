# [SlantedExtend](https://dt27.org/SlantedExtend/)
Typecho Plugin  
:warning:**Typecho 主题 [Slanted](https://dt27.org/Slanted-for-Typecho/) 的扩展插件**

[Slanted](https://dt27.org/Slanted-for-Typecho/) 为文章及独立页面扩展了多项自定义字段，通过安装本插件，使您无需手动添加字段，例如文章缩略图```thumbUrl```，独立页面短标题```shotTitle```、页眉主```heading```副```subheading```文字描述等。  
主题中文章原创选项也需要本插件辅助实现。  
插件还集成了浏览量功能*（来自 willin kan 的 Views 插件）*。

###### Plugin License
> Copyright © 2016 [DT27](https://dt27.org)  
> License: [GNU General Public License v3.0](http://www.gnu.org/licenses/gpl-3.0.html)