<?php
/**
 * gotop返回顶部插件，Jrotty菜鸟制作，然并卵的插件
 * 
 * @package gotop
 * @author jrotty
 * @version 1.0
 * @link http://qqdie.com
 */

class gotop_Plugin implements Typecho_Plugin_Interface
{
	public static function activate()
	{
		
		Typecho_Plugin::factory('Widget_Archive')->header = array('gotop_Plugin', 'header');
		Typecho_Plugin::factory('Widget_Archive')->footer = array('gotop_Plugin', 'footer');
	
		
	}
	/* 禁用插件方法 */
	public static function deactivate(){}
	
	/* 插件配置方法 */

			public static function config(Typecho_Widget_Helper_Form $form){
$jquery = new Typecho_Widget_Helper_Form_Element_Radio(
        '加载jquery', array('0'=> '不加载', '1'=> '自动加载'), 0, 'jQuery',
            '"不加载不行的话，再开启自动加载！');
        $form->addInput($jquery);
}
	/* 个人用户的配置方法 */
	public static function personalConfig(Typecho_Widget_Helper_Form $form){}
	
	/* 插件实现方法 */

public static function header(){
if(Typecho_Widget::widget('Widget_Options')->Plugin('gotop')->jquery=='1'){	
			echo '<script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.min.js"></script>';
		}

	echo "\n<link href=\"" . Helper::options()->pluginUrl . "/gotop/ys.css\" rel=\"stylesheet\">\n";
}


public static function footer(){
$pd = Helper::options()->pluginUrl . '/gotop/pd.js';
 echo '<script type="text/javascript" src="'.$pd.'"></script>' . "\n";
echo '<div class="go-top dn" id="go-top">
    
    <a href="javascript:;" class="go"></a>
</div>
' . "\n";


}

}