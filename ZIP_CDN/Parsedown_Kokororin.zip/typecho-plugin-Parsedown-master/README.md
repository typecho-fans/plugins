### Typecho Parsedown 解析markdown插件

使用[Parsedown](https://github.com/erusev/parsedown)替换Typecho自带的[Markdown解析库](http://michelf.com/projects/php-markdown)。**启用前请将目录名重命名为Parsedown。**


