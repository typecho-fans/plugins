<?php
/**
 * <strong>macOS style code box for Typecho Handsome</strong> <a href="https://github.com/lei2rock/Typecho-Plugin-macOScode" target="_blank">Github</a>
 * 
 * @package macOScode
 * @author lei2rock
 * @version 1.0.0
 * @link https://github.com/lei2rock
 */
class macOScode_Plugin implements Typecho_Plugin_Interface {
     /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate() {
        Typecho_Plugin::factory('Widget_Archive')->header = array(__CLASS__, 'header');
        Typecho_Plugin::factory('Widget_Archive')->footer = array(__CLASS__, 'footer');
    }

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){}

    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form){}

    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    /**
     * 插件实现方法
     * 
     * @access public
     * @return void
     */
    public static function render() {
        
    }

    /**
     *为header添加文件
     *@return void
     */
    public static function header() {
        echo '<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lei2rock/Typecho-Plugin-macOScode@latest/static/macOScode.css" media="print" onload="this.media=\'all\'">';
    }

    /**
     *为footer添加文件
     *@return void
     */
    public static function footer() {
        echo '<script src="/usr/plugins/macOScode/static/prism.js"></script>';
    }
}
