# Typecho-Plugin-macOScode

<a href="https://github.com/lei2rock/Typecho-Plugin-macOScode"><img src="https://img.shields.io/badge/macOScode-v1.0.0-brightgreen?&style=flat-square"></a>
<a href="https://typecho.org/"><img src="https://img.shields.io/badge/Typecho->=1.2-0e83cd?&style=flat-square"></a>

实现 macOS 风格代码框的 Typecho 插件（只适配 Handsome 主题），修改自 [Xcnte/Code-Prettify-for-typecho](https://github.com/Xcnte/Code-Prettify-for-typecho)，精简了部分设置和功能。

**演示效果**：[班班碎碎念](https://blog.dlzhang.com)

## 安装

1. 下载源码并上传到 Typecho 插件目录 `usr/plugins` 下
2. 修改插件文件夹名为 `macOScode`
3. 在 Typecho 后台插件管理中启用插件
4. 请关闭之前开启的 Handsome 主题的代码高亮和风格
5. 如果开启了 PJAX，你需要添加回调/重载函数：

```javascript
// macOS code
if (typeof Prism !== 'undefined') {
Prism.highlightAll(true,null);}
```

## 自定义

如果需要添加更多的代码语言高亮支持，可以：

1. 在 [Prism](https://prismjs.com/download.html) 选择需要高亮的代码语言，下载 `prism.js`；
2. 在 `prism.js` 最后面添加如下代码以支持代码框快速复制功能

```javascript
// Load Clipboard.js
(function(){if("undefined"!==typeof self&&self.Prism&&self.document)if(Prism.plugins.toolbar){var b=window.ClipboardJS||void 0;b||"function"!==typeof require||(b=require("clipboard"));var e=[];if(!b){var c=document.createElement("script"),d=document.querySelector("head");c.onload=function(){if(b=window.ClipboardJS)for(;e.length;)e.pop()()};c.src="https://cdn.jsdelivr.net/npm/clipboard@2/dist/clipboard.min.js";d.appendChild(c)}Prism.plugins.toolbar.registerButton("copy-to-clipboard",function(c){function a(){var a=
new b(g,{text:function(){return c.code}});a.on("success",function(){g.innerHTML='<i class="fontello fontello-tags" id="btn-copy-code"style="font-style:normal;"> \u5df2\u590d\u5236</i>';d()});a.on("error",function(){g.textContent="Press Ctrl+C to copy";d()})}function d(){setTimeout(function(){g.innerHTML='<i class="fontello fontello-tags" id="btn-copy-code"style="font-style:normal;"> \u590d\u5236</i>'},5E3)}var g=document.createElement("button");g.innerHTML='<i class="fontello fontello-tags" id="btn-copy-code"style="font-style:normal;"> \u590d\u5236</i>';
b?a():e.push(a);return g})}else console.warn("Copy to Clipboard plugin loaded before Toolbar plugin.")})();
```

3. 将编辑后的文件替换 `static/` 目录下的 `prism.js` 文件。