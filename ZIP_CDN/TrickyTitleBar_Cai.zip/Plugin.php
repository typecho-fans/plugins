<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * 狡猾的标题栏
 * 
 * @package TrickyTitleBar
 * @author Cai
 * @version 1.0.0
 * @link http://zwho.me
 */
class TrickyTitleBar_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->footer = array('TrickyTitleBar_Plugin', 'TrickyTitleBarCreate');
        return '插件安装成功，请进入设置';
    }
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate()
    {
        return '插件卸载成功';
    }

    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $sqjd = new Typecho_Widget_Helper_Form_Element_Text('sqjd', NULL, '草榴社區主論壇 - 1024', _t('标题栏失去焦点显示的标题'));
        $form->addInput($sqjd);

        $hfjd = new Typecho_Widget_Helper_Form_Element_Text('hfjd', NULL, '生命 -1s ~', _t('标题栏获取焦点显示的标题'));
        $form->addInput($hfjd);

        $xszq = new Typecho_Widget_Helper_Form_Element_Text('xszq', NULL, '2000', _t('恢复原标题时间'));
        $form->addInput($xszq);
    }
    
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    
    /**
     * 插件实现方法
     * 
     * @access public
     * @return void
     */
    public static function TrickyTitleBarCreate()
    {
        $options = Helper::options();
        $sqjd = $options->plugin('TrickyTitleBar')->sqjd;
        $hfjd = $options->plugin('TrickyTitleBar')->hfjd;
        $xszq = $options->plugin('TrickyTitleBar')->xszq;
        echo
<<<eof
<script>
    var OriginTitile = document.title;
    var titleTime;
    document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
            document.title = '$sqjd';
            clearTimeout(titleTime);
        } else {
            document.title = '$hfjd';
            titleTime = setTimeout(function() {
                document.title = OriginTitile;
            }, $xszq);
        }
    });
</script>
eof;
    }
}
