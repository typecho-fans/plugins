Statistics
==========

A Statistics Plugin about Visit Activites of Typecho.
