# typecho-MouseFloating

typecho 鼠标漂浮字插件

## 使用方法

- 把 `typecho-MouseFloating` 改成 `MouseFloating`，上传至 `usr/plugins` 下，后台开启
- 可设置随机出现的文字

## 效果

访问我的博客：[传送门](https://www.icy2003.com/)，点击空白处