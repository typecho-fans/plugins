# Typecho Plugins

莫名博客：Qzone.Work

站长邮箱：admin@qzone.work

莫名博客创作插件，适用于Typecho博客系统，欢迎使用！

-------------------------------

## Comment3Wechat

> 一款将评论推送到微信的插件，接口：PushPlus

原版是 https://github.com/YianAndCode/Comment2Wechat
，但年久失修，且当下的Server酱也不是当初的Server酱；于是基于原版进行了修改，改为了PushPlus推送，且适配了`Typecho版本1.2.1`。

### PushPlus

个人在公众号底部会有广告，但总体不影响使用，对个人而言，免费版已经足够使用了。
官网地址：https://www.pushplus.plus

## OssImg

阿里云OSS 图床外链，基于插件(OssForTypecho)制作

## AdminLogin

后台扫码登录，支持接口：【微信，QQ】

## LskyPro

一款使用开源程序**兰空图床**，将图片单独托管的外链插件；使用介绍：https://qzone.work/codes/725.html  