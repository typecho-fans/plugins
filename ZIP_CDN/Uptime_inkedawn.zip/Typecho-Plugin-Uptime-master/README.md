# Typecho-Plugin-Uptime
A typecho plugin for Uptime

## 介绍
显示本站运行时间

## 使用方法
修改主题文件，在适当位置加入以下代码

``` php
Uptime_Plugin::show();
```
