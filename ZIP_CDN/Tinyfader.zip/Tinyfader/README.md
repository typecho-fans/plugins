### Typecho简易首页图片轮播插件Tinyfader v1.0.0

使用仅1.6K的TinyFader脚本全自动化实现首页图片轮播效果。
