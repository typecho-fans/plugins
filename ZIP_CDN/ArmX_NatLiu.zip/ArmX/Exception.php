<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * 插件异常
 *
 * @package Plugin
 */
class ArmX_Exception extends Typecho_Exception
{}
