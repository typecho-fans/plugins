# KodoForTypecho

使用七牛云对象存储服务KODO作为附件存储空间的Typecho插件。

## 安装

1. 从 Github载源码，将源码上传到 Typecho 插件目录 `usr/plugins` 下

2. 修改插件文件名为`KodoForTypecho`

3. 修改目录权限和用户组

```bash
chown -R www:www KodoForTypecho/
chmod 755 KodoForTypecho/
```

4. 启用~
