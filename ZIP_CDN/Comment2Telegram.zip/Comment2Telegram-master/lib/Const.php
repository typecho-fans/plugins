<?php
class Plugin_Const {
    const VERSION = '1.3.2';
    
    const EMAIL_SENT_API = 'https://api.aim.moe/Common/SendEmail';

    const GITHUB_REPO_API = 'https://api.github.com/repos/MoeLoli/Comment2Telegram/releases/latest';
}
