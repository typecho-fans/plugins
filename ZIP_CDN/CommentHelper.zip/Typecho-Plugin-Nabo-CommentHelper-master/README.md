# Typecho-Plugin-Nabo-CommentHelper
https://github.com/ShangJixin/Typecho-Plugin-Nabo-CommentHelper/releases

南博助手 - 消息推送 的配套插件，使评论动作可以响应到南博插件上。运行此插件需要安装南博的原插件！


南博的原插件下载地址：https://github.com/kraity/Messages/releases


**Typecho版本要求：版本号大于17.11.15（如果不确定的话，保证是最新开发版即可）**

评论回调方式使用新方式，正式版(截止于2020-05-30)的Typecho可能会不可用。使用新的回调方式的目的是使评论不受Ajax/Pjax主题的影响

关于新评论回调的介绍：https://joyqi.com/typecho/typecho-async-service.html


插件即安即用。使用要求不多，需要同原南博助手Messages插件一同安装即可。
