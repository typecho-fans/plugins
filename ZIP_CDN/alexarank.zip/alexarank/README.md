安装方法
将下载到的压缩包解压，
然后将文件夹名字重命名为alexarank
然后传到插件目录即可

输出排名数字：

```<?php $this->alexa(); ?>```

###### 更多详见作者博客：https://qqdie.com/archives/alexa.html
