## 插件说明 ##
 - 插件名称：Reposidget
 - 开发作者：西秦公子
 - 作者网址：[http://www.ixiqin.com](http://www.ixiqin.com)
 - 兼容版本：0.9

## 使用帮助 ##

 1. 下载插件
 2. 将插件上传到 `/usr/plugins/` 这个目录下
 3. 登陆后台，在“控制台”下拉菜单中进入“插件管理”
 4. 启用相关插件

## 更新日志 ##




备注:可能出现的卡顿是因为Json加载，Github有被墙的可能性。1-2S加载完成。

感谢墙:多谢`兜兜大婶`帮助开发。多谢FlashMp3Player/GoogleCodePrettfy插件的代码

感谢`leo`提供这么好的项目。http://forcefront.com/2012/reposidget-github-repo-widget/
