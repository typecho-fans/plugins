<?php
/**
 * AB-Admin (Admin Beautify) - 最美 Typecho 后台美化增强插件，Material Design 3 设计
 *
 * @package AB-Admin
 * @author LHL
 * @version 2.1.63
 * @link https://github.com/lhl77/Typecho-Plugin-AdminBeautify
 */
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
class AdminBeautify_MissingOptions
{
    public function __get($name)
    {
        return null;
    }
    public function __isset($name)
    {
        return false;
    }
}
class AdminBeautify_SafeHidden extends Typecho_Widget_Helper_Form_Element_Hidden {
    protected function inputValue($value) {
        if (is_array($value)) {
            $value = json_encode($value);
        }
        $value = (string) $value;
        if ($this->name === 'dashboardCustomCards') {
            $value = AdminBeautify_Plugin::hydrateCardValueForForm($value);
        }
        $this->input->setAttribute('value', htmlspecialchars($value));
    }
}
class AdminBeautify_Plugin implements Typecho_Plugin_Interface
{
    private static function isLoginPage()
    {
        try {
            return !Typecho_Widget::widget('Widget_User')->hasLogin();
        } catch (Exception $e) {
            return true;
        }
    }
    private static function jsString($s)
    {
        return json_encode((string) $s, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    private static function iniSizeToBytes($size)
    {
        $size = trim((string)$size);
        if ($size === '') {
            return 0;
        }
        if (!preg_match('/^([0-9]+)([a-zA-Z]{0,2})$/', $size, $matches)) {
            return (int)$size;
        }
        $value = (int)$matches[1];
        $unit = isset($matches[2]) ? strtolower($matches[2]) : '';
        if ($unit === '' || $unit === 'b') {
            return $value;
        }
        $map = array(
            'k' => 1,
            'm' => 2,
            'g' => 3,
            't' => 4,
            'p' => 5,
        );
        $first = substr($unit, 0, 1);
        if (!isset($map[$first])) {
            return $value;
        }
        return (int)($value * pow(1024, $map[$first]));
    }
    private static function minPositiveBytes(array $values)
    {
        $filtered = array();
        foreach ($values as $v) {
            $v = (int)$v;
            if ($v > 0) {
                $filtered[] = $v;
            }
        }
        if (empty($filtered)) {
            return 0;
        }
        return (int)min($filtered);
    }
    public static function activate()
    {
        Typecho_Plugin::factory('admin/header.php')->header = array(__CLASS__, 'renderHeader');
        Typecho_Plugin::factory('admin/footer.php')->begin = array(__CLASS__, 'renderFooter');
        Typecho_Plugin::factory('admin/footer.php')->end = array(__CLASS__, 'renderLoginFooter');
        Utils\Helper::addAction('admin-beautify', 'AdminBeautify_Action');
        self::ensureTurnstileActions();
        return _t('AB-Admin 已启用');
    }
    public static function deactivate()
    {
        Utils\Helper::removeAction('admin-beautify');
        Utils\Helper::removeAction('login');
        Utils\Helper::removeAction('register');
        return _t('AdminBeautify 已禁用');
    }
    public static function ensureTurnstileActions()
    {
        $actionTable = array();
        try {
            $actionTable = Utils\Helper::options()->actionTable;
        } catch (Exception $e) {
            $actionTable = array();
        } catch (Throwable $e) {
            $actionTable = array();
        }
        if (!is_array($actionTable)) {
            $actionTable = array();
        }
        if (!isset($actionTable['login']) || $actionTable['login'] !== 'AdminBeautify_Login') {
            Utils\Helper::addAction('login', 'AdminBeautify_Login');
        }
        if (!isset($actionTable['register']) || $actionTable['register'] !== 'AdminBeautify_Register') {
            Utils\Helper::addAction('register', 'AdminBeautify_Register');
        }
    }
    public static function turnstileSiteKey($page)
    {
        if (self::turnstileIsDisabled()) {
            return '';
        }
        $opt = self::pluginOptions();
        $siteKey = trim((string) $opt->turnstile_siteKey);
        $secret  = trim((string) $opt->turnstile_secretKey);
        if ($siteKey === '' || $secret === '') {
            return '';
        }
        $flag = 'turnstile_' . $page;
        if (empty($opt->{$flag})) {
            return '';
        }
        return $siteKey;
    }
    public static function turnstileKillSwitchPath()
    {
        return dirname(__FILE__) . '/turnstile-off';
    }
    public static function turnstileIsDisabled()
    {
        if (file_exists(self::turnstileKillSwitchPath())) {
            return true;
        }
        return self::turnstileIsSuspended();
    }
    private static $turnstileResumedThisRequest = false;
    public static function turnstileIsSuspended()
    {
        if (self::$turnstileResumedThisRequest) {
            return false;
        }
        $opt = self::pluginOptions();
        if (empty($opt->turnstile_suspended)) {
            return false;
        }
        $now  = self::turnstileKeyPrint($opt);
        $then = isset($opt->turnstile_keyPrint) ? (string) $opt->turnstile_keyPrint : '';
        if ($then !== '' && $then !== $now) {
            self::turnstileClearSuspend();
            return false;
        }
        return true;
    }
    private static function turnstileKeyPrint($opt = null)
    {
        if ($opt === null) {
            $opt = self::pluginOptions();
        }
        return md5(trim((string) $opt->turnstile_siteKey) . '|' . trim((string) $opt->turnstile_secretKey));
    }
    public static function turnstileClearSuspend()
    {
        try {
            self::savePluginOptions('AdminBeautify', array(
                'turnstile_suspended'       => '',
                'turnstile_suspendedAt'     => '',
                'turnstile_suspendedReason' => '',
                'turnstile_failStreak'      => '',
                'turnstile_keyPrint'        => '',
            ));
        } catch (Exception $e) {
        } catch (Throwable $e) {
        }
    }
    public static function turnstileEnabledFor($page)
    {
        return self::turnstileSiteKey($page) !== '';
    }
    public static function turnstileVerifyToken($token, $secret)
    {
        if (!is_string($secret) || $secret === '') {
            return true;
        }
        if (!is_string($token) || $token === '') {
            self::turnstileNoteError('missing-token');
            return false;
        }
        $ctx = stream_context_create(array('http' => array(
            'method'  => 'POST',
            'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
            'content' => http_build_query(array(
                'secret'   => $secret,
                'response' => $token,
            )),
            'timeout' => 5,
            'ignore_errors' => true,
        )));
        $body = @file_get_contents('https://challenges.cloudflare.com/turnstile/v0/siteverify', false, $ctx);
        if ($body === false) {
            return true;
        }
        $json = json_decode($body, true);
        if (!is_array($json) || !array_key_exists('success', $json)) {
            return true;
        }
        if (!empty($json['success'])) {
            self::turnstileNoteError('');
            return true;
        }
        $codes = (isset($json['error-codes']) && is_array($json['error-codes']))
            ? implode(',', $json['error-codes'])
            : 'unknown';
        self::turnstileNoteError($codes);
        return false;
    }
    public static function turnstileVerifyRequest($page)
    {
        if (!self::turnstileEnabledFor($page)) {
            return true;
        }
        $secret = trim((string) self::pluginOptions()->turnstile_secretKey);
        $token  = isset($_POST['cf-turnstile-response']) ? $_POST['cf-turnstile-response'] : '';
        return self::turnstileVerifyToken($token, $secret);
    }
    private static function turnstileNoteError($code)
    {
        $code = (string) $code;
        $opt = self::pluginOptions();
        if ($code === '') {
            $had = (!empty($opt->turnstile_lastError) || !empty($opt->turnstile_failStreak));
            if (!$had) {
                return;
            }
            try {
                self::savePluginOptions('AdminBeautify', array(
                    'turnstile_lastError'   => '',
                    'turnstile_lastErrorAt' => '',
                    'turnstile_failStreak'  => '',
                ));
            } catch (Exception $e) {
            } catch (Throwable $e) {
            }
            return;
        }
        $fatal  = in_array($code, self::turnstileConfigErrorCodes(), true);
        $streak = (int) (isset($opt->turnstile_failStreak) ? $opt->turnstile_failStreak : 0);
        $streak = $fatal ? ($streak + 1) : 0;
        $patch = array(
            'turnstile_lastError'   => $code,
            'turnstile_lastErrorAt' => (string) time(),
            'turnstile_failStreak'  => $streak > 0 ? (string) $streak : '',
        );
        if ($fatal && $streak >= 3 && empty($opt->turnstile_suspended)) {
            $patch['turnstile_suspended']       = '1';
            $patch['turnstile_suspendedAt']     = (string) time();
            $patch['turnstile_suspendedReason'] = $code;
            $patch['turnstile_keyPrint']        = self::turnstileKeyPrint($opt);
        }
        try {
            self::savePluginOptions('AdminBeautify', $patch);
        } catch (Exception $e) {
        } catch (Throwable $e) {
        }
    }
    public static function turnstileConfigErrorCodes()
    {
        return array('invalid-input-secret', 'bad-request');
    }
    public static function turnstileErrorHint($code)
    {
        $code = trim((string) $code);
        if ($code === '') {
            return '';
        }
        $map = array(
            'missing-token'        => '浏览器没有把验证令牌提交上来：多半是组件还没加载完就点了提交，或页面上的 JS 被拦截。让用户刷新页面后重试。',
            'invalid-input-secret' => 'Secret Key 不对（Site Key 与 Secret Key 不是同一个 Turnstile 部件的，或密钥被重置过）。请回 Cloudflare 控制台重新复制两个密钥。',
            'invalid-input-response' => '令牌无效：组件所属域名与当前站点不匹配，或令牌被改动过。请检查 Turnstile 部件的「域」是否包含本站域名（本地测试要加上 127.0.0.1）。',
            'timeout-or-duplicate' => '令牌已过期或已被使用过（令牌只有 5 分钟有效期且只能用一次）。刷新页面拿到新令牌即可。',
            'bad-request'          => '请求格式不对（Secret Key 里可能混入了空格或换行）。',
            'internal-error'       => 'Cloudflare 侧临时故障，稍后重试即可。',
        );
        if (isset($map[$code])) {
            return $map[$code];
        }
        $parts = array();
        foreach (explode(',', $code) as $one) {
            $one = trim($one);
            if ($one !== '' && isset($map[$one])) {
                $parts[] = $map[$one];
            }
        }
        return $parts ? implode(' ', array_unique($parts)) : ('Cloudflare 返回：' . $code);
    }
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        self::ensureTurnstileActions();
        $abConfigColors = array(
            'purple' => array('#7D5260', '#9E7B8A'),
            'blue'   => array('#556270', '#7A8A9E'),
            'teal'   => array('#4A6363', '#6A8A8A'),
            'green'  => array('#55624C', '#7A8A6E'),
            'orange' => array('#725A42', '#9E8062'),
            'pink'   => array('#74565F', '#9E7A85'),
            'red'    => array('#775654', '#A27A78'),
        );
        $abOpt = null;
        try {
            $abOpt = Typecho_Widget::widget('Widget_Options')->plugin('AdminBeautify');
            $abScheme = isset($abOpt->primaryColor) ? (string) $abOpt->primaryColor : 'purple';
        } catch (Exception $e) {
            $abScheme = 'purple';
        }
        if (!isset($abConfigColors[$abScheme])) $abScheme = 'purple';
        $abC1 = $abConfigColors[$abScheme][0];
        $abC2 = $abConfigColors[$abScheme][1];
        $abVer = '2.1.63';
        include dirname(__FILE__) . '/assets/pages/config/header.php';
        include dirname(__FILE__) . '/assets/pages/config/config.style.php';
        include_once dirname(__FILE__) . '/assets/pages/config/card-create.php';
        abCard('admin', $abC1, 'settings', '管理后台设置', '统一管理外观、概要页、统计、导航与插件页行为');
        $primaryColor = new Typecho_Widget_Helper_Form_Element_Select(
            'primaryColor',
            array(
                'purple'  => '🟣 紫 (默认)',
                'blue'    => '🔵 蓝',
                'teal'    => '🩵 青',
                'green'   => '🟢 绿',
                'orange'  => '🟠 橙',
                'pink'    => '🩷 粉',
                'red'     => '🔴 红',
            ),
            'purple',
            _t('主题色'),
            _t('设置后台主色调（按钮、选中态与强调元素会同步变化）')
        );
        $form->addInput($primaryColor);
        $darkMode = new Typecho_Widget_Helper_Form_Element_Select(
            'darkMode',
            array(
                'auto'  => '跟随系统',
                'light' => '浅色模式',
                'dark'  => '深色模式',
            ),
            'auto',
            _t('颜色模式'),
            _t('选择后台的明暗模式')
        );
        $form->addInput($darkMode);
        $borderRadius = new Typecho_Widget_Helper_Form_Element_Select(
            'borderRadius',
            array(
                'small'  => '小圆角',
                'medium' => '中圆角 (默认)',
                'large'  => '大圆角',
            ),
            'medium',
            _t('圆角风格'),
            _t('控制界面元素的圆角大小')
        );
        $form->addInput($borderRadius);
        $enableAnimation = new Typecho_Widget_Helper_Form_Element_Select(
            'enableAnimation',
            array(
                '1' => '开启',
                '0' => '关闭',
            ),
            '1',
            _t('过渡动画'),
            _t('是否开启界面元素的过渡动画效果')
        );
        $form->addInput($enableAnimation);
        $loadingAnimation = new Typecho_Widget_Helper_Form_Element_Select(
            'loadingAnimation',
            array(
                'morph'   => '新版转圈（默认，M3 官方变形指示器）',
                'spinner' => '旧版转圈（MD3 圆环）',
                'topbar'  => '顶部进度条',
            ),
            'morph',
            _t('加载动画'),
            _t('选择页面进入与 AJAX 切换时的加载反馈样式：<b>新版转圈</b>（默认）复刻 Material 3 官方 Loading indicator —— 在 SoftBurst / Cookie9Sided / Pentagon / Pill / Sunny / Cookie4Sided / Oval 七个形状之间弹簧形变，每 700ms 切一个形状并同步旋转（官方参数：形变 ≈650ms/步 + 全局旋转 4666ms/圈）；<b>旧版转圈</b>为圆环旋转；<b>顶部进度条</b>为页面顶部细进度条。颜色均跟随插件主色。')
        );
        $form->addInput($loadingAnimation);
        $postListStyle = new Typecho_Widget_Helper_Form_Element_Select(
            'postListStyle',
            array(
                'card' => '卡片展示（默认）',
                'list' => '原版列表展示',
            ),
            'card',
            _t('文章列表展示'),
            _t('「管理 → 文章」列表的展示方式：<b>卡片展示</b>把每篇文章渲染成一张 MD3 卡片（标题 / 状态 / 评论 / 作者 / 分类 / 日期）；<b>原版列表展示</b>保持 Typecho 原样表格。')
        );
        $form->addInput($postListStyle);
        $pageListStyle = new Typecho_Widget_Helper_Form_Element_Select(
            'pageListStyle',
            array(
                'card' => '卡片展示（默认）',
                'list' => '原版列表展示',
            ),
            'card',
            _t('独立页面列表展示'),
            _t('「管理 → 独立页面」列表的展示方式，效果与文章列表一致（子页面 / 作者 / 日期）。')
        );
        $form->addInput($pageListStyle);
        $commentListStyle = new Typecho_Widget_Helper_Form_Element_Select(
            'commentListStyle',
            array(
                'card' => '卡片展示（默认）',
                'list' => '原版列表展示',
            ),
            'card',
            _t('评论列表展示'),
            _t('「管理 → 评论」列表的展示方式：<b>卡片展示</b>把每条评论渲染成一张 MD3 卡片（头像 / 作者 / 内容 / 日期与文章，底部一条操作带）；<b>原版列表展示</b>保持 Typecho 原样表格。两种模式下「编辑 / 回复」都在带窗口动画的弹窗里完成。')
        );
        $form->addInput($commentListStyle);
        $categoryListStyle = new Typecho_Widget_Helper_Form_Element_Select(
            'categoryListStyle',
            array(
                'card' => '卡片展示（默认）',
                'list' => '原版列表展示',
            ),
            'card',
            _t('分类列表展示'),
            _t('「管理 → 分类」列表的展示方式：<b>卡片展示</b>把每个分类渲染成一张 MD3 卡片（名称 / 缩略名 / 子分类 / 文章数 / 默认，右下角一条操作带）；<b>原版列表展示</b>保持 Typecho 原样表格。拖拽排序在两种模式下都可用。')
        );
        $form->addInput($categoryListStyle);
        $dashboardQuickShow = new Typecho_Widget_Helper_Form_Element_Select(
            'dashboardQuickShow',
            array(
                '1' => '显示 (默认)',
                '0' => '隐藏',
            ),
            '1',
            _t('概要页快捷操作'),
            _t('是否显示概要页中 Typecho 原有的快捷操作按钮（写文章、管理评论等）')
        );
        $form->addInput($dashboardQuickShow);
        $dashboardQuickStyle = new Typecho_Widget_Helper_Form_Element_Select(
            'dashboardQuickStyle',
            array(
                'small' => '小（胶囊按钮，默认）',
                'large' => '大（图标卡片）',
            ),
            'large',
            _t('快捷操作按钮样式'),
            _t('小：横排胶囊按钮（图标 + 文字并排）；大：网格图标卡片（图标在上、文字在下）')
        );
        $form->addInput($dashboardQuickStyle);
        $dashboardQuickHint = new Typecho_Widget_Helper_Form_Element_Select(
            'dashboardQuickHint',
            array(
                '1' => '显示 (默认)',
                '0' => '隐藏',
            ),
            '1',
            _t('快捷按钮 - "自定义"'),
            _t('控制概要页快捷操作区是否显示“自定义”入口按钮')
        );
        $form->addInput($dashboardQuickHint);
        $dashboardHideDonate = new Typecho_Widget_Helper_Form_Element_Select(
            'dashboardHideDonate',
            array(
                '0' => '显示 (默认)',
                '1' => '隐藏',
            ),
            '0',
            _t('快捷按钮 - "捐助作者"'),
            _t('是否在概要页快捷操作中显示"捐助作者"按钮')
        );
        $form->addInput($dashboardHideDonate);
        $dashboardCustomButtons = new Typecho_Widget_Helper_Form_Element_Textarea(
            'dashboardCustomButtons',
            null,
            '',
            _t('概要页自定义快捷按钮'),
            _t('每行一个按钮，格式：<code>名称:地址:图标</code> 或 <code>名称:地址:图标:highlight</code>。<br><code>:highlight</code> 为强调样式。图标名称可在 <a href="https://fonts.google.com/icons" target="_blank" rel="noopener noreferrer">Material Symbols</a> 查询。<br><span class="ab-tip-ico material-icons-round">warning</span> 外链地址需以 <code>http://</code> 或 <code>https://</code> 开头，站内路径可直接填写。<br>示例：<br><code>写文章:write-post.php:edit</code><br><code>查看前台:https://example.com:public:highlight</code><br><code>管理评论:manage-comments.php:comment</code>')
        );
        $form->addInput($dashboardCustomButtons);
        $dashboardRecentStyle = new Typecho_Widget_Helper_Form_Element_Select(
            'dashboardRecentStyle',
            array(
                'md3'      => 'MD卡片（默认）',
                'original' => '原版',
            ),
            'md3',
            _t('最近文章/评论卡片样式'),
            _t('MD卡片：Material Design 3 列表风格，时间居右，文章单行、评论双行；原版：Typecho 原有样式。同时会隐藏"官方最新日志"卡片。')
        );
        $form->addInput($dashboardRecentStyle);
        $themeBtnModeDefault = 'merge';
        if (isset($abOpt->dashboardThemeButtonShow)) {
            $abThemeBtnRaw = (string) $abOpt->dashboardThemeButtonShow;
            $themeBtnModeDefault = ($abThemeBtnRaw === '0' || $abThemeBtnRaw === 'hide') ? 'hide' : 'merge';
        }
        $dashboardThemeButtonShow = new Typecho_Widget_Helper_Form_Element_Select(
            'dashboardThemeButtonShow',
            array(
                'merge' => '合并到「概要页自定义快捷按钮」（默认）',
                'hide'  => '不显示',
            ),
            $themeBtnModeDefault,
            _t('主题设置按钮'),
            _t('设置「主题设置」入口的显示方式。<b>右上角单独显示已取消</b>，曾选过它的站点会自动改为合并到概要页快捷操作。')
        );
        $form->addInput($dashboardThemeButtonShow);
        $overviewChartEnabled = new Typecho_Widget_Helper_Form_Element_Select(
            'overviewChartEnabled',
            array(
                '1' => '开启（默认）',
                '0' => '关闭',
            ),
            '1',
            _t('概要页图表'),
            _t('是否在概要页底部显示「更新频率」折线图和「近期评论分类」极坐标图')
        );
        $form->addInput($overviewChartEnabled);
        $overviewTimeRange = new Typecho_Widget_Helper_Form_Element_Select(
            'overviewTimeRange',
            array(
                '7'  => '近 7 天',
                '30' => '近 30 天（默认）',
                '0'  => '全部',
            ),
            '30',
            _t('图表统计时间范围'),
            _t('「更新频率」和「近期评论分类」图表的数据统计时间范围')
        );
        $form->addInput($overviewTimeRange);
        $umamiEnabled = new Typecho_Widget_Helper_Form_Element_Select(
            'umamiEnabled',
            array(
                '0' => '关闭（默认）',
                '1' => '开启',
            ),
            '0',
            _t('Umami 访问统计'),
            _t('开启后在概要页显示 Umami 统计卡片（今日访问、总访问、访客数量、平均时长、跳出率）。需同时填写下方 API 配置。')
        );
        $form->addInput($umamiEnabled);
        $umamiProvider = new Typecho_Widget_Helper_Form_Element_Select(
            'umamiProvider',
            array(
                'self'  => '自建（默认）',
                'cloud' => 'Umami Cloud',
            ),
            'self',
            _t('Umami 平台类型'),
            _t('自建：使用你自己的 Umami 服务地址；Umami Cloud：使用官方云服务 API。')
        );
        $form->addInput($umamiProvider);
        $umamiApiBase = new Typecho_Widget_Helper_Form_Element_Text(
            'umamiApiBase',
            null,
            '',
            _t('Umami API 地址（自建）'),
            _t('仅「自建」模式生效。填写 Umami 实例地址（不含末尾斜线），例如：<code>https://umami.example.com</code>')
        );
        $form->addInput($umamiApiBase);
        $umamiWebsiteId = new Typecho_Widget_Helper_Form_Element_Text(
            'umamiWebsiteId',
            null,
            '',
            _t('Umami 网站 ID'),
            _t('在 Umami → 网站设置 中查看 Website ID（UUID 格式）')
        );
        $form->addInput($umamiWebsiteId);
        $umamiApiToken = new Typecho_Widget_Helper_Form_Element_Text(
            'umamiApiToken',
            null,
            '',
            _t('Umami API Token'),
            _t('自建模式：填写 Bearer Token（可按官方认证流程获取）。Cloud 模式：可直接填写 Umami Cloud 后台创建的 API Key。')
        );
        $form->addInput($umamiApiToken);
        $umamiTimeRange = new Typecho_Widget_Helper_Form_Element_Select(
            'umamiTimeRange',
            array(
                '7'  => '近 7 天',
                '30' => '近 30 天（默认）',
                '0'  => '全部',
            ),
            '30',
            _t('Umami 数据时间范围'),
            _t('访客数量、平均访问时长、跳出率 这三项的统计时间范围（今日访问量 / 总访问量 始终固定为今日 / 全部时间）')
        );
        $form->addInput($umamiTimeRange);
        self::ensureCardTable();
        abCard('dashboardcards', $abC1, 'dashboard_customize', '概要页卡片设置',
            '查看概要页已有卡片、调整卡片顺序'
        );
        $dashboardCardOrder = new AdminBeautify_SafeHidden(
            'dashboardCardOrder',
            null,
            isset($abOpt->dashboardCardOrder) ? (string) $abOpt->dashboardCardOrder : ''
        );
        $form->addInput($dashboardCardOrder);
        $dashboardCardGroups = new AdminBeautify_SafeHidden(
            'dashboardCardGroups',
            null,
            isset($abOpt->dashboardCardGroups) ? (string) $abOpt->dashboardCardGroups : ''
        );
        $form->addInput($dashboardCardGroups);
        $dashboardLayout = new Typecho_Widget_Helper_Form_Element_Select(
            'dashboardLayout',
            array(
                'masonry' => '瀑布流（默认，各列独立堆叠、不留空白）',
                'grid'    => '网格流（同一行等高对齐）',
            ),
            'masonry',
            _t('卡片排版模式'),
            _t('决定概要页卡片的排列方式：<b>瀑布流</b>每列各自堆叠，卡片高度不必对齐，内容少的卡片下方不会留大块空白；<b>网格流</b>同一行卡片等高对齐（原版表现）。')
        );
        $form->addInput($dashboardLayout);
        $dashboardCustomCardsEnabled = new Typecho_Widget_Helper_Form_Element_Select(
            'dashboardCustomCardsEnabled',
            array(
                '0' => '关闭（默认）',
                '1' => '开启（允许执行自定义 HTML / JS）',
            ),
            '0',
            _t('自定义卡片'),
            _t('开启后，才会在概要页渲染下方配置的自定义卡片。<br>卡片脚本可直接使用内置 MD3 组件库 <code>ab.ui</code>（磁贴指标 / 行列表 / 大号数字 / 清单 / 徽标 / 按钮 / 提示条 / 空状态 / 卡片底部入口 <code>ab-card-footer</code>），无需自己写 CSS，详见「自定义卡片开发说明」。<br><span class="ab-tip-ico material-icons-round">warning</span> 卡片内容支持任意 HTML 与 JavaScript，将在后台页面执行，请仅粘贴自己信任的代码。')
        );
        $form->addInput($dashboardCustomCardsEnabled);
        $dashboardCustomCards = new AdminBeautify_SafeHidden(
            'dashboardCustomCards',
            null,
            self::hydrateCardValueForForm(isset($abOpt->dashboardCustomCards) ? (string) $abOpt->dashboardCustomCards : '')
        );
        $form->addInput($dashboardCustomCards);
        $dashboardMoreCardEnabled = new Typecho_Widget_Helper_Form_Element_Select(
            'dashboardMoreCardEnabled',
            array(
                '1' => '显示（默认）',
                '0' => '隐藏',
            ),
            '1',
            _t('「更多」卡片'),
            _t('在概要页显示一张「更多」卡片：<b>插件文档</b> / <b>插件仓库</b> / <b>QQ 群</b>，以及<b>捐助作者</b>（鼠标悬停变成微信赞赏码，点击弹出二维码）。<br>卡片默认排在最后，可在上方卡片清单里调整顺序。')
        );
        $form->addInput($dashboardMoreCardEnabled);
        abCard('editor', $abC1, 'edit_note', '编辑器设置', '切换 AB 编辑体验与 Vditor 模式，兼容第三方编辑器',
            abCardTip('edit', '可在 AB Typecho 原版优化 / AB Vditor / AB Editor.md / 兼容其他编辑器 之间切换。启用 Vditor 或 Editor.md 后，会替代原版 PageDown 编辑体验，并套用 AB 的 MD3 风格。')
        );
        $editorVditor = new Typecho_Widget_Helper_Form_Element_Select(
            'editor_vditor',
            array(
                '0' => 'AB Typecho 原版优化',
                '1' => 'AB Vditor',
                '3' => 'AB Editor.md (Beta)',
                '2' => '兼容其他编辑器',
            ),
            '1',
            _t('编辑器'),
            _t('AB Typecho 优化：使用 AB-Admin 优化后的原版编辑器（含 工具栏）；AB Vditor：替换为 Vditor Markdown 编辑器；AB Editor.md：替换为 Editor.md 编辑器；兼容其他编辑器：不注入任何编辑器相关 CSS / JS，适合已安装第三方编辑器插件时使用。')
        );
        $form->addInput($editorVditor);
        $editorVditorMode = new Typecho_Widget_Helper_Form_Element_Select(
            'editor_vditorMode',
            array(
                'wysiwyg' => '所见即所得',
                'ir'      => '实时预览（默认）',
                'sv'      => '分屏编辑（宽屏推荐）',
            ),
            'ir',
            _t('AB Vditor 默认模式'),
            _t('首次打开编辑器时使用的模式，用户可通过编辑器上方的模式切换按钮随时切换')
        );
        $form->addInput($editorVditorMode);
        $editorHideToolbar = new Typecho_Widget_Helper_Form_Element_Select(
            'editor_hideToolbar',
            array(
                '0' => '保留原有工具栏',
                '1' => '隐藏原有工具栏',
            ),
            '0',
            _t('原有工具栏'),
            _t('仅在"兼容其他编辑器"模式下生效。开启后将强制隐藏 Typecho 原有编辑工具栏（#wmd-button-bar），以避免与第三方编辑器的工具栏叠加显示。')
        );
        $form->addInput($editorHideToolbar);
        abCard('login', $abC2, 'lock', '登录页设置', '自定义登录页主题、背景、虚化与扩展样式脚本',
            abCardTip('tips_and_updates', '以下设置控制登录页面的样式，支持自定义配色、背景图片、虚化效果等。')
        );
        $loginIsEnabled = new Typecho_Widget_Helper_Form_Element_Radio(
            'login_isEnabled',
            array('1' => _t('使用AB登录页'), '0' => _t('不使用/使用其他登录页美化')),
            '1',
            _t('登录页启用状态')
        );
        $form->addInput($loginIsEnabled);
        $loginColorPreset = new Typecho_Widget_Helper_Form_Element_Select(
            'login_colorPreset',
            array(
                'custom'   => _t('自定义'),
                'purple'   => _t('🟣 紫 (默认)'),
                'blue'     => _t('🔵 蓝'),
                'pink'     => _t('🌸 粉'),
                'green'    => _t('🌿 绿'),
                'orange'   => _t('🍊 橙'),
                'red'      => _t('❤️ 红'),
                'teal'     => _t('🌊 青'),
                'indigo'   => _t('💙 靛蓝'),
                'sunset'   => _t('🌅 日落渐变'),
                'ocean'    => _t('🌊 海洋渐变'),
                'forest'   => _t('🌲 森林渐变'),
                'lavender' => _t('💜 薰衣草'),
            ),
            'purple',
            _t('登录页配色方案'),
            _t('选择预设配色或使用自定义颜色')
        );
        $form->addInput($loginColorPreset);
        $loginPrimaryColor = new Typecho_Widget_Helper_Form_Element_Text(
            'login_primaryColor',
            null,
            '#7d5260',
            _t('登录页主色（自定义）'),
            _t('选择"自定义"方案后生效。如：#625fa0')
        );
        $form->addInput($loginPrimaryColor);
        $loginPrimaryColor2 = new Typecho_Widget_Helper_Form_Element_Text(
            'login_primaryColor2',
            null,
            '#9e7b8a',
            _t('登录页辅色（自定义）'),
            _t('选择"自定义"方案后生效。如：#7a6ec0')
        );
        $form->addInput($loginPrimaryColor2);
        $loginShowSiteName = new Typecho_Widget_Helper_Form_Element_Radio(
            'login_showSiteName',
            array('1' => _t('显示'), '0' => _t('隐藏')),
            '1',
            _t('登录页显示站点名称')
        );
        $form->addInput($loginShowSiteName);
        $loginThemeMode = new Typecho_Widget_Helper_Form_Element_Radio(
            'login_themeMode',
            array('auto' => _t('跟随系统'), 'light' => _t('亮色'), 'dark' => _t('暗色')),
            'auto',
            _t('登录页默认主题')
        );
        $form->addInput($loginThemeMode);
        $loginShowThemeToggle = new Typecho_Widget_Helper_Form_Element_Radio(
            'login_showThemeToggle',
            array('1' => _t('显示'), '0' => _t('隐藏')),
            '1',
            _t('登录页显示主题切换按钮')
        );
        $form->addInput($loginShowThemeToggle);
        $loginBgImage = new Typecho_Widget_Helper_Form_Element_Text(
            'login_bgImage',
            null,
            '',
            _t('登录页背景图片 URL'),
            _t('留空则使用纯色背景。')
        );
        $form->addInput($loginBgImage);
        $loginBlurType = new Typecho_Widget_Helper_Form_Element_Radio(
            'login_blurType',
            array(
                'none'   => _t('不虚化'),
                'filter' => _t('背景图模糊（filter: blur）'),
            ),
            'filter',
            _t('登录页虚化方式')
        );
        $form->addInput($loginBlurType);
        $loginBlurSize = new Typecho_Widget_Helper_Form_Element_Text(
            'login_blurSize',
            null,
            '12',
            _t('登录页虚化大小(px)'),
            _t('建议 0-50。')
        );
        $form->addInput($loginBlurSize);
        $loginCustomCss = new Typecho_Widget_Helper_Form_Element_Textarea(
            'login_customCss',
            null,
            '',
            _t('登录页自定义 CSS'),
            _t('将注入到登录页。无需 style 标签。如果不生效请加 !important')
        );
        $form->addInput($loginCustomCss);
        $loginCustomJs = new Typecho_Widget_Helper_Form_Element_Textarea(
            'login_customJs',
            null,
            '',
            _t('登录页自定义 JavaScript'),
            _t('将注入到登录页。无需 script 标签。')
        );
        $form->addInput($loginCustomJs);
        self::renderLoginPreview();
        abCard('pwa', $abC1, 'phone_android', 'PWA 应用设置', '配置后台 PWA 应用名称、图标与安装辅助工具');
        $pwaAppName = new Typecho_Widget_Helper_Form_Element_Text(
            'pwa_appName',
            null,
            '',
            _t('PWA 应用名称'),
            _t('安装为 PWA 后显示的应用名称。留空则默认为「博客名称 + 管理后台」')
        );
        $form->addInput($pwaAppName);
        $pwaAppIcon = new Typecho_Widget_Helper_Form_Element_Text(
            'pwa_appIcon',
            null,
            'https://i.see.you/2026/03/08/Uei3/26ee132f48bd9453e9c4d1d3fa1d312d.jpg',
            _t('PWA 应用图标 URL'),
            _t('安装为 PWA 后显示的应用图标，建议使用 512×512 的正方形图片。')
        );
        $form->addInput($pwaAppIcon);
        abCard('perf', $abC1, 'speed', '速度优化', '切换头像源与后台 AJAX 导航策略');
        $avatarSource = new Typecho_Widget_Helper_Form_Element_Select(
            'avatarSource',
            array(
                'loli'     => _t('loli.net 镜像（gravatar.loli.net，推荐）'),
                'gravatar' => _t('Gravatar 官方（www.gravatar.com）'),
                'cravatar' => _t('Cravatar（cravatar.cn）'),
                'custom'   => _t('自定义域名'),
            ),
            'loli',
            _t('Gravatar 头像源'),
            _t('选择后台头像（侧栏、移动端、个人设置页、评论管理页）的加载域名。')
        );
        $form->addInput($avatarSource);
        $customAvatarUrl = new Typecho_Widget_Helper_Form_Element_Text(
            'customAvatarUrl',
            null,
            '',
            _t('自定义头像域名'),
            _t('选「自定义域名」后生效。填入完整头像服务地址，如 https://example.com/avatar，末尾不加斜线，格式需与 Gravatar 兼容（路径后接 MD5 邮箱哈希）。')
        );
        $form->addInput($customAvatarUrl);
        $ajaxEnabled = new Typecho_Widget_Helper_Form_Element_Select(
            'ajaxEnabled',
            array(
                '1' => '开启（默认）',
                '0' => '关闭',
            ),
            '1',
            _t('AJAX 导航'),
            _t('开启后后台页面在兼容场景下无刷新切换；若与浏览器或插件冲突，可关闭回退为整页加载。')
        );
        $form->addInput($ajaxEnabled);
        abCard('channel', $abC1, 'system_update_alt', '升级通道', '选择接收正式版，或同时接收 GitHub 上的开发版（Pre-release）',
            abCardTip('science',
                '开发版 = 除正式 Release 外，还把 GitHub 上标记为 <b>Pre-release</b> 的最新版当作更新推送。<br>'
                . '<span class="ab-tip-ico material-icons-round">warning</span> 开发版可能不稳定，建议只在测试站点开启；从开发版回退到稳定版需要手动覆盖安装一次正式版。',
                true
            )
        );
        $updateChannel = new Typecho_Widget_Helper_Form_Element_Select(
            'updateChannel',
            array(
                'stable' => '稳定版',
                'beta'   => '开发版',
            ),
            'stable',
            _t('升级通道'),
            _t('决定「检查更新」时的通道')
        );
        $form->addInput($updateChannel);
        abCard('compat', $abC2, 'extension', '兼容脚本管理', '按需启用兼容脚本，修复插件页面样式与交互冲突',
            abCardTip('inventory_2',
                '兼容脚本默认不加载，请根据需要手动开启。脚本位于 <code>assets/compat/</code> 目录。<br>'
                . '开发者可参考 <code>assets/compat/README.md</code> 编写兼容脚本（需包含 <code>@name</code> / <code>@plugins</code> / <code>@description</code> 元数据）。<br>'
                . '文档：<a href="https://blog.lhl.one/artical/977.html" target="_blank">https://blog.lhl.one/artical/977.html</a>',
                true
            )
        );
        $compatDir = dirname(__FILE__) . '/assets/compat/';
        $compatScripts = self::scanCompatScripts($compatDir);
        $enabledRaw = '';
        try {
            $abOptCompat = Typecho_Widget::widget('Widget_Options')->plugin('AdminBeautify');
            $enabledRaw = isset($abOptCompat->compat_disabledScripts) ? (string) $abOptCompat->compat_disabledScripts : '';
        } catch (Exception $e) {
            $enabledRaw = '';
        }
        $enabledList = ($enabledRaw !== '') ? (array) json_decode($enabledRaw, true) : array();
        if (!is_array($enabledList)) $enabledList = array();
        self::renderCompatScriptsList($compatScripts, $enabledList, $abC1);
        $compatEnabledScripts = new AdminBeautify_SafeHidden(
            'compat_disabledScripts',
            null,
            $enabledRaw
        );
        $form->addInput($compatEnabledScripts);
        $compatExternalJs = new Typecho_Widget_Helper_Form_Element_Textarea(
            'compat_externalJs',
            null,
            '',
            _t('外部兼容脚本 URL'),
            _t('每行一个 JS 文件 URL，将在后台所有页面加载。示例：https://cdn.example.com/compat/my-plugin-fix.js')
        );
        $form->addInput($compatExternalJs);
        $telemetryOptOut = new Typecho_Widget_Helper_Form_Element_Radio(
            'telemetryOptOut',
            array(
                '0' => _t('允许'),
                '1' => _t('关闭统计'),
            ),
            '0',
            _t('匿名使用统计'),
            _t('启用后，插件会通过浏览器向开发者统计服务发送，仅包含：插件版本号、站点表示。选择"关闭统计"后立即停止上报。')
        );
        $form->addInput($telemetryOptOut);
        $notifyOptOut = new Typecho_Widget_Helper_Form_Element_Radio(
            'notifyOptOut',
            array(
                '0' => _t('显示通知（默认）'),
                '1' => _t('关闭通知'),
            ),
            '0',
            _t('插件通知'),
            _t('关闭后，将不再显示设置页的插件公告弹窗。')
        );
        $form->addInput($notifyOptOut);
        abCard('smtp', $abC2, 'outbox', 'SMTP 发件设置', '配置发信服务器，供登录页「忘记密码」等功能发送邮件',
            abCardTip('mail',
                '在需要发送邮件时会使用以上设置，如登录页面的「忘记密码」功能等。<br>'
                . '多数邮箱（QQ、163、Gmail 等）需要填写<strong>授权码</strong>，而不是邮箱登录密码。'
            )
        );
        $smtpEnabled = new Typecho_Widget_Helper_Form_Element_Radio(
            'smtp_enabled',
            array(
                '1' => _t('启用'),
                '0' => _t('关闭（默认）'),
            ),
            '0',
            _t('SMTP 发件功能'),
            _t('开启后，插件在需要发送邮件时才会使用以下设置。')
        );
        $form->addInput($smtpEnabled);
        $smtpHost = new Typecho_Widget_Helper_Form_Element_Text(
            'smtp_host',
            null,
            '',
            _t('SMTP 服务器地址'),
            _t('如 smtp.qq.com、smtp.163.com、smtp.gmail.com。')
        );
        $form->addInput($smtpHost);
        $smtpPort = new Typecho_Widget_Helper_Form_Element_Text(
            'smtp_port',
            null,
            '465',
            _t('SMTP 端口'),
            _t('SSL 常用 465，STARTTLS 常用 587。')
        );
        $form->addInput($smtpPort);
        $smtpSecure = new Typecho_Widget_Helper_Form_Element_Select(
            'smtp_secure',
            array(
                'ssl'  => _t('SSL / TLS 隐式加密（465）'),
                'tls'  => _t('STARTTLS 明文升级（587）'),
                'none' => _t('不加密（仅内网使用）'),
            ),
            'ssl',
            _t('加密方式'),
            _t('需与端口匹配：465 选 SSL，587 选 STARTTLS。')
        );
        $form->addInput($smtpSecure);
        $smtpUser = new Typecho_Widget_Helper_Form_Element_Text(
            'smtp_user',
            null,
            '',
            _t('SMTP 账号'),
            _t('通常就是发件邮箱地址；部分服务商要求与发件人邮箱完全一致。')
        );
        $form->addInput($smtpUser);
        $smtpPass = new Typecho_Widget_Helper_Form_Element_Password(
            'smtp_pass',
            null,
            '',
            _t('SMTP 密码 / 授权码'),
            _t('多数邮箱（QQ、163、Gmail 等）需要填写「授权码」，不是邮箱登录密码。')
        );
        $smtpPass->setInputsAttribute('autocomplete', 'new-password');
        $form->addInput($smtpPass);
        $smtpFrom = new Typecho_Widget_Helper_Form_Element_Text(
            'smtp_from',
            null,
            '',
            _t('发件人邮箱'),
            _t('留空则使用上面的 SMTP 账号。')
        );
        $form->addInput($smtpFrom);
        $smtpFromName = new Typecho_Widget_Helper_Form_Element_Text(
            'smtp_fromName',
            null,
            '',
            _t('发件人名称'),
            _t('收件方看到的发件人名称，留空则使用站点名称。')
        );
        $form->addInput($smtpFromName);
        if (isset($_REQUEST['ab-turnstile-resume']) && (string) $_REQUEST['ab-turnstile-resume'] === '1') {
            self::turnstileClearSuspend();
            self::$turnstileResumedThisRequest = true;
        }
        $abTsOptNow = self::pluginOptions();
        $abTsAdminUrl = (string) Typecho_Widget::widget('Widget_Options')->adminUrl;
        $abTsErrHtml = '';
        if (self::$turnstileResumedThisRequest) {
            $abTsErrHtml .= '<br><br><b style="color:#2e7d32"><span class="ab-tip-ico material-icons-round">check_circle</span> 已恢复人机验证</b><br>'
                . '请确认上面的密钥与 Cloudflare 控制台一致，再让用户重试登录。';
        }
        if (file_exists(self::turnstileKillSwitchPath())) {
            $abTsErrHtml .= '<br><br><b style="color:#b3261e"><span class="ab-tip-ico material-icons-round">block</span> 紧急开关生效中</b><br>'
                . '检测到文件 <code>usr/plugins/AdminBeautify/turnstile-off</code>，'
                . '人机验证已<b>全部跳过</b>。确认能正常登录后请删除该文件。';
        } elseif (self::turnstileIsSuspended()) {
            $abTsWhen = !empty($abTsOptNow->turnstile_suspendedAt)
                ? '（' . date('Y-m-d H:i', (int) $abTsOptNow->turnstile_suspendedAt) . '）'
                : '';
            $abTsReason = isset($abTsOptNow->turnstile_suspendedReason)
                ? (string) $abTsOptNow->turnstile_suspendedReason
                : '';
            $abTsErrHtml .= '<br><br><b style="color:#b3261e"><span class="ab-tip-ico material-icons-round">block</span> 人机验证已被自动暂停' . $abTsWhen . '</b><br>'
                . '连续多次出现「服务器侧配置错」（<code>' . htmlspecialchars($abTsReason, ENT_QUOTES | ENT_HTML5) . '</code>），'
                . '为避免把管理员锁在后台外面，插件已自动跳过验证、放行登录。<br>'
                . htmlspecialchars(self::turnstileErrorHint($abTsReason), ENT_QUOTES | ENT_HTML5) . '<br>'
                . '<b>改好上面的密钥并保存后会自动恢复</b>；也可以 '
                . '<a href="' . htmlspecialchars($abTsAdminUrl, ENT_QUOTES) . 'options-plugin.php?config=AdminBeautify&amp;ab-turnstile-resume=1">立即恢复验证</a>。';
        }
        $abTsLast = isset($abTsOptNow->turnstile_lastError) ? (string) $abTsOptNow->turnstile_lastError : '';
        if ($abTsLast !== '') {
            $abTsWhen = !empty($abTsOptNow->turnstile_lastErrorAt)
                ? '（' . date('Y-m-d H:i', (int) $abTsOptNow->turnstile_lastErrorAt) . '）'
                : '';
            $abTsErrHtml .= '<br><br><b style="color:#b3261e"><span class="ab-tip-ico material-icons-round">warning</span> 上次安全验证失败' . $abTsWhen . '</b><br>'
                . '原因：<code>' . htmlspecialchars($abTsLast, ENT_QUOTES | ENT_HTML5) . '</code><br>'
                . htmlspecialchars(self::turnstileErrorHint($abTsLast), ENT_QUOTES | ENT_HTML5);
        }
        $abTsErrHtml .= '<br><br><b><span class="ab-tip-ico material-icons-round">key</span> 万一配错把自己锁在门外：</b><br>'
            . '① 用 FTP / 主机文件管理，在 <code>usr/plugins/AdminBeautify/</code> 下新建一个<b>空文件</b>'
            . ' <code>turnstile-off</code> → 人机验证立即全部跳过，登录后回来修配置，修好再删掉该文件；<br>'
            . '② 若改不了文件，可在数据库里把本插件设置中的 <code>turnstile_login</code> / '
            . '<code>turnstile_register</code> / <code>turnstile_forgot</code> 三个值改成 <code>0</code>（或把两个密钥清空）。';
        abCard('security', $abC1, 'admin_panel_settings', '安全验证设置', 'Cloudflare Turnstile 人机验证，保护登录、注册与找回密码入口',
            abCardTip('verified_user',
                'Turnstile 是 Cloudflare 提供的人机验证服务（免费）。'
                . '在 Cloudflare 控制台创建站点后即可拿到「站点密钥（Site Key）」与「密钥（Secret Key）」。<br>'
                . '<b>两项密钥都留空 = 视为未启用</b>，不会拦截任何页面，避免配置到一半把自己锁在门外。'
                . '开启后，勾选的入口在提交前会先完成一次人机验证。'
                . '开启前请先确认密钥填对了：配错会导致登录页无法通过验证。'
                . $abTsErrHtml
            )
        );
        $turnstileSiteKey = new Typecho_Widget_Helper_Form_Element_Text(
            'turnstile_siteKey',
            null,
            '',
            _t('Turnstile 站点密钥（Site Key）'),
            _t('公开密钥，渲染人机验证组件时使用。')
        );
        $form->addInput($turnstileSiteKey);
        $turnstileSecretKey = new Typecho_Widget_Helper_Form_Element_Password(
            'turnstile_secretKey',
            null,
            '',
            _t('Turnstile 密钥（Secret Key）'),
            _t('私密密钥，服务端校验用，切勿泄露。')
        );
        $turnstileSecretKey->setInputsAttribute('autocomplete', 'new-password');
        $form->addInput($turnstileSecretKey);
        $turnstileLogin = new Typecho_Widget_Helper_Form_Element_Radio(
            'turnstile_login',
            array('1' => _t('开启'), '0' => _t('关闭（默认）')),
            '0',
            _t('登录页安全验证'),
            _t('开启后，登录提交前需先完成 Turnstile 人机验证。')
        );
        $form->addInput($turnstileLogin);
        $turnstileRegister = new Typecho_Widget_Helper_Form_Element_Radio(
            'turnstile_register',
            array('1' => _t('开启'), '0' => _t('关闭（默认）')),
            '0',
            _t('注册页安全验证'),
            _t('开启后，注册提交前需先完成 Turnstile 人机验证。')
        );
        $form->addInput($turnstileRegister);
        $turnstileForgot = new Typecho_Widget_Helper_Form_Element_Radio(
            'turnstile_forgot',
            array('1' => _t('开启'), '0' => _t('关闭（默认）')),
            '0',
            _t('忘记密码页安全验证'),
            _t('开启后，忘记密码提交邮箱前需先完成 Turnstile 人机验证。')
        );
        $form->addInput($turnstileForgot);
        if ($abOpt) {
            $existingInputs = $form->getInputs();
            foreach ($abOpt as $key => $val) {
                if (!isset($existingInputs[$key])) {
                    $ghostInput = new AdminBeautify_SafeHidden('ab_legacy_' . md5((string) $key), null, null);
                    $ghostInput->name = (string) $key;
                    $form->addInput($ghostInput);
                }
            }
        }
        include dirname(__FILE__) . '/assets/pages/config/config.script.php';
        include dirname(__FILE__) . '/assets/pages/config/patch.php';
        include dirname(__FILE__) . '/assets/pages/config/about.php';
        include dirname(__FILE__) . '/assets/pages/config/notice.script.php';
    }
    public static function personalConfig(Typecho_Widget_Helper_Form $form)
    {
    }
    public static function storeBoot()
    {
        if (!defined('__TYPECHO_ADMIN__')) {
            return false;
        }
        if (!class_exists('AdminBeautify_Store')) {
            $file = dirname(__FILE__) . '/store/bootstrap.php';
            if (!is_file($file)) {
                return false;
            }
            require_once $file;
        }
        return class_exists('AdminBeautify_Store');
    }
    private static function storeHeaderInject()
    {
        if (!self::storeBoot()) {
            return '';
        }
        $out = '';
        $storeOn = false;
        try {
            $storeOn = AdminBeautify_Store::enabled();
        } catch (Exception $e) {
        } catch (Throwable $e) {
        }
        if (!$storeOn) {
            return '';
        }
        try {
            $export = Typecho_Plugin::export();
            if (!empty($export['activated']['AdminBeautifyStore'])) {
                $out .= '<style id="ab-store-legacy-hide">'
                    . '.typecho-head-nav nav menu li:has(>a[href*="panel=AdminBeautifyStore"]),'
                    . '.typecho-head-nav nav menu li>a[href*="panel=AdminBeautifyStore"]{display:none!important}'
                    . '</style>';
            }
        } catch (Exception $e) {
        } catch (Throwable $e) {
        }
        try {
            if (AdminBeautify_StoreTakeover::canTakeover()) {
                AdminBeautify_StoreTakeover::arm();
                $options = Typecho_Widget::widget('Widget_Options');
                $css = Typecho_Common::url('AdminBeautify/store/assets/store.css', $options->pluginUrl);
                $file = dirname(__FILE__) . '/store/assets/store.css';
                $ver = is_file($file) ? (string) filemtime($file) : '0';
                $out .= '<link rel="stylesheet" href="' . htmlspecialchars($css . '?v=' . $ver) . '">';
            }
        } catch (Exception $e) {
        } catch (Throwable $e) {
        }
        return $out;
    }
    public static function renderHeader($header)
    {
        $header .= self::storeHeaderInject();
        $header .= '<script>(function(){try{'
            . 'console.log('
            .   '"%c AB-Admin %c v2.1.63 %c",'
            .   '"background:#6750a4;color:#fff;padding:3px 10px;border-radius:3px 0 0 3px;font-family:sans-serif;font-size:12px;font-weight:600",'
            .   '"background:#625b71;color:#fff;padding:3px 10px;font-family:sans-serif;font-size:12px",'
            .   '"background:#e8def8;color:#21005d;padding:3px 10px;border-radius:0 3px 3px 0;font-family:sans-serif;font-size:12px"'
            . ');'
            . 'console.log("%c  \uD83D\uDD17 https://see.lhl.one/Typecho-AB-Admin ","color:#6750a4;font-size:11px");'
            . '}catch(e){}})();</script>';
        $options = Typecho_Widget::widget('Widget_Options');
        $pluginOptions = self::pluginOptions($options);
        $loginIsEnabled = isset($pluginOptions->login_isEnabled) ? (string)$pluginOptions->login_isEnabled : '1';
        if (self::isLoginPage() && $loginIsEnabled == '1') {
            ob_start();
            self::outputLoginHeaderCss();
            $inject = ob_get_clean();
            return $header . $inject;
        } else if (self::isLoginPage()) {
            return $header;
        }
        return self::renderAdminHeader($header);
    }
    private static function renderAdminHeader($header)
    {
        $options = Typecho_Widget::widget('Widget_Options');
        $pluginOptions = self::pluginOptions($options);
        $primaryColor = $pluginOptions->primaryColor ?: 'purple';
        $darkMode = $pluginOptions->darkMode ?: 'auto';
        $borderRadius = $pluginOptions->borderRadius ?: 'medium';
        $rawAnim = isset($pluginOptions->enableAnimation) ? (string)$pluginOptions->enableAnimation : '';
        $enableAnimation = ($rawAnim !== '') ? $rawAnim : '1';
        $loadingAnimation = isset($pluginOptions->loadingAnimation) ? (string)$pluginOptions->loadingAnimation : '';
        if ($loadingAnimation === '') {
            $loadingAnimation = 'morph';
        }
        if (!in_array($loadingAnimation, array('spinner', 'topbar', 'morph'), true)) {
            $loadingAnimation = 'morph';
        }
        if ((isset($pluginOptions->abLoaderDefault) ? (string)$pluginOptions->abLoaderDefault : '') !== '1'
            && $loadingAnimation === 'spinner') {
            $loadingAnimation = 'morph';
            self::savePluginOptions('AdminBeautify', array(
                'loadingAnimation' => 'morph',
                'abLoaderDefault'  => '1',
            ));
        }
        $postListStyle = isset($pluginOptions->postListStyle) ? (string)$pluginOptions->postListStyle : 'card';
        if ($postListStyle !== 'list') $postListStyle = 'card';
        $pageListStyle = isset($pluginOptions->pageListStyle) ? (string)$pluginOptions->pageListStyle : 'card';
        if ($pageListStyle !== 'list') $pageListStyle = 'card';
        $commentListStyle = isset($pluginOptions->commentListStyle) ? (string)$pluginOptions->commentListStyle : 'card';
        if ($commentListStyle !== 'list') $commentListStyle = 'card';
        $categoryListStyle = isset($pluginOptions->categoryListStyle) ? (string)$pluginOptions->categoryListStyle : 'card';
        if ($categoryListStyle !== 'list') $categoryListStyle = 'card';
    $colors = self::getColorScheme($primaryColor);
    $lightBg = isset($colors['--md-surface'])      ? $colors['--md-surface']      : '#FFFBFE';
    $darkBg  = isset($colors['--md-dark-surface']) ? $colors['--md-dark-surface'] : '#1C1B1F';
    $cssUrl = Typecho_Common::url('AdminBeautify/assets/AdminBeautify', $options->pluginUrl);
        $earlyScript = '<script>';
        $earlyScript .= '(function(){';
        $earlyScript .= 'var s;try{s=localStorage.getItem("adminBeautifyTheme");}catch(e){s=null;}';
        $earlyScript .= 'var d;';
        $earlyScript .= 'if(s==="dark"){d=true;}';
        $earlyScript .= 'else if(s==="light"){d=false;}';
        $earlyScript .= 'else{';
        if ($darkMode === 'dark') {
            $earlyScript .= 'd=true;';
        } elseif ($darkMode === 'light') {
            $earlyScript .= 'd=false;';
        } else {
            $earlyScript .= 'd=!!(window.matchMedia&&window.matchMedia("(prefers-color-scheme:dark)").matches);';
        }
        $earlyScript .= '}';
        $earlyScript .= 'if(d){document.documentElement.setAttribute("data-theme","dark");document.documentElement.style.setProperty("color-scheme","dark");}';
        $earlyScript .= 'else{document.documentElement.removeAttribute("data-theme");document.documentElement.style.setProperty("color-scheme","light");}';
        $earlyScript .= '})();';
        $earlyScript .= 'document.documentElement.setAttribute("data-nav","left");if(localStorage.getItem("adminBeautifySidebarCollapsed")==="1"){document.documentElement.setAttribute("data-nav-collapsed","");}';
        if ($loadingAnimation === 'topbar') {
            $earlyScript .= 'document.documentElement.setAttribute("data-ab-loader","topbar");';
        } elseif ($loadingAnimation === 'morph') {
            $earlyScript .= 'document.documentElement.setAttribute("data-ab-loader","morph");';
        }
        if ($enableAnimation === '0') {
            $earlyScript .= 'document.documentElement.setAttribute("data-no-animation","");';
        }
        $abTypechoVer = isset($options->version) ? (string) $options->version : '';
        $abLegacyTypecho = ($abTypechoVer !== '' && version_compare($abTypechoVer, '1.3.0', '<'));
        $earlyScript .= 'var AB_LIST_MODES=' . json_encode(array(
            'posts' => $postListStyle,
            'pages' => $pageListStyle,
            'comments' => $commentListStyle,
            'categories' => $categoryListStyle,
        )) . ';';
        if ($abLegacyTypecho) {
            $earlyScript .= 'document.documentElement.setAttribute("data-ab-tc","12");';
        }
        $earlyScript .= 'function abSyncListMode(){'
            .   'var h=document.documentElement,u=(location.pathname||"")+(location.search||"");'
            .   'h.removeAttribute("data-ab-postlist");h.removeAttribute("data-ab-pagelist");h.removeAttribute("data-ab-commentlist");h.removeAttribute("data-ab-categorylist");h.removeAttribute("data-ab-listcard");'
            .   'var attr="",mode="";'
            .   'if(u.indexOf("manage-posts.php")!==-1){attr="data-ab-postlist";mode=AB_LIST_MODES.posts;}'
            .   'else if(u.indexOf("manage-pages.php")!==-1){attr="data-ab-pagelist";mode=AB_LIST_MODES.pages;}'
            .   'else if(u.indexOf("manage-comments.php")!==-1){attr="data-ab-commentlist";mode=AB_LIST_MODES.comments;}'
            .   'else if(u.indexOf("manage-categories.php")!==-1){attr="data-ab-categorylist";mode=AB_LIST_MODES.categories;}'
            .   'if(!attr||!mode)return;'
            .   'h.setAttribute(attr,mode);'
            .   'if(mode==="card")h.setAttribute("data-ab-listcard","1");'
            . '}'
            . 'abSyncListMode();'
            . 'document.addEventListener("ab:pageload",abSyncListMode);'
            . 'window.addEventListener("popstate",abSyncListMode);'
            . 'if(window.history){["pushState","replaceState"].forEach(function(n){'
            .   'var orig=history[n];if(typeof orig!=="function")return;'
            .   'history[n]=function(){var r=orig.apply(this,arguments);try{abSyncListMode();}catch(e){}return r;};'
            . '});}';
        $earlyScript .= 'document.documentElement.setAttribute("data-ab-loading","");';
        $earlyScript .= '</script>';
        $colors = self::getColorScheme($primaryColor);
        $lightBg = isset($colors['--md-surface'])      ? $colors['--md-surface']      : '#FFFBFE';
        $darkBg  = isset($colors['--md-dark-surface']) ? $colors['--md-dark-surface'] : '#1C1B1F';
        $colorSchemeValue = 'light dark';
        $injectHead = "\n" . '<meta name="color-scheme" content="' . $colorSchemeValue . '">';
        $injectHead .= "\n" . $earlyScript;
        $injectHead .= "\n" . '<style>';
        $injectHead .= '[data-ab-loading],[data-ab-loading] *{transition:none!important;}';
        $injectHead .= '[data-ab-loading] .typecho-head-nav{visibility:hidden!important;}';
        $injectHead .= 'html,body{background:' . $lightBg . '!important;}';
        $injectHead .= 'html[data-theme="dark"],html[data-theme="dark"] body{background:' . $darkBg . '!important;}';
        $injectHead .= ':root{';
        $injectHead .= 'color-scheme:' . $colorSchemeValue . ';';
        foreach ($colors as $key => $value) {
            $injectHead .= $key . ':' . $value . ';';
        }
        $radiusMap = array(
            'small'  => array('--md-radius-xs' => '4px', '--md-radius-sm' => '6px', '--md-radius-md' => '8px', '--md-radius-lg' => '12px', '--md-radius-xl' => '16px', '--md-radius-full' => '9999px'),
            'medium' => array('--md-radius-xs' => '6px', '--md-radius-sm' => '8px', '--md-radius-md' => '12px', '--md-radius-lg' => '16px', '--md-radius-xl' => '28px', '--md-radius-full' => '9999px'),
            'large'  => array('--md-radius-xs' => '8px', '--md-radius-sm' => '12px', '--md-radius-md' => '16px', '--md-radius-lg' => '24px', '--md-radius-xl' => '32px', '--md-radius-full' => '9999px'),
        );
        if (isset($radiusMap[$borderRadius])) {
            foreach ($radiusMap[$borderRadius] as $key => $value) {
                $injectHead .= $key . ':' . $value . ';';
            }
        }
        if ($enableAnimation === '0') {
            $injectHead .= '--md-transition-duration:0s;';
        } else {
            $injectHead .= '--md-transition-duration:0.2s;';
        }
        $injectHead .= '}';
        $injectHead .= '[data-ab-loading] body{visibility:hidden!important;}';
        if ($loadingAnimation === 'topbar') {
            $injectHead .= '#ab-page-loader{display:none;position:fixed;top:0;left:0;right:0;height:4px;z-index:999999;background:rgba(103,80,164,.18);pointer-events:none;overflow:hidden;}';
            $injectHead .= '[data-theme="dark"] #ab-page-loader{background:rgba(208,188,255,.2)!important;}';
            $injectHead .= '#ab-loader-spinner{position:absolute;left:0;top:0;height:100%;width:34%;background:linear-gradient(90deg,var(--md-primary,#6750a4),rgba(103,80,164,.68));border-radius:0 3px 3px 0;box-shadow:0 0 14px rgba(103,80,164,.45);animation:ab-topbar-loading 1.25s ease-in-out infinite;}';
            $injectHead .= '[data-ab-loading] #ab-page-loader{display:block!important;visibility:visible!important;}';
            $injectHead .= '@keyframes ab-topbar-loading{0%{left:-36%;width:36%}55%{left:40%;width:46%}100%{left:100%;width:32%}}';
        } elseif ($loadingAnimation === 'morph') {
            $injectHead .= '#ab-page-loader{display:none;position:fixed;top:0;left:0;right:0;bottom:0;z-index:999999;background:var(--md-surface,#FFFBFE);align-items:center;justify-content:center;}';
            $injectHead .= '[data-theme="dark"] #ab-page-loader{background:var(--md-dark-surface,#1C1B1F)!important;}';
            $injectHead .= '[data-ab-loading] #ab-page-loader{display:flex!important;visibility:visible!important;}';
            $injectHead .= '#ab-loader-spinner{width:48px;height:48px;background:var(--md-primary,#6750a4);animation:ab-morph-shape var(--ab-m3-loader-duration,4.9s) var(--ab-m3-loader-easing,cubic-bezier(.34,1.16,.44,1)) infinite;}';
            $injectHead .= '[data-theme="dark"] #ab-loader-spinner{background:var(--md-dark-primary,#d0bcff);}';
        } else {
            $injectHead .= '#ab-page-loader{display:none;position:fixed;top:0;left:0;right:0;bottom:0;z-index:999999;background:var(--md-surface,#FFFBFE);align-items:center;justify-content:center;}';
            $injectHead .= '[data-theme="dark"] #ab-page-loader{background:var(--md-dark-surface,#1C1B1F)!important;}';
            $injectHead .= '[data-ab-loading] #ab-page-loader{display:flex!important;visibility:visible!important;}';
            $injectHead .= '#ab-loader-spinner{width:44px;height:44px;border-radius:50%;border:3.5px solid rgba(0,0,0,0.1);border-top-color:var(--md-primary,#1976D2);animation:ab-spin 0.72s linear infinite;}';
            $injectHead .= '[data-theme="dark"] #ab-loader-spinner{border-color:rgba(255,255,255,0.1);border-top-color:var(--md-primary,#90CAF9);}';
        }
        $injectHead .= '@keyframes ab-spin{to{transform:rotate(360deg)}}';
        $injectHead .= '</style>';
        $abCssFile = dirname(__FILE__) . '/assets/AdminBeautify.v2.1.63.css';
        $abCssVer = is_file($abCssFile) ? (string) filemtime($abCssFile) : '0';
        $injectTail = "\n" . '<link rel="stylesheet" href="' . $cssUrl . '.v2.1.63.css?v=' . $abCssVer . '">';
        $editorVditor = isset($pluginOptions->editor_vditor) ? (string)$pluginOptions->editor_vditor : '1';
        $reqUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        $isWritePage = (strpos($reqUri, 'write-post.php') !== false || strpos($reqUri, 'write-page.php') !== false);
        if ($editorVditor === '1' && $isWritePage) {
            $vditorIndexCssFile = dirname(__FILE__) . '/assets/lib/vditor/index.css';
            $vditorIndexCssUrl = Typecho_Common::url('AdminBeautify/assets/lib/vditor/index.css', $options->pluginUrl)
                . '?v=' . (is_file($vditorIndexCssFile) ? filemtime($vditorIndexCssFile) : '0');
            echo '<link rel="stylesheet" href="' . htmlspecialchars($vditorIndexCssUrl) . '">';
        }
        if ($editorVditor === '3' && $isWritePage) {
            $editorMdBaseCssUrl = Typecho_Common::url('AdminBeautify/assets/lib/editor.md/css/editormd.min.css', $options->pluginUrl);
            $editorMdMd3CssUrl  = Typecho_Common::url('AdminBeautify/assets/lib/editor.md/editormd_v1.0.0.css', $options->pluginUrl);
            echo '<link rel="stylesheet" href="' . htmlspecialchars($editorMdBaseCssUrl) . '">';
            echo '<link rel="stylesheet" href="' . htmlspecialchars($editorMdMd3CssUrl) . '">';
        }
        $editorHideToolbar = isset($pluginOptions->editor_hideToolbar) ? (string)$pluginOptions->editor_hideToolbar : '0';
        if ($editorVditor === '2' && $editorHideToolbar === '1' && $isWritePage) {
            $injectTail .= '<style>body #wmd-button-bar,body .wmd-button-bar{display:none!important;}</style>';
        }
        if ($editorVditor === '3' && $isWritePage) {
            $injectTail .= '<style>body #wmd-button-bar,body #wmd-button-row,body #wmd-preview,body #wmd-editarea{display:none!important;}</style>';
        }
        $resIconUrl = Typecho_Common::url('AdminBeautify/assets/fonts/MDIR/MaterialIconsRound.css', $options->pluginUrl);
        $injectTail .= "\n" . '<link rel="stylesheet" href="' . htmlspecialchars($resIconUrl) . '">';
        $injectTail .= '<script>document.addEventListener("DOMContentLoaded",function(){var h=document.documentElement;if(h.getAttribute("data-ab-loader")==="topbar"){setTimeout(function(){h.removeAttribute("data-ab-loading");},260);}else{h.removeAttribute("data-ab-loading");}},false);</script>';
        $themeColorMap = array(
            'purple' => '#7D5260', 'blue' => '#556270', 'teal' => '#4A6363',
            'green'  => '#55624C', 'orange' => '#725A42', 'pink' => '#74565F', 'red' => '#775654',
        );
        $themeHex = isset($themeColorMap[$primaryColor]) ? $themeColorMap[$primaryColor] : '#7D5260';
        $manifestUrl = Typecho_Common::url('/action/admin-beautify?do=manifest', $options->index);
        $pwaAppName = isset($pluginOptions->pwa_appName) ? trim((string) $pluginOptions->pwa_appName) : '';
        $pwaAppIcon = isset($pluginOptions->pwa_appIcon) ? trim((string) $pluginOptions->pwa_appIcon) : '';
        $pwaTitle = ($pwaAppName !== '') ? $pwaAppName : ((string) $options->title . ' 管理后台');
        $injectTail .= "\n" . '<link rel="manifest" href="' . htmlspecialchars($manifestUrl) . '">';
        $injectTail .= "\n" . '<meta name="theme-color" content="' . $themeHex . '">';
        $injectTail .= "\n" . '<meta name="apple-mobile-web-app-capable" content="yes">';
        $injectTail .= "\n" . '<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">';
        $injectTail .= "\n" . '<meta name="apple-mobile-web-app-title" content="' . htmlspecialchars($pwaTitle) . '">';
        $injectTail .= "\n" . '<meta name="mobile-web-app-capable" content="yes">';
        if ($pwaAppIcon !== '') {
            $injectTail .= "\n" . '<link rel="apple-touch-icon" sizes="180x180" href="' . htmlspecialchars($pwaAppIcon) . '">';
        }
        $telemetryOptOut = isset($pluginOptions->telemetryOptOut) ? (string)$pluginOptions->telemetryOptOut : '0';
        if ($telemetryOptOut !== '1') {
            $injectTail .= "\n" . '<script defer src="https://stats.lhl.one/script.js" data-website-id="dfabc99f-991e-4f7c-9358-03177fbee0ec"></script>';
        }
        return $injectHead . $header . $injectTail;
    }
    public static function renderFooter()
    {
        if (self::isLoginPage()) {
            return;
        }
        if (self::storeBoot()) {
            AdminBeautify_StoreTakeover::finish();
        }
        echo '<div id="ab-page-loader"><div id="ab-loader-spinner"></div></div>';
        $options = Typecho_Widget::widget('Widget_Options');
        $pluginOptions = self::pluginOptions($options);
        $darkMode = $pluginOptions->darkMode ?: 'auto';
        $rawAnim = isset($pluginOptions->enableAnimation) ? (string)$pluginOptions->enableAnimation : '';
        $enableAnimation = ($rawAnim !== '') ? $rawAnim : '1';
        $pluginCardView = '1';
        $postListStyle = isset($pluginOptions->postListStyle) ? (string)$pluginOptions->postListStyle : 'card';
        if ($postListStyle !== 'list') $postListStyle = 'card';
        $pageListStyle = isset($pluginOptions->pageListStyle) ? (string)$pluginOptions->pageListStyle : 'card';
        if ($pageListStyle !== 'list') $pageListStyle = 'card';
        $commentListStyle = isset($pluginOptions->commentListStyle) ? (string)$pluginOptions->commentListStyle : 'card';
        if ($commentListStyle !== 'list') $commentListStyle = 'card';
        $categoryListStyle = isset($pluginOptions->categoryListStyle) ? (string)$pluginOptions->categoryListStyle : 'card';
        if ($categoryListStyle !== 'list') $categoryListStyle = 'card';
        $editorVditor = isset($pluginOptions->editor_vditor) ? (string)$pluginOptions->editor_vditor : '1';
        $editorVditorMode = isset($pluginOptions->editor_vditorMode) ? (string)$pluginOptions->editor_vditorMode : 'ir';
        $dashboardQuickShow = isset($pluginOptions->dashboardQuickShow) ? (string)$pluginOptions->dashboardQuickShow : '1';
        $dashboardQuickStyle = isset($pluginOptions->dashboardQuickStyle) ? (string)$pluginOptions->dashboardQuickStyle : 'small';
        $dashboardQuickHint = isset($pluginOptions->dashboardQuickHint) ? (string)$pluginOptions->dashboardQuickHint : '1';
        $dashboardHideDonate = isset($pluginOptions->dashboardHideDonate) ? (string)$pluginOptions->dashboardHideDonate : '0';
        $dashboardCustomButtons = isset($pluginOptions->dashboardCustomButtons) ? (string)$pluginOptions->dashboardCustomButtons : '';
        $dashboardRecentStyle = isset($pluginOptions->dashboardRecentStyle) ? (string)$pluginOptions->dashboardRecentStyle : 'md3';
        $dashboardCardOrder   = isset($pluginOptions->dashboardCardOrder)   ? (string)$pluginOptions->dashboardCardOrder   : '';
        $dashboardCardGroups = self::normalizeCardGroups(
            isset($pluginOptions->dashboardCardGroups) ? (string)$pluginOptions->dashboardCardGroups : ''
        );
        $dashboardCustomCardsEnabled = isset($pluginOptions->dashboardCustomCardsEnabled) ? (string)$pluginOptions->dashboardCustomCardsEnabled : '0';
        $dashboardLayout      = isset($pluginOptions->dashboardLayout)      ? (string)$pluginOptions->dashboardLayout      : 'masonry';
        if ($dashboardLayout !== 'masonry' && $dashboardLayout !== 'grid') $dashboardLayout = 'masonry';
        $dashboardMoreCardEnabled = isset($pluginOptions->dashboardMoreCardEnabled) ? (string)$pluginOptions->dashboardMoreCardEnabled : '1';
        if ($dashboardMoreCardEnabled !== '0') $dashboardMoreCardEnabled = '1';
        $dashboardCustomCardsRaw = isset($pluginOptions->dashboardCustomCards) ? (string)$pluginOptions->dashboardCustomCards : '';
        $dashboardCustomCards = array();
        if ($dashboardCustomCardsEnabled === '1' && $dashboardCustomCardsRaw !== '') {
            $dashboardCustomCards = self::normalizeCards(json_decode($dashboardCustomCardsRaw, true));
            if (!empty($dashboardCustomCards)) {
                self::hydrateCards($dashboardCustomCards);
                $renderable = array();
                foreach ($dashboardCustomCards as $cardItem) {
                    if ($cardItem['html'] === '' && $cardItem['js'] === '') {
                        if ($cardItem['code'] !== 'db') continue;
                        $cardItem['html'] = '<div style="padding:12px;font-size:13px;line-height:1.7;opacity:.8">'
                            . '⚠️ 卡片代码缺失：数据表里没有找到这张卡片的代码，请到「插件 → AB Admin → 概要页卡片设置」重新粘贴代码后保存。'
                            . '</div>';
                        $cardItem['js'] = '';
                    }
                    $renderable[] = $cardItem;
                }
                $dashboardCustomCards = $renderable;
            }
        }
        $dashboardThemeButtonShow = isset($pluginOptions->dashboardThemeButtonShow) ? (string)$pluginOptions->dashboardThemeButtonShow : 'merge';
        $dashboardThemeButtonShow = ($dashboardThemeButtonShow === '0' || $dashboardThemeButtonShow === 'hide') ? 'hide' : 'merge';
        $overviewChartEnabled = isset($pluginOptions->overviewChartEnabled) ? (string)$pluginOptions->overviewChartEnabled : '1';
        $overviewTimeRange    = isset($pluginOptions->overviewTimeRange)    ? (string)$pluginOptions->overviewTimeRange    : '30';
        $umamiEnabled         = isset($pluginOptions->umamiEnabled)         ? (string)$pluginOptions->umamiEnabled         : '0';
        $umamiProvider        = isset($pluginOptions->umamiProvider)        ? (string)$pluginOptions->umamiProvider        : 'self';
        $umamiApiBase         = isset($pluginOptions->umamiApiBase)         ? (string)$pluginOptions->umamiApiBase         : '';
        $umamiWebsiteId       = isset($pluginOptions->umamiWebsiteId)       ? (string)$pluginOptions->umamiWebsiteId       : '';
        $umamiApiToken        = isset($pluginOptions->umamiApiToken)        ? (string)$pluginOptions->umamiApiToken        : '';
        $umamiTimeRange       = isset($pluginOptions->umamiTimeRange)       ? (string)$pluginOptions->umamiTimeRange       : '30';
        $ajaxEnabled          = isset($pluginOptions->ajaxEnabled)          ? (string)$pluginOptions->ajaxEnabled          : '1';
        $loadingAnimation     = isset($pluginOptions->loadingAnimation)     ? (string)$pluginOptions->loadingAnimation     : 'morph';
        if (!in_array($loadingAnimation, array('spinner', 'topbar', 'morph'), true)) {
            $loadingAnimation = 'morph';
        }
        $updateChannel = isset($pluginOptions->updateChannel) ? (string)$pluginOptions->updateChannel : 'stable';
        if ($updateChannel !== 'beta') $updateChannel = 'stable';
        $primaryColorScheme = $pluginOptions->primaryColor ?: 'purple';
        $colorSchemeData = self::getColorScheme($primaryColorScheme);
        $primaryColorHex     = $colorSchemeData['--md-primary'];
        $primaryColorDarkHex = $colorSchemeData['--md-dark-primary'];
        $user = Typecho_Widget::widget('Widget_User');
        $avatarUrl  = '';
        $avatarHost = 'https://gravatar.loli.net/avatar';
        if ($user->hasLogin() && $user->mail) {
            $avatarSrcOpt   = isset($pluginOptions->avatarSource)    ? (string)$pluginOptions->avatarSource    : 'loli';
            $customAvatarOpt = isset($pluginOptions->customAvatarUrl) ? trim((string)$pluginOptions->customAvatarUrl) : '';
            $avatarHostMap = array(
                'loli'     => 'https://gravatar.loli.net/avatar',
                'gravatar' => 'https://www.gravatar.com/avatar',
                'cravatar' => 'https://cravatar.cn/avatar',
                'custom'   => rtrim($customAvatarOpt, '/'),
            );
            $avatarHost = (isset($avatarHostMap[$avatarSrcOpt]) && $avatarHostMap[$avatarSrcOpt] !== '')
                ? $avatarHostMap[$avatarSrcOpt]
                : 'https://gravatar.loli.net/avatar';
            $hash = md5(strtolower(trim($user->mail)));
            $avatarUrl = $avatarHost . '/' . $hash . '?s=80&d=mp';
        }
        $screenName = $user->hasLogin() ? $user->screenName : '';
        $ajaxUrl = Typecho_Common::url('/action/admin-beautify', $options->index);
        $security = Typecho_Widget::widget('Widget_Security');
        $token = $security->getToken($ajaxUrl);
        echo '<script>window.__AB_USER__=' . json_encode(array(
            'avatar' => $avatarUrl,
            'name'   => $screenName,
        )) . ';';
        echo 'window.__AB_AJAX__=' . json_encode(array(
            'url'   => $ajaxUrl,
            'token' => $token,
        )) . ';';
        echo 'window.__AB_AVATAR_HOST__=' . json_encode($avatarHost) . ';';
        echo '</script>';
        echo '<script>(function(){';
        echo 'var host=window.__AB_AVATAR_HOST__;';
        echo 'if(!host)return;';
        echo 'function replaceAvatar(img){';
        echo '  var src=img.getAttribute("src")||"";';
        echo '  var m=src.match(/https?:\/\/[^\/]+\/avatar\/([a-f0-9]{32})(.*)/);';
        echo '  if(m)img.setAttribute("src",host+"/"+m[1]+m[2]);';
        echo '}';
        echo 'function runReplace(){';
        echo '  var imgs=document.querySelectorAll(".profile-avatar img,.ab-profile-avatar-wrap img,td.author img,.typecho-list-table td img");';
        echo '  [].forEach.call(imgs,function(img){replaceAvatar(img);});';
        echo '}';
        echo 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",runReplace);}';
        echo 'else{runReplace();}';
        echo 'document.addEventListener("ab:pageload",runReplace);';
        echo '})();</script>';
        echo '<script>';
        $notifyOptOut = isset($pluginOptions->notifyOptOut) ? (string)$pluginOptions->notifyOptOut : '0';
        $customBtnsRaw = $dashboardCustomButtons;
        $customBtnsParsed = array();
        foreach (array_filter(array_map('trim', explode("\n", $customBtnsRaw))) as $line) {
            $parts = array_map('trim', explode(':', $line, 4));
            if (count($parts) >= 2 && $parts[0] !== '' && $parts[1] !== '') {
                $customBtnsParsed[] = array(
                    'label'     => $parts[0],
                    'href'      => $parts[1],
                    'icon'      => isset($parts[2]) && $parts[2] !== '' ? $parts[2] : 'link',
                    'highlight' => isset($parts[3]) && trim(strtolower($parts[3])) === 'highlight',
                );
            }
        }
        $enabledCompatPlugins = array();
        $compatEnabledRaw = isset($pluginOptions->compat_disabledScripts) ? (string)$pluginOptions->compat_disabledScripts : '';
        $compatEnabledFiles = ($compatEnabledRaw !== '') ? (array)json_decode($compatEnabledRaw, true) : array();
        if (is_array($compatEnabledFiles) && !empty($compatEnabledFiles)) {
            $compatDir = dirname(__FILE__) . '/assets/compat/';
            foreach ($compatEnabledFiles as $compatFile) {
                if (substr($compatFile, -3) === '.js' && is_file($compatDir . $compatFile)) {
                    $compatMeta = self::parseCompatMeta($compatDir . $compatFile);
                    if (!empty($compatMeta['plugins'])) {
                        foreach (array_map('trim', explode(',', $compatMeta['plugins'])) as $pName) {
                            if ($pName !== '') $enabledCompatPlugins[] = strtolower($pName);
                        }
                    }
                }
            }
        }
        $enabledCompatPlugins = array_values(array_unique($enabledCompatPlugins));
        $pendingCompatSuggestions = array();
        $compatDirScan = dirname(__FILE__) . '/assets/compat/';
        $pluginsBaseDir = dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR;
        if (is_dir($compatDirScan)) {
            $scanFiles = @scandir($compatDirScan);
            if ($scanFiles) {
                foreach ($scanFiles as $scanFile) {
                    if (substr($scanFile, -3) !== '.js' || !is_file($compatDirScan . $scanFile)) continue;
                    if (is_array($compatEnabledFiles) && in_array($scanFile, $compatEnabledFiles)) continue;
                    $scanMeta = self::parseCompatMeta($compatDirScan . $scanFile);
                    if (empty($scanMeta['plugins'])) continue;
                    $scanPluginList = array_map('trim', explode(',', $scanMeta['plugins']));
                    foreach ($scanPluginList as $scanPlugin) {
                        if ($scanPlugin === '') continue;
                        if (is_dir($pluginsBaseDir . $scanPlugin)) {
                            $pendingCompatSuggestions[] = array(
                                'file'        => $scanFile,
                                'name'        => ($scanMeta['name'] !== '' ? $scanMeta['name'] : basename($scanFile, '.js')),
                                'plugin'      => $scanPlugin,
                                'description' => $scanMeta['description'],
                            );
                            break;
                        }
                    }
                }
            }
        }
        $pluginSettingsUrl = $options->adminUrl . 'options-plugin.php?config=AdminBeautify';
        $currentPageCompatKey = '';
        $requestUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        if (strpos($requestUri, 'options-plugin.php') !== false && isset($_GET['config'])) {
            $currentPageCompatKey = strtolower(trim((string)$_GET['config']));
        } elseif (strpos($requestUri, 'options-theme.php') !== false) {
            $currentPageCompatKey = strtolower(trim((string)$options->theme));
        } elseif (strpos($requestUri, 'extending.php') !== false && isset($_GET['panel'])) {
            $panelParts = explode('/', trim((string)$_GET['panel']));
            $currentPageCompatKey = strtolower($panelParts[0]);
        }
        $vditorAssetBaseUrl = Typecho_Common::url('AdminBeautify/assets/lib/vditor', $options->pluginUrl);
        $vditorIndexJsFile = dirname(__FILE__) . '/assets/lib/vditor/index.min.js';
        $vditorLocalJsUrl = Typecho_Common::url('AdminBeautify/assets/lib/vditor/index.min.js', $options->pluginUrl)
            . '?v=' . (is_file($vditorIndexJsFile) ? filemtime($vditorIndexJsFile) : '0');
        $vditorUploadUrl = Typecho_Common::url('/action/admin-beautify?do=upload-media', $options->index);
        $editorMdAssetBaseUrl = Typecho_Common::url('AdminBeautify/assets/lib/editor.md', $options->pluginUrl);
        $editorMdLibPath = Typecho_Common::url('AdminBeautify/assets/lib/editor.md/lib/', $options->pluginUrl);
        $editorMdUploadUrl = Typecho_Common::url('/action/admin-beautify?do=upload-media', $options->index);
        $rawAllowedAttachmentTypes = isset($options->allowedAttachmentTypes)
            ? $options->allowedAttachmentTypes
            : array();
        if (is_string($rawAllowedAttachmentTypes)) {
            $rawAllowedAttachmentTypes = explode(',', $rawAllowedAttachmentTypes);
        } elseif (!is_array($rawAllowedAttachmentTypes)) {
            $rawAllowedAttachmentTypes = array();
        }
        $uploadAcceptExt = array();
        foreach ($rawAllowedAttachmentTypes as $ext) {
            $ext = strtolower(ltrim(trim((string)$ext), '.'));
            if ($ext !== '') {
                $uploadAcceptExt[] = '.' . $ext;
            }
        }
        $uploadAcceptExt = array_values(array_unique($uploadAcceptExt));
        $uploadAccept = implode(',', $uploadAcceptExt);
        $uploadMaxBytes = self::minPositiveBytes(array(
            self::iniSizeToBytes(function_exists('ini_get') ? ini_get('upload_max_filesize') : '0'),
            self::iniSizeToBytes(function_exists('ini_get') ? ini_get('post_max_size') : '0'),
        ));
        $currentUserInfo = array('uid' => 0, 'name' => '', 'screenName' => '', 'group' => '');
        try {
            $abCurUser = Typecho_Widget::widget('Widget_User');
            if ($abCurUser->hasLogin()) {
                $currentUserInfo = array(
                    'uid'        => (int) $abCurUser->uid,
                    'name'       => (string) $abCurUser->name,
                    'screenName' => (string) ($abCurUser->screenName !== '' ? $abCurUser->screenName : $abCurUser->name),
                    'group'      => (string) $abCurUser->group,
                );
            }
        } catch (Exception $e) {
        } catch (Throwable $e) {
        }
        echo 'window.__AB_CONFIG__=' . json_encode(array(
            'darkMode'               => $darkMode,
            'enableAnimation'        => $enableAnimation,
            'pluginCardView'         => $pluginCardView,
            'postListStyle'          => $postListStyle,
            'pageListStyle'          => $pageListStyle,
            'commentListStyle'       => $commentListStyle,
            'categoryListStyle'      => $categoryListStyle,
            'siteName'               => $options->title,
            'user'                   => $currentUserInfo,
            'pluginUrl'              => (string)$options->pluginUrl,
            'ajaxUrl'                => $ajaxUrl,
            'ajaxToken'              => $token,
            'editorVditor'           => $editorVditor,
            'editorVditorMode'       => $editorVditorMode,
            'vditorAssetBaseUrl'     => $vditorAssetBaseUrl,
            'vditorLocalJsUrl'       => $vditorLocalJsUrl,
            'vditorCdnBaseUrl'       => $vditorAssetBaseUrl,
            'vditorUploadUrl'        => $vditorUploadUrl,
            'editorMdAssetBaseUrl'   => $editorMdAssetBaseUrl,
            'editorMdLibPath'        => $editorMdLibPath,
            'editorMdUploadUrl'      => $editorMdUploadUrl,
            'uploadAccept'           => $uploadAccept,
            'uploadMaxBytes'         => $uploadMaxBytes,
            'pluginVersion'          => '2.1.63',
            'notifyOptOut'           => $notifyOptOut,
            'dashboardQuickShow'     => $dashboardQuickShow,
            'dashboardQuickStyle'    => $dashboardQuickStyle,
            'dashboardQuickHint'     => $dashboardQuickHint,
            'dashboardHideDonate'    => $dashboardHideDonate,
            'dashboardCustomButtons' => $customBtnsParsed,
            'dashboardRecentStyle'   => $dashboardRecentStyle,
            'dashboardCardOrder'     => $dashboardCardOrder,
            'dashboardCardGroups'    => $dashboardCardGroups,
            'dashboardCustomCardsEnabled' => $dashboardCustomCardsEnabled,
            'dashboardLayout'        => $dashboardLayout,
            'dashboardMoreCardEnabled' => $dashboardMoreCardEnabled,
            'dashboardCustomCards'   => $dashboardCustomCards,
            'dashboardThemeButtonShow' => $dashboardThemeButtonShow,
            'overviewChartEnabled'   => $overviewChartEnabled,
            'overviewTimeRange'      => $overviewTimeRange,
            'ajaxEnabled'            => $ajaxEnabled,
            'loadingAnimation'       => $loadingAnimation,
            'updateChannel'          => $updateChannel,
            'umamiEnabled'           => $umamiEnabled,
            'umamiProvider'          => $umamiProvider,
            'umamiApiBase'           => $umamiApiBase,
            'umamiWebsiteId'         => $umamiWebsiteId,
            'umamiApiToken'          => $umamiApiToken,
            'umamiTimeRange'         => $umamiTimeRange,
            'primaryColorHex'        => $primaryColorHex,
            'primaryColorDarkHex'    => $primaryColorDarkHex,
            'enabledCompatPlugins'       => $enabledCompatPlugins,
            'currentPageCompatKey'       => $currentPageCompatKey,
            'pendingCompatSuggestions'   => $pendingCompatSuggestions,
            'pluginSettingsUrl'          => $pluginSettingsUrl,
        )) . ';</script>';
        $jsUrlPrefix = Typecho_Common::url('AdminBeautify/assets/AdminBeautify.min', $options->pluginUrl);
        $abJsFile = dirname(__FILE__) . '/assets/AdminBeautify.min.v2.1.63.js';
        $abJsVer = is_file($abJsFile) ? (string) filemtime($abJsFile) : '0';
        echo '<script src="' . $jsUrlPrefix . '.v2.1.63.js?v=' . $abJsVer . '"></script>';
        echo '<script>(function(){"use strict";
  var CQ = 575, OPEN = "ab-search-open";
  function box(f){ return f.querySelector(".search"); }
  function inp(f){ var b = box(f); return b ? b.querySelector(":scope > input[type=text]") : null; }
  function narrow(f){ return f.getBoundingClientRect().width <= CQ; }
  function filtered(f){
    if (f.querySelector(".search > a, .ab-filter-group > a")) return true;
    var i = inp(f); return !!(i && i.value);
  }
  /* 实测展开态输入框的「尾部长度」：左容器宽 + 容器左右内边距 + (输入框之后每个可见兄弟的宽 + 间隔)。
     减 1px 是故意的：让右容器内容宽略大于可用宽，靠 flex-shrink 精确收在可用宽度上，接缝恒为 0 */
  function sizeTail(f){
    var b = box(f), i = inp(f);
    if (!b || !i) return;
    var cs = getComputedStyle(b), gap = parseFloat(cs.columnGap) || 0;
    var op = f.querySelector(".operate");
    var tail = op ? op.getBoundingClientRect().width : 0;
    tail += (parseFloat(cs.paddingLeft) || 0) + (parseFloat(cs.paddingRight) || 0);
    var k = b.children, seen = false;
    for (var j = 0; j < k.length; j++){
      if (k[j] === i){ seen = true; continue; }
      if (!seen) continue;
      var st = getComputedStyle(k[j]);
      if (st.display === "none" || st.position === "absolute") continue;
      tail += k[j].getBoundingClientRect().width + gap;
    }
    f.style.setProperty("--ab-tail", (tail - 1).toFixed(2) + "px");
  }
  /* 移动端把「« 取消筛选」搬进第一行的 .ab-filter-group（它是 .search 的第一个子元素，
     order 挪不出容器，只能真搬 DOM）；桌面再搬回原位 */
  function placeLink(f){
    var b = box(f), g = f.querySelector(".ab-filter-group");
    if (!b || !g) return;
    var a = b.querySelector(":scope > a") || g.querySelector(":scope > a");
    if (!a) return;
    if (!a.__abHome) a.__abHome = { p: b, n: a.nextSibling };
    if (narrow(f)){ if (a.parentNode !== g) g.insertBefore(a, g.firstChild); }
    else if (a.parentNode !== b) b.insertBefore(a, a.__abHome.n);
  }
  function sync(f){
    var btn = f.querySelector(".ab-filter-toggle");
    if (!btn) return;
    btn.setAttribute("aria-expanded", f.classList.contains(OPEN) ? "true" : "false");
    btn.setAttribute("aria-disabled", (narrow(f) && filtered(f)) ? "true" : "false");
  }
  /* 折叠按钮是 JS 注入的（不改 Typecho 模板）：
     <span class="ab-filter-group"><button class="ab-filter-toggle">两种图标</button></span> */
  function ensureToggle(f){
    var op = f.querySelector(".operate");
    if (!op || op.querySelector(".ab-filter-toggle")) return;
    var g = op.querySelector(".ab-filter-group");
    if (!g){ g = document.createElement("span"); g.className = "ab-filter-group"; op.appendChild(g); }
    var b = document.createElement("button");
    b.className = "ab-filter-toggle";
    b.type = "button";
    var sub = f.querySelector(".search > .btn");
    b.setAttribute("aria-label", (sub && sub.textContent.trim()) || "筛选");
    var i1 = document.createElement("i"); i1.className = "material-icons-round ab-ft-open"; i1.textContent = "filter_alt";
    var i2 = document.createElement("i"); i2.className = "material-icons-round ab-ft-close"; i2.textContent = "close";
    b.appendChild(i1); b.appendChild(i2);
    g.appendChild(b);
  }
  function each(fn){
    var fs = document.querySelectorAll("form.typecho-list-operate");
    for (var i = 0; i < fs.length; i++){
      /* ⚠️ 列表**底部**还有一条同名 form（只有「选中项」+ 分页，没有 .search）——
         它不是工具条：不给它插折叠按钮，也不需要量 --ab-tail。 */
      if (!fs[i].querySelector(".search")) continue;
      ensureToggle(fs[i]); fn(fs[i]);
    }
  }
  function sizeAll(){ each(function(f){ placeLink(f); sizeTail(f); }); }
  function init(){
    each(function(f){
      var i = inp(f);
      if (!i) return;
      placeLink(f); sizeTail(f);
      if (i.value || (narrow(f) && filtered(f))) f.classList.add(OPEN);
      sync(f);
    });
  }
  /* ⚠️⚠️ 监听器只能绑一次！Typecho 后台的 AJAX 翻页会把整段脚本**再执行一遍**
     （服务端只输出一次，DOM 里会变成两份），于是 document 上的 click 处理器被绑两遍：
     一次点击里两个处理器各 toggle 一次 → 又切回原状 = 净零。
     表现就是移动端点「筛选」折叠按钮“没反应”（桌面看不出来 —— 桌面靠 :focus-within
     展开、按钮本身是 display:none）。
     所以监听器用 window 标记守一道；但 init() 每次执行都跑，
     保证 AJAX 换页后新出现的工具条也能被初始化。 */
  if (!window.__abToolbarBound){
  window.__abToolbarBound = 1;
  document.addEventListener("click", function(e){
    var btn = e.target && e.target.closest ? e.target.closest(".ab-filter-toggle") : null;
    if (!btn) return;
    e.preventDefault();
    var f = btn.closest("form.typecho-list-operate");
    if (!f) return;
    if (filtered(f)){ var i0 = inp(f); if (i0) i0.focus(); return; }
    var open = f.classList.toggle(OPEN);
    if (open){ var i1 = inp(f); if (i1) i1.focus(); }
    else {
      /* 收起时务必把焦点移出去：CSS 的 :has(.search:focus-within) 也算展开，
         刚点过输入框/分类的话这一下会关不上 */
      var a = document.activeElement;
      if (a && a.blur && a.closest && a.closest(".search") && f.contains(a)) a.blur();
    }
    sync(f);
  });
  /* 桌面兜底：浏览器不支持 :has() 时靠这里维持展开态 */
  document.addEventListener("focusin", function(e){
    var t = e.target;
    if (!t || !t.closest || !t.closest(".search")) return;
    var f = t.closest("form.typecho-list-operate");
    if (!f) return;
    f.classList.add(OPEN); sync(f);
  });
  document.addEventListener("focusout", function(e){
    var t = e.target;
    if (!t || !t.closest || !t.closest(".search")) return;
    var f = t.closest("form.typecho-list-operate");
    if (!f) return;
    setTimeout(function(){
      if (narrow(f) || filtered(f)) return;
      var a = document.activeElement;
      if (a && a.closest && a.closest(".search") && f.contains(a)) return;
      f.classList.remove(OPEN); sync(f);
    }, 0);
  });
  window.addEventListener("resize", sizeAll);
  window.addEventListener("load", sizeAll);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(sizeAll);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();})();</script>';
        $reqUriForEditor = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        $isWritePageForEditor = (strpos($reqUriForEditor, 'write-post.php') !== false || strpos($reqUriForEditor, 'write-page.php') !== false);
        if (($editorVditor === '2' || $editorVditor === '3') && $isWritePageForEditor) {
            echo '<script>if(window.AdminBeautify){AdminBeautify.initEditorToolbar=function(){};}</script>';
        }
        if ($darkMode === 'auto') {
            echo '<script>AdminBeautify.watchSystemTheme();</script>';
        }
        $telemetryOptOut = isset($pluginOptions->telemetryOptOut) ? (string)$pluginOptions->telemetryOptOut : '0';
        if ($telemetryOptOut !== '1') {
            echo '<script>(function(){function abTrack(){if(window.umami&&typeof window.umami.track==="function"){window.umami.track("settings_visit",{domain:window.location.hostname,version:"2.1.63"});}else{setTimeout(abTrack,300);}}if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",function(){setTimeout(abTrack,200);});}else{setTimeout(abTrack,200);}})();</script>';
        }
        $reqUriFooter = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        $isWritePageFooter = (strpos($reqUriFooter, 'write-post.php') !== false || strpos($reqUriFooter, 'write-page.php') !== false);
        if ($editorVditor === '1' && $isWritePageFooter) {
            $vditorCssFile = dirname(__FILE__) . '/assets/lib/vditor/vditor_v2.1.1.css';
            $vditorJsFile  = dirname(__FILE__) . '/assets/lib/vditor/vditor_v2.1.1.js';
            $vditorCssUrl = Typecho_Common::url('AdminBeautify/assets/lib/vditor/vditor_v2.1.1.css', $options->pluginUrl)
                . '?v=' . (is_file($vditorCssFile) ? filemtime($vditorCssFile) : '0');
            $vditorJsUrl  = Typecho_Common::url('AdminBeautify/assets/lib/vditor/vditor_v2.1.1.js', $options->pluginUrl)
                . '?v=' . (is_file($vditorJsFile) ? filemtime($vditorJsFile) : '0');
            echo '<link rel="stylesheet" href="' . htmlspecialchars($vditorCssUrl) . '">';
            echo '<script src="' . htmlspecialchars($vditorJsUrl) . '"></script>';
        }
        if ($editorVditor === '3' && $isWritePageFooter) {
            $editorMdBaseJsUrl = Typecho_Common::url('AdminBeautify/assets/lib/editor.md/editormd.js', $options->pluginUrl);
            $editorMdAdapterJsUrl = Typecho_Common::url('AdminBeautify/assets/lib/editor.md/editormd_v1.0.0.js', $options->pluginUrl);
            echo '<script src="' . htmlspecialchars($editorMdBaseJsUrl) . '"></script>';
            echo '<script src="' . htmlspecialchars($editorMdAdapterJsUrl) . '"></script>';
        }
        if ($editorVditor === '0' && $isWritePageFooter) {
            $editorTipUrl = $options->adminUrl . 'options-plugin.php?config=AdminBeautify&to=editor_vditor';
            echo '<style>'
                . '.ab-editor-tip{margin:14px 0 0;display:flex;align-items:flex-start;gap:12px;padding:14px 16px;border-radius:18px;'
                . 'background:var(--md-surface-container-high,#ECE6F0);background:color-mix(in srgb,var(--md-primary,#6750a4) 10%,var(--md-surface-container-low,#F7F2FA));'
                . 'border:1px solid color-mix(in srgb,var(--md-primary,#6750a4) 22%,transparent);box-sizing:border-box;}'
                . '[data-theme="dark"] .ab-editor-tip{background:var(--md-dark-surface-container-high,#2B2930);background:color-mix(in srgb,var(--md-dark-primary,#d0bcff) 12%,var(--md-dark-surface-container-high,#2B2930));'
                . 'border-color:color-mix(in srgb,var(--md-dark-primary,#d0bcff) 22%,transparent);}'
                . '.ab-editor-tip[hidden]{display:none!important;}'
                . '.ab-editor-tip-icon{font-size:22px!important;line-height:1;flex:0 0 auto;margin-top:2px;color:var(--md-primary,#6750a4);}'
                . '[data-theme="dark"] .ab-editor-tip-icon{color:var(--md-dark-primary,#d0bcff);}'
                . '.ab-editor-tip-main{flex:1 1 auto;min-width:0;}'
                . '.ab-editor-tip-title{display:block;font-size:14px;font-weight:600;color:var(--md-on-surface,#1c1b1f);}'
                . '[data-theme="dark"] .ab-editor-tip-title{color:var(--md-dark-on-surface,#e6e1e5);}'
                . '.ab-editor-tip-desc{display:block;margin-top:2px;font-size:12.5px;line-height:1.6;color:var(--md-on-surface-variant,#49454f);}'
                . '[data-theme="dark"] .ab-editor-tip-desc{color:var(--md-dark-on-surface-variant,#cac4d0);}'
                . '.ab-editor-tip-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap;justify-content:flex-end;flex:0 0 auto;}'
                . '.ab-editor-tip-btn{display:inline-flex;align-items:center;gap:4px;height:32px;padding:0 14px;border-radius:999px;border:1px solid transparent;'
                . 'background:transparent;color:var(--md-primary,#6750a4);font-size:13px;font-weight:500;font-family:inherit;cursor:pointer;text-decoration:none;'
                . 'transition:background .15s ease,border-color .15s ease;}'
                . '.ab-editor-tip-btn:hover{background:color-mix(in srgb,var(--md-primary,#6750a4) 10%,transparent);}'
                . '.ab-editor-tip-btn.primary{background:var(--md-primary,#6750a4);color:#fff;}'
                . '.ab-editor-tip-btn.primary:hover{filter:brightness(1.06);}'
                . '.ab-editor-tip-btn.ghost{border-color:var(--md-outline-variant,#CAC4D0);color:var(--md-on-surface-variant,#49454f);}'
                . '[data-theme="dark"] .ab-editor-tip-btn{color:var(--md-dark-primary,#d0bcff);}'
                . '[data-theme="dark"] .ab-editor-tip-btn.ghost{border-color:var(--md-dark-outline-variant,#49454F);color:var(--md-dark-on-surface-variant,#cac4d0);}'
                . '.ab-editor-tip-close{width:32px;height:32px;padding:0;flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;border-radius:50%;'
                . 'border:0;background:transparent;color:var(--md-on-surface-variant,#49454f);cursor:pointer;}'
                . '.ab-editor-tip-close:hover{background:color-mix(in srgb,var(--md-on-surface,#1c1b1f) 8%,transparent);}'
                . '.ab-editor-tip-close .material-icons-round{font-size:18px!important;line-height:1;}'
                . '[data-theme="dark"] .ab-editor-tip-close{color:var(--md-dark-on-surface-variant,#cac4d0);}'
                . '@media (max-width:700px){.ab-editor-tip{flex-wrap:wrap;}.ab-editor-tip-actions{width:100%;justify-content:flex-start;}}'
                . '</style>';
            echo '<div class="ab-editor-tip" id="ab-editor-tip" hidden>'
                . '<span class="material-icons-round ab-editor-tip-icon">tips_and_updates</span>'
                . '<div class="ab-editor-tip-main">'
                .   '<b class="ab-editor-tip-title">AB Admin 有内置编辑器，是否启用？</b>'
                .   '<span class="ab-editor-tip-desc">可切换 AB Vditor / AB Editor.md，获得实时预览、全屏写作与图片上传体验（随时可在插件设置里改回原版）。</span>'
                . '</div>'
                . '<div class="ab-editor-tip-actions">'
                .   '<a class="ab-editor-tip-btn primary" href="' . htmlspecialchars($editorTipUrl) . '">进入插件设置</a>'
                .   '<button type="button" class="ab-editor-tip-btn" data-ab-tip="later">知道了</button>'
                .   '<button type="button" class="ab-editor-tip-btn ghost" data-ab-tip="never">不再提示</button>'
                .   '<button type="button" class="ab-editor-tip-close" data-ab-tip="later" title="暂不提示" aria-label="关闭"><span class="material-icons-round">close</span></button>'
                . '</div>'
                . '</div>';
            echo '<script>(function(){'
                . 'var NEVER="ab-editor-tip-never",LATER="ab-editor-tip-later";'
                . 'function read(kind,key){try{return !!(kind==="local"?localStorage:sessionStorage).getItem(key);}catch(e){return false;}}'
                . 'function write(kind,key){try{(kind==="local"?localStorage:sessionStorage).setItem(key,"1");}catch(e){}}'
                . 'if(read("local",NEVER)||read("session",LATER)){var dead=document.getElementById("ab-editor-tip");if(dead&&dead.parentNode)dead.parentNode.removeChild(dead);return;}'
                . 'var tries=0;'
                . 'function place(){'
                .   'var tip=document.getElementById("ab-editor-tip");'
                .   'if(!tip||tip.getAttribute("data-ab-placed")==="1")return;'
                .   'var area=document.getElementById("wmd-editarea");'
                .   'if(!area){if(++tries<60)setTimeout(place,100);return;}'
                .   'tip.setAttribute("data-ab-placed","1");'
                .   'tip.hidden=false;'
                .   'area.parentNode.insertBefore(tip,area.nextSibling);'
                .   'tip.addEventListener("click",function(e){'
                .     'var btn=e.target&&e.target.closest?e.target.closest("[data-ab-tip]"):null;'
                .     'if(!btn)return;'
                .     'write(btn.getAttribute("data-ab-tip")==="never"?"local":"session",btn.getAttribute("data-ab-tip")==="never"?NEVER:LATER);'
                .     'if(tip.parentNode)tip.parentNode.removeChild(tip);'
                .   '});'
                . '}'
                . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",place);}else{place();}'
                . '}());</script>';
        }
        $swUrl = Typecho_Common::url('/action/admin-beautify?do=sw', $options->index);
        echo '<script>(function(){'
            . 'function abSwToast(){'
            .   'if(document.getElementById("ab-sw-toast"))return;'
            .   'var t=document.createElement("div");'
            .   't.id="ab-sw-toast";'
            .   't.setAttribute("role","alert");'
            .   'var isDark=document.documentElement.getAttribute("data-theme")==="dark";'
            .   'var bg=isDark?"#2d2b31":"#1c1b1f";'
            .   'var fg=isDark?"#e6e1e5":"#f3eff4";'
            .   'var btnBg=isDark?"rgba(208,188,255,.18)":"rgba(208,188,255,.22)";'
            .   't.style.cssText="position:fixed;bottom:24px;left:50%;transform:translateX(-50%) translateY(80px);'
            .     'background:"+bg+";color:"+fg+";padding:14px 20px;border-radius:16px;'
            .     'box-shadow:0 4px 20px rgba(0,0,0,.35);display:flex;align-items:center;gap:14px;'
            .     'font-size:14px;font-family:inherit;z-index:9999;white-space:nowrap;'
            .     'transition:transform .35s cubic-bezier(.4,0,.2,1),opacity .35s;opacity:0;";'
            .   'var txt=document.createElement("span");'
            .   'txt.textContent="✨ 插件已更新，刷新后生效";'
            .   'var btn=document.createElement("button");'
            .   'btn.textContent="立即刷新";'
            .   'btn.style.cssText="border:none;background:"+btnBg+";color:"+fg+";padding:7px 16px;'
            .     'border-radius:999px;cursor:pointer;font-size:13px;font-weight:500;flex-shrink:0;'
            .     'transition:background .15s;";'
            .   'btn.onmouseover=function(){this.style.background=isDark?"rgba(208,188,255,.32)":"rgba(208,188,255,.36)";};'
            .   'btn.onmouseout=function(){this.style.background=btnBg;};'
            .   'btn.onclick=function(){window.location.reload();};'
            .   'var close=document.createElement("button");'
            .   'close.textContent="✕";'
            .   'close.title="关闭";'
            .   'close.style.cssText="border:none;background:transparent;color:"+fg+";'
            .     'cursor:pointer;font-size:16px;padding:2px 4px;opacity:.6;flex-shrink:0;";'
            .   'close.onclick=function(){'
            .     't.style.opacity="0";t.style.transform="translateX(-50%) translateY(80px)";'
            .     'setTimeout(function(){t.parentNode&&t.parentNode.removeChild(t);},400);'
            .   '};'
            .   't.appendChild(txt);t.appendChild(btn);t.appendChild(close);'
            .   'document.body.appendChild(t);'
            .   'requestAnimationFrame(function(){requestAnimationFrame(function(){'
            .     't.style.opacity="1";t.style.transform="translateX(-50%) translateY(0)";'
            .   '});});'
            . '}'
            . 'if("serviceWorker"in navigator){'
            .   'navigator.serviceWorker.addEventListener("message",function(e){'
            .     'if(e.data&&e.data.type==="SW_UPDATED"){ abSwToast(); }'
            .   '});'
            .   'var refreshing=false;'
            .   'navigator.serviceWorker.addEventListener("controllerchange",function(){'
            .     'if(refreshing)return;'
            .     '/* controller 已切换，toast 由 SW_UPDATED 消息触发，此处不再重复 */'
            .   '});'
            .   'navigator.serviceWorker.register(' . json_encode($swUrl) . ',{scope:' . json_encode(rtrim((string)$options->adminUrl, '/') . '/') . '})'
            .   '.then(function(reg){'
            .     'reg.addEventListener("updatefound",function(){'
            .       'var newSW=reg.installing;'
            .       'newSW.addEventListener("statechange",function(){'
            .         'if(newSW.state==="installed"&&navigator.serviceWorker.controller){'
            .           '/* 新 SW 已安装，等待激活后由 SW_UPDATED 消息触发 toast */'
            .           '/* 若 SW 没有自动 skipWaiting，则主动通知它跳过等待 */'
            .           'newSW.postMessage({type:"SKIP_WAITING"});'
            .         '}'
            .       '});'
            .     '});'
            .   '})'
            .   '.catch(function(){});'
            . '}'
            . '}());</script>';
        $pingUrl = Typecho_Common::url('/action/admin-beautify?do=ping', $options->index);
        echo '<script>(function(){'
            . 'var isStandalone=window.matchMedia&&window.matchMedia("(display-mode:standalone)").matches||window.navigator.standalone===true;'
            . 'if(!isStandalone)return;'
            . 'function renewCookies(){'
            .   'var cookies=document.cookie.split(";");'
            .   'for(var i=0;i<cookies.length;i++){'
            .     'var c=cookies[i].trim();'
            .     'if(c.indexOf("__typecho_uid=")=== 0||c.indexOf("__typecho_authCode=")===0){'
            .       'var eqIdx=c.indexOf("=");'
            .       'var name=c.substring(0,eqIdx);'
            .       'var value=c.substring(eqIdx+1);'
            .       'var d=new Date();d.setTime(d.getTime()+30*24*60*60*1000);'
            .       'document.cookie=name+"="+value+";expires="+d.toUTCString()+";path=/;SameSite=Lax";'
            .     '}'
            .   '}'
            . '}'
            . 'renewCookies();'
            . 'setInterval(renewCookies,10*60*1000);'
            . 'setInterval(function(){fetch(' . json_encode($pingUrl) . ',{credentials:"include"}).catch(function(){});},15*60*1000);'
            . '}());</script>';
        echo '<script>(function(){';
        echo 'var __AB_VER__="2.1.63";';
        echo <<<'UPDATEJS'
// ---- abPatchKey: 把一批补丁 id 变成一个稳定的忽略 key ----
window.abPatchKey=function(pt){
    var ids=(pt&&pt.ids&&pt.ids.slice)?pt.ids.slice():[];
    ids.sort();
    var s=ids.join(",")+"|"+((pt&&pt.typecho)||"");
    var h=5381;
    for(var i=0;i<s.length;i++){ h=((h<<5)+h+s.charCodeAt(i))|0; }
    return (h>>>0).toString(36);
};
// ---- abCheckUpdate: 向后端请求最新版信息 ----
// manual=true  → ?force=1，跳过缓存直连 GitHub，等待真实结果（超时 25s）
// manual=false → 自动后台模式，stale-while-revalidate，立即返回缓存
window.abCheckUpdate=function(manual){
    var btn=document.getElementById("ab-btn-update");
    var origHTML=btn?btn.innerHTML:"";
    var ajax=window.__AB_AJAX__||{};
    if(!ajax.url) return;
    var spinSVG='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="animation:ab-spin 1s linear infinite"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>';
    if(btn){ btn.disabled=true; btn.innerHTML=spinSVG+' 检查中...'; }
    var url=ajax.url+(manual?"?do=check-update&force=1":"?do=check-update");
    var xhr=new XMLHttpRequest();
    xhr.open("GET",url,true);
    xhr.setRequestHeader("X-Requested-With","XMLHttpRequest");
    // 手动：等待 GitHub 实时响应（最多 4 节点×5s=20s，预留余量）
    // 自动：后端立即返回缓存，8s 已足够
    xhr.timeout=manual?25000:8000;
    xhr.onload=function(){
        if(btn){ btn.disabled=false; btn.innerHTML=origHTML; }
        try{
            var res=JSON.parse(xhr.responseText);
            if(res.code!==0){
                if(manual) abShowUpdateToast("error","❌ "+(res.message||"检查失败"));
                return;
            }
            var d=res.data;
            // 补丁索引过期 / 从未拉过：后台会在响应发出后去拉，10 秒后重查一次把结果取回来
            // （每次页面加载最多补查一次，避免网络一直不通时无限重试）
            if(!manual&&d.patches&&d.patches.stale&&!window.__abPatchRetry){
                window.__abPatchRetry=1;
                setTimeout(function(){ window.abCheckUpdate(false); },10000);
            }
            // ── 自动后台模式：stale-while-revalidate 处理 ──
            if(!manual && d.cache_stale){
                // 若有旧缓存数据且有更新，仍然展示（不阻止旧通知）
                if(d.has_update && d.latest){
                    try{ if(localStorage.getItem("ab-update-dismissed-v"+d.latest)) return; }catch(e){}
                    abShowUpdateAvailable(d);
                }
                // 10 秒后自动重新检查，等后台刷新完成
                setTimeout(function(){ window.abCheckUpdate(false); }, 10000);
                return;
            }
            // ── 手动模式且网络不通（force_failed）：已降级返回缓存 ──
            if(manual && d.force_failed){
                abShowUpdateToast("error","⚠️ 无法连接 GitHub，以下为缓存结果");
                // 继续往下展示缓存内容，不 return
            }
            // 写入 localStorage（手动直连的新鲜数据，或自动命中新鲜缓存）
            if(!d.cache_stale && !d.force_failed){
                try{ localStorage.setItem("ab-update-check",JSON.stringify({ts:Date.now(),data:d})); }catch(e){}
            }
            // ── 核心补丁：与插件更新并列判断（任一有内容就要提示）──
            var pt=d.patches||{};
            var pCount=parseInt(pt.count||0,10)||0;
            var pConf=parseInt(pt.conflict||0,10)||0;
            var hasPatch=!!pt.have&&(pCount>0||pConf>0);
            var patchKey="ab-patch-dismissed-"+window.abPatchKey(pt);
            if(!d.has_update&&!hasPatch){
                // 都没有：清理旧「已忽略」标记
                try{
                    var keysToRemove=[];
                    for(var k in localStorage){
                        if(k.indexOf("ab-update-dismissed-v")===0||k.indexOf("ab-patch-dismissed-")===0) keysToRemove.push(k);
                    }
                    keysToRemove.forEach(function(k){ localStorage.removeItem(k); });
                }catch(e){}
                if(manual) abShowUpdateToast("ok","✅ 已是最新版本 v"+d.current);
                return;
            }
            // 两者各自独立忽略：只忽略插件版本不能把补丁提示一起藏掉，反之亦然
            var verOff=false,patOff=false;
            try{ verOff=!!localStorage.getItem("ab-update-dismissed-v"+d.latest); }catch(e){}
            try{ patOff=!!localStorage.getItem(patchKey); }catch(e){}
            if(verOff&&(patOff||!hasPatch)) return;
            if(patOff&&!d.has_update) return;
            if(manual&&!d.has_update&&pCount>0){
                abShowUpdateToast("ok","✅ 已是最新版本 v"+d.current+"，另有 "+pCount+" 个核心补丁");
            }
            abShowUpdateAvailable(d);
        }catch(e){
            if(manual) abShowUpdateToast("error","❌ 响应解析失败");
        }
    };
    xhr.onerror=xhr.ontimeout=function(){
        if(btn){ btn.disabled=false; btn.innerHTML=origHTML; }
        if(manual) abShowUpdateToast("error","❌ 检查超时，服务器无法访问 GitHub");
    };
    xhr.send();
};
// ---- abShowUpdateAvailable: 配置页用 banner 内嵌，其他页面用固定顶栏 ----
window.abShowUpdateAvailable=function(d){
    var old=document.getElementById("ab-update-notify"); if(old) old.remove();
    var banner=document.getElementById("ab-header-banner");
    var notify=document.createElement("div");
    notify.id="ab-update-notify";
    /* 核心补丁（可能只有补丁、没有插件更新） */
    var pt=d.patches||{};
    var pCount=parseInt(pt.count||0,10)||0;
    var pConf=parseInt(pt.conflict||0,10)||0;
    var hasPatch=!!pt.have&&(pCount>0||pConf>0);
    /* 忽略：插件版本与补丁批次各自一个 key，一起写才能把这条 banner 收掉 */
    var dismissKeys=[];
    if(d.has_update) dismissKeys.push("ab-update-dismissed-v"+d.latest);
    if(hasPatch) dismissKeys.push("ab-patch-dismissed-"+window.abPatchKey(pt));
    var dismissBtn='<button type="button" onclick="(function(el){el.remove();try{(el.dataset.keys||\'\').split(\'|\').forEach(function(k){if(k)localStorage.setItem(k,\'1\')})}catch(e){}})(document.getElementById(\'ab-update-notify\'))" data-keys="'+dismissKeys.join("|")+'" data-ver="'+d.latest+'" style="background:none;border:none;cursor:pointer;font-size:16px;opacity:.7;padding:0 0 0 8px;color:inherit;line-height:1" title="忽略">✕</button>';
    // 开发版（Pre-release）标记：让用户一眼看出这条更新不是正式版
    // （服务端只在查最新版时标记，与当前选择的通道无关 —— 开发版通道下也可能收到正式版）
    var prereleaseTag = d.prerelease ? '（开发版）' : '';
    // 统一按钮基础样式：圆角描边，透明背景，继承颜色
    // box-sizing + line-height + vertical-align 三项确保 button/a/span 高度完全一致
    var btnBase='display:inline-flex;align-items:center;gap:5px;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:500;line-height:1.4;white-space:nowrap;text-decoration:none;border:1px solid currentColor;box-sizing:border-box;vertical-align:middle;';
    var actionBtns='';
    /* 核心补丁优先（修 bug / 安全问题比装新功能更要紧） */
    if(hasPatch&&pCount>0){
        actionBtns+='<button id="ab-btn-do-patch" type="button" onclick="abDoPatch()" style="'+btnBase+'background:rgba(255,255,255,.25);color:inherit;cursor:pointer;">立即修复</button>';
    } else if(hasPatch&&pConf>0){
        actionBtns+='<span style="'+btnBase+'background:rgba(255,255,255,.08);color:inherit;opacity:.7;cursor:not-allowed;" title="本地文件与补丁清单不一致，需手工处理">需手工处理</span>';
    }
    /* 插件更新相关的按钮只在确实有新版本时出现 —— 只有补丁时不显示更新/详情 */
    if(d.has_update){
        if(d.can_direct){
            actionBtns+='<button id="ab-btn-do-update" type="button" onclick="abDoUpdate()" style="'+btnBase+'background:rgba(255,255,255,.25);color:inherit;cursor:pointer;">立即更新</button>';
        } else {
            // 不支持直接更新：显示禁用态按钮 + 原因提示
            actionBtns+='<span style="'+btnBase+'background:rgba(255,255,255,.08);color:inherit;opacity:.5;cursor:not-allowed;" title="当前版本跨越了主/次版本号，需手动下载">立即更新</span>'
                       +'<span style="font-size:11px;opacity:.65;align-self:center;">需手动更新</span>';
        }
        if(d.html_url){
            actionBtns+='<a href="'+d.html_url+'" target="_blank" style="'+btnBase+'background:transparent;color:inherit;opacity:.85;color:white!important">查看详情</a>';
        }
    }
    if(banner){
        // 配置页：嵌入 banner 内
        notify.style.cssText="margin:12px 0 0;padding:12px 16px;background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.35);border-radius:14px;font-size:13px;color:#fff;animation:ab-fadeIn .3s ease;backdrop-filter:blur(4px)";
        var bodyText='';
        if(d.has_update&&d.body){ bodyText=d.body.replace(/[#*`]/g,"").replace(/\r?\n/g," ").trim(); if(bodyText.length>120) bodyText=bodyText.substring(0,120)+"..."; }
        // 核心补丁块：标题 + 逐个补丁（冲突项标注需手工处理）
        var patchHtml='';
        if(hasPatch){
            var rows='';
            var arr=(pt.list||[]);
            for(var pi=0;pi<arr.length;pi++){
                var it=arr[pi]||{};
                rows+='<div style="font-size:12px;opacity:.85;margin-top:4px;line-height:1.5">• '
                    +String(it.title||'')
                    +(it.status==='conflict'?'　⚠️ 需手工处理':'')
                    +'</div>';
            }
            patchHtml='<div style="margin-bottom:10px">'
                +'<div style="font-size:12px;font-weight:600;opacity:.92">Typecho 核心补丁'
                +(pCount>0?'（'+pCount+' 个可安装）':'')
                +(pConf>0?'　'+pConf+' 个冲突':'')
                +'</div>'+rows+'</div>';
        }
        notify.innerHTML='<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px">'
            +'<div style="flex:1">'
            +(d.has_update?'<div style="font-weight:600;margin-bottom:'+(bodyText?'6px':'0')+'">🎉 发现新版本 <strong>v'+d.latest+'</strong>'+prereleaseTag+' <span style="font-size:11px;opacity:.7;font-weight:400">（当前 v'+d.current+'）</span></div>':'')
            +patchHtml
            +(bodyText?'<div style="font-size:12px;opacity:.8;margin-bottom:10px;line-height:1.5">'+bodyText+'</div>':'')
            +'<div style="display:flex;gap:8px;flex-wrap:wrap">'+actionBtns+'</div></div>'
            +dismissBtn+'</div>';
        banner.appendChild(notify);
    } else {
        // 其他后台页面：不再插顶部横条 —— 「发现新版本」已由通知中心展示
        // （服务端 do=check-update 会写一条通知）。这里只把铃铛未读数刷一下。
        if(window.AdminBeautify&&AdminBeautify.noticeCenter){
            try{ AdminBeautify.noticeCenter.refresh(); }catch(e){}
        }
        return;
    }
    if(d.can_direct){
        notify.setAttribute("data-download-url",d.download_url||"");
        notify.setAttribute("data-new-version",d.latest);
    }
    if(hasPatch){
        notify.setAttribute("data-patch-count",String(pCount));
        notify.setAttribute("data-patch-ids",(pt.ids||[]).join(","));
    }
};
// ---- abAskConfirm: AB Admin 劫持了 window.confirm（返回 Promise<boolean>），这里统一成 Promise 用法 ----
// 注意：绝不能用 `if(!window.confirm(msg)) return;` —— 被劫持后返回值是 Promise，恒为真/或为 undefined，
// 会导致「点了确定没反应」。
window.abAskConfirm=function(msg){
    var ab=window.AdminBeautify;
    if(ab&&typeof ab.confirm==="function"){
        try{
            var p=ab.confirm(msg);
            if(p&&typeof p.then==="function") return p.then(function(v){ return v!==false; });
            return Promise.resolve(p!==false);
        }catch(e){}
    }
    var r=null;
    try{ r=window.confirm(msg); }catch(e){}
    if(r&&typeof r.then==="function") return r.then(function(v){ return v!==false; });
    return Promise.resolve(!!r);
};
// ---- 补丁进度遮罩（自带样式，可反复开关）----
window.abPatchOverlay=function(show){
    var el=document.getElementById("ab-patch-overlay");
    if(show===false){ if(el) el.remove(); return null; }
    if(!document.getElementById("ab-patch-ovl-style")){
        var st=document.createElement("style");
        st.id="ab-patch-ovl-style";
        st.textContent=[
            "#ab-patch-overlay{position:fixed;inset:0;z-index:999999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.55);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);padding:16px;box-sizing:border-box}",
            "#ab-patch-card{width:100%;max-width:420px;background:var(--md-surface,#fff);color:var(--md-on-surface,#1c1b1f);border-radius:28px;padding:32px 28px 28px;box-shadow:0 8px 40px rgba(0,0,0,.28);box-sizing:border-box}",
            "[data-theme=dark] #ab-patch-card{background:var(--md-dark-surface,#1c1b1f);color:var(--md-dark-on-surface,#e6e1e5);box-shadow:0 8px 40px rgba(0,0,0,.55)}",
            "#ab-patch-card .abp-icon{font-size:36px;text-align:center;margin-bottom:16px}",
            "#ab-patch-card .abp-title{font-size:18px;font-weight:700;text-align:center;margin-bottom:6px}",
            "#ab-patch-card .abp-sub{font-size:13px;text-align:center;color:var(--md-on-surface-variant,#49454f);margin-bottom:24px}",
            "[data-theme=dark] #ab-patch-card .abp-sub{color:var(--md-dark-on-surface-variant,#cac4d0)}",
            "#abp-bar-track{height:6px;border-radius:3px;overflow:hidden;background:var(--md-surface-variant,#e7e0ec);margin-bottom:10px}",
            "[data-theme=dark] #abp-bar-track{background:var(--md-dark-surface-variant,#49454f)}",
            "#abp-bar-fill{height:100%;border-radius:3px;background:var(--md-primary,#6750a4);width:0%;transition:width .35s cubic-bezier(.4,0,.2,1)}",
            "#abp-pct{font-size:12px;text-align:right;color:var(--md-on-surface-variant,#49454f);margin-bottom:4px;min-height:16px}",
            "#abp-msg{font-size:13px;text-align:center;min-height:20px;color:var(--md-on-surface-variant,#49454f);word-break:break-word}",
            "[data-theme=dark] #abp-pct,[data-theme=dark] #abp-msg{color:var(--md-dark-on-surface-variant,#cac4d0)}",
            "#ab-patch-btns{display:none;gap:10px;justify-content:center;margin-top:20px;flex-wrap:wrap}",
            ".abp-btn{display:inline-flex;align-items:center;justify-content:center;padding:10px 20px;border-radius:20px;font-size:13px;font-weight:500;border:none;cursor:pointer;gap:6px}",
            ".abp-btn-primary{background:var(--md-primary,#6750a4);color:#fff}",
            ".abp-btn-secondary{background:var(--md-surface-variant,#e7e0ec);color:var(--md-on-surface,#1c1b1f)}",
            "[data-theme=dark] .abp-btn-secondary{background:var(--md-dark-surface-variant,#49454f);color:var(--md-dark-on-surface,#e6e1e5)}"
        ].join("");
        document.head.appendChild(st);
    }
    if(el) return el;
    el=document.createElement("div");
    el.id="ab-patch-overlay";
    el.innerHTML='<div id="ab-patch-card">'
        +'<div class="abp-icon">🛡️</div>'
        +'<div class="abp-title">正在应用核心补丁</div>'
        +'<div class="abp-sub">请勿关闭或刷新页面</div>'
        +'<div id="abp-pct"></div>'
        +'<div id="abp-bar-track"><div id="abp-bar-fill"></div></div>'
        +'<div id="abp-msg">准备中…</div>'
        +'<div id="ab-patch-btns"></div>'
        +'</div>';
    document.body.appendChild(el);
    return el;
};
window.abPatchSet=function(pct,msg){
    var f=document.getElementById("abp-bar-fill");
    var p=document.getElementById("abp-pct");
    var m=document.getElementById("abp-msg");
    if(m&&msg!==undefined&&msg!==null) m.textContent=msg;
    if(f&&pct>=0){
        f.style.animation="";
        f.style.width=Math.min(100,pct)+"%";
        if(p) p.textContent=Math.min(100,pct)+"%";
    }
};
window.abPatchFinish=function(okFlag,text,detail,titleText){
    var card=document.getElementById("ab-patch-card");
    if(!card) return;
    var icon=card.querySelector(".abp-icon"),
        title=card.querySelector(".abp-title"),
        sub=card.querySelector(".abp-sub");
    if(icon) icon.textContent=okFlag?"✅":"❌";
    if(title) title.textContent=titleText||(okFlag?"补丁已应用":"补丁未应用");
    if(sub) sub.textContent=text||"";
    var f=document.getElementById("abp-bar-fill");
    if(f){ f.style.width="100%"; if(!okFlag) f.style.background="#dc2626"; }
    var m=document.getElementById("abp-msg");
    if(m) m.textContent=detail||"";
    var box=document.getElementById("ab-patch-btns");
    if(box){
        box.style.display="flex";
        box.innerHTML='<button class="abp-btn abp-btn-primary" type="button" id="abp-close">'+(okFlag?"完成":"关闭")+'</button>';
        var c=document.getElementById("abp-close");
        if(c) c.onclick=function(){ window.abPatchOverlay(false); };
    }
    // 广播结果：设置页「补丁」卡片 / 其他面板可以据此刷新
    try{
        document.dispatchEvent(new CustomEvent("ab:patchdone",{detail:{ok:!!okFlag,message:text||""}}));
    }catch(e){}
};
// ---- abPatchRollback: 回滚单个补丁（设置页「补丁」卡片用）----
window.abPatchRollback=function(id){
    var ajax=window.__AB_AJAX__||{};
    if(!ajax.url||!id) return;
    window.abAskConfirm("确定回滚补丁「"+id+"」？\n会把对应核心文件还原到打补丁前的版本。").then(function(ok){
        if(!ok) return;
        window.abPatchOverlay(true);
        window.abPatchSet(5,"回滚中…");
        var sep=ajax.url.indexOf('?')>=0?'&':'?';
        var xhr=new XMLHttpRequest();
        xhr.open("POST",ajax.url+sep+"do=patch-rollback&id="+encodeURIComponent(id)
            +"&_="+encodeURIComponent(ajax.token||""),true);
        xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
        xhr.setRequestHeader("X-Requested-With","XMLHttpRequest");
        xhr.timeout=60000;
        xhr.onload=function(){
            var j=null; try{ j=JSON.parse(xhr.responseText); }catch(e){}
            window.abPatchSet(100,"完成");
            if(j&&j.code===0) window.abPatchFinish(true,(j.message||"已回滚"),"","已回滚");
            else window.abPatchFinish(false,(j&&j.message)||"回滚失败","","回滚失败");
        };
        xhr.onerror=xhr.ontimeout=function(){ window.abPatchFinish(false,"请求失败","请检查网络后重试","回滚失败"); };
        xhr.send("id="+encodeURIComponent(id));
    });
};
// ---- abDoPatch: 一键应用 Typecho 核心补丁（banner 与通知中心共用）----
window.abDoPatch=function(id){
    var ajax=window.__AB_AJAX__||{};
    if(!ajax.url) return;
    id=id||"all";
    // 从缓存里取本次要改哪些文件，用于二次确认
    var files=[];
    try{
        var c=JSON.parse(localStorage.getItem("ab-update-check")||"null");
        var pt=(c&&c.data&&c.data.patches)||{};
        var list=pt.list||[];
        for(var i=0;i<list.length;i++){
            if(list[i].status!=="pending") continue;
            var fs=list[i].files||[];
            for(var j=0;j<fs.length;j++) files.push(fs[j]);
        }
    }catch(e){}
    var msg="将修改 Typecho 核心文件：\n"
        +(files.length?("· "+files.join("\n· ")):"（清单未缓存，仍继续？）")
        +"\n\n会先自动备份，可直接回滚。继续？";
    window.abAskConfirm(msg).then(function(ok){
        if(!ok) return;
        abPatchRun(id);
    });
};
// ---- abPatchRun: 真正执行（SSE 流式读进度）----
window.abPatchRun=function(id){
    var ajax=window.__AB_AJAX__||{};
    if(!ajax.url) return;
    window.abPatchOverlay(true);
    window.abPatchSet(0,"准备中…");
    var sep=ajax.url.indexOf('?')>=0?'&':'?';
    function endpoint(act){
        return ajax.url+sep+"do="+act+"&id="+encodeURIComponent(id||"all")
            +"&_="+encodeURIComponent(ajax.token||"");
    }
    function finish(okFlag,text,detail){
        window.abPatchFinish(okFlag,text,detail);
        if(okFlag){
            try{ localStorage.removeItem("ab-update-check"); }catch(e){}
            try{
                if(window.AdminBeautify&&AdminBeautify.noticeCenter) AdminBeautify.noticeCenter.refresh();
            }catch(e){}
            var old=document.getElementById("ab-update-notify"); if(old) old.remove();
            setTimeout(function(){ window.abCheckUpdate(true); },800);
        }
    }
    // 老浏览器（无 ReadableStream）：退回一次性 JSON 接口，只显示「不确定进度」
    var useStream=!!(window.fetch&&window.ReadableStream&&window.TextDecoder);
    if(!useStream){
        var xhr=new XMLHttpRequest();
        xhr.open("POST",endpoint("patch-apply"),true);
        xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
        xhr.setRequestHeader("X-Requested-With","XMLHttpRequest");
        xhr.timeout=120000;
        xhr.onload=function(){
            var j=null; try{ j=JSON.parse(xhr.responseText); }catch(e){}
            if(j&&j.code===0) finish(true,(j.message||"补丁已应用"),"");
            else finish(false,(j&&j.message)||"应用失败","");
        };
        xhr.onerror=xhr.ontimeout=function(){ finish(false,"请求失败","请检查网络后重试"); };
        xhr.send("id="+encodeURIComponent(id||"all"));
        return;
    }
    fetch(endpoint("patch-apply-stream"),{
        method:"POST",
        credentials:"same-origin",
        headers:{"Content-Type":"application/x-www-form-urlencoded"}
    }).then(function(resp){
        if(!resp.ok||!resp.body){
            finish(false,"服务器返回 HTTP "+resp.status,"如果刚升级过插件，请确认 Patch.php 已上传");
            return;
        }
        var ct=resp.headers.get("content-type")||"";
        if(ct.indexOf("text/event-stream")<0){
            return resp.text().then(function(t){
                var plain=t?t.replace(/<[^>]+>/g,"").trim().substring(0,180):"";
                finish(false,"响应格式异常（"+ct+"）",plain);
            });
        }
        var reader=resp.body.getReader(), dec=new TextDecoder(), buf="", last=null;
        function pump(){
            return reader.read().then(function(r){
                if(r.done){
                    if(!last) finish(false,"连接中断","未收到结果，请刷新页面确认核心文件状态");
                    return;
                }
                buf+=dec.decode(r.value,{stream:true});
                var parts=buf.split("\n\n");
                buf=parts.pop();
                for(var i=0;i<parts.length;i++){
                    var m=parts[i].match(/^data:\s*(.+)$/m);
                    if(!m) continue;
                    var ev=null; try{ ev=JSON.parse(m[1]); }catch(e){}
                    if(!ev) continue;
                    last=ev;
                    if(ev.type==="progress") window.abPatchSet(parseInt(ev.progress,10)||0,ev.message||"");
                    else if(ev.type==="done") finish(true,ev.message||"补丁已应用","");
                    else if(ev.type==="error") finish(false,ev.message||"应用失败","");
                }
                return pump();
            });
        }
        return pump();
    }).catch(function(){
        finish(false,"请求失败","请检查网络后重试");
    });
};
// ---- abDoUpdate: 执行直接更新（fetch 流式版，全屏进度遮罩）----
window.abDoUpdate=function(){
    var notify=document.getElementById("ab-update-notify");
    if(!notify) return;
    window.abDoUpdateFrom(notify.getAttribute("data-download-url"), notify.getAttribute("data-new-version"));
};
// ---- abDoUpdateFrom: 真正执行更新（通知中心里的「立即更新」也调它，保证行为一致）----
window.abDoUpdateFrom=function(dlUrl,newVer){
    if(!dlUrl||!newVer){ window.open("https://github.com/lhl77/Typecho-Plugin-AdminBeautify/releases","_blank"); return; }
    var ajax=window.__AB_AJAX__||{};
    if(!ajax.url) return;
    // ---- 注入全屏进度遮罩 ----
    var oldOvl=document.getElementById("ab-update-overlay");
    if(oldOvl) oldOvl.remove();
    // 注入遮罩样式（幂等）
    if(!document.getElementById("ab-update-overlay-style")){
        var st=document.createElement("style");
        st.id="ab-update-overlay-style";
        st.textContent=[
            "#ab-update-overlay{",
            "  position:fixed;inset:0;z-index:999999;",
            "  display:flex;align-items:center;justify-content:center;",
            "  background:rgba(0,0,0,.55);backdrop-filter:blur(6px);",
            "  -webkit-backdrop-filter:blur(6px);",
            "  animation:ab-ovl-in .25s ease;",
            "  padding:16px;box-sizing:border-box;",
            "}",
            "@keyframes ab-ovl-in{from{opacity:0}to{opacity:1}}",
            "#ab-update-card{",
            "  width:100%;max-width:420px;",
            "  background:var(--md-surface,#fff);",
            "  color:var(--md-on-surface,#1c1b1f);",
            "  border-radius:28px;",
            "  padding:32px 28px 28px;",
            "  box-shadow:0 8px 40px rgba(0,0,0,.28);",
            "  box-sizing:border-box;",
            "  animation:ab-card-in .3s cubic-bezier(.4,0,.2,1);",
            "}",
            "[data-theme=dark] #ab-update-card{",
            "  background:var(--md-dark-surface,#1c1b1f);",
            "  color:var(--md-dark-on-surface,#e6e1e5);",
            "  box-shadow:0 8px 40px rgba(0,0,0,.55);",
            "}",
            "@keyframes ab-card-in{from{transform:translateY(24px);opacity:0}to{transform:translateY(0);opacity:1}}",
            "#ab-update-card .ab-ovl-icon{font-size:36px;text-align:center;margin-bottom:16px;}",
            "#ab-update-card .ab-ovl-title{",
            "  font-size:18px;font-weight:700;text-align:center;",
            "  margin-bottom:6px;",
            "  color:var(--md-on-surface,#1c1b1f);",
            "}",
            "[data-theme=dark] #ab-update-card .ab-ovl-title{color:var(--md-dark-on-surface,#e6e1e5);}",
            "#ab-update-card .ab-ovl-sub{",
            "  font-size:13px;text-align:center;",
            "  color:var(--md-on-surface-variant,#49454f);",
            "  margin-bottom:24px;",
            "}",
            "[data-theme=dark] #ab-update-card .ab-ovl-sub{color:var(--md-dark-on-surface-variant,#cac4d0);}",
            "#ab-ovl-bar-track{",
            "  height:6px;border-radius:3px;overflow:hidden;",
            "  background:var(--md-surface-variant,#e7e0ec);",
            "  margin-bottom:10px;",
            "}",
            "[data-theme=dark] #ab-ovl-bar-track{background:var(--md-dark-surface-variant,#49454f);}",
            "#ab-ovl-bar-fill{",
            "  height:100%;border-radius:3px;",
            "  background:var(--md-primary,#6750a4);",
            "  transition:width .45s cubic-bezier(.4,0,.2,1);",
            "  width:0%;",
            "}",
            "#ab-ovl-msg{",
            "  font-size:13px;text-align:center;min-height:20px;",
            "  color:var(--md-on-surface-variant,#49454f);",
            "}",
            "[data-theme=dark] #ab-ovl-msg{color:var(--md-dark-on-surface-variant,#cac4d0);}",
            "#ab-ovl-pct{",
            "  font-size:12px;text-align:right;",
            "  color:var(--md-on-surface-variant,#49454f);",
            "  margin-bottom:4px;min-height:16px;",
            "}",
            "[data-theme=dark] #ab-ovl-pct{color:var(--md-dark-on-surface-variant,#cac4d0);}",
            "@keyframes ab-bar-pulse{0%,100%{opacity:.5}50%{opacity:1}}",
            /* ---- 按钮样式（含暗色适配）---- */
            ".ab-ovl-btn-primary{",
            "  display:inline-flex;align-items:center;justify-content:center;",
            "  padding:10px 20px;border-radius:20px;",
            "  background:var(--md-primary,#6750a4);color:#fff;",
            "  font-size:13px;font-weight:500;border:none;cursor:pointer;",
            "  text-decoration:none;gap:6px;",
            "}",
            ".ab-ovl-btn-secondary{",
            "  display:inline-flex;align-items:center;justify-content:center;",
            "  padding:10px 20px;border-radius:20px;",
            "  background:var(--md-surface-variant,#e7e0ec);",
            "  color:var(--md-on-surface,#1c1b1f);",
            "  font-size:13px;font-weight:500;border:none;cursor:pointer;gap:6px;",
            "  text-decoration:none;",
            "}",
            "[data-theme=dark] .ab-ovl-btn-secondary{",
            "  background:var(--md-dark-surface-variant,#49454f);",
            "  color:var(--md-dark-on-surface,#e6e1e5);",
            "}",
            "@media(max-width:480px){",
            "  #ab-update-card{padding:24px 18px 20px;border-radius:20px;}",
            "  #ab-update-card .ab-ovl-title{font-size:16px;}",
            "  .ab-ovl-btn-primary,.ab-ovl-btn-secondary{padding:9px 16px;font-size:12px;}",
            "}"
        ].join("");
        document.head.appendChild(st);
    }
    var overlay=document.createElement("div");
    overlay.id="ab-update-overlay";
    overlay.innerHTML=[
        '<div id="ab-update-card">',
        '  <div class="ab-ovl-icon">☁️</div>',
        '  <div class="ab-ovl-title">正在更新到 v'+newVer+'</div>',
        '  <div class="ab-ovl-sub">请勿关闭或刷新页面</div>',
        '  <div id="ab-ovl-pct"></div>',
        '  <div id="ab-ovl-bar-track"><div id="ab-ovl-bar-fill"></div></div>',
        '  <div id="ab-ovl-msg">连接服务器...</div>',
        '</div>'
    ].join("");
    document.body.appendChild(overlay);
    // 屏蔽键盘退出（ESC / 返回键）和页面关闭提示
    function onBeforeUnload(e){ e.preventDefault(); e.returnValue=''; }
    window.addEventListener("beforeunload", onBeforeUnload);
    document.addEventListener("keydown", function onKey(e){
        if(e.key==="Escape"){ e.stopPropagation(); e.preventDefault(); }
    }, true);
    var barFill=document.getElementById("ab-ovl-bar-fill");
    var barMsg =document.getElementById("ab-ovl-msg");
    var barPct =document.getElementById("ab-ovl-pct");
    var card   =document.getElementById("ab-update-card");
    var lastType="";
    function setProgress(pct, msg){
        if(barMsg) barMsg.textContent=msg||"";
        if(pct>=0){
            if(barFill){
                barFill.style.animation="";
                barFill.style.width=Math.min(100,pct)+"%";
            }
            if(barPct) barPct.textContent=Math.min(100,pct)+"%";
        } else {
            if(barFill){
                barFill.style.animation="ab-bar-pulse 1.2s ease infinite";
                barFill.style.width="35%";
            }
            if(barPct) barPct.textContent="";
        }
    }
    function showBtns(html){
        if(!card) return;
        var w=document.createElement("div");
        w.style.cssText="display:flex;gap:10px;justify-content:center;margin-top:20px;flex-wrap:wrap;";
        w.innerHTML=html;
        card.appendChild(w);
    }
    // 成功处理
    function onDone(){
        window.removeEventListener("beforeunload", onBeforeUnload);
        if(barFill){ barFill.style.animation=""; barFill.style.width="100%"; }
        if(barPct) barPct.textContent="100%";
        setTimeout(function(){
            if(card){
                card.querySelector(".ab-ovl-icon").textContent="✅";
                card.querySelector(".ab-ovl-title").textContent="更新成功！";
                card.querySelector(".ab-ovl-sub").textContent="即将自动刷新页面...";
            }
            try{ localStorage.removeItem("ab-update-check"); }catch(e){}
            try{
                if(navigator.serviceWorker&&navigator.serviceWorker.controller){
                    navigator.serviceWorker.controller.postMessage({type:"CLEAR_CACHE"});
                }
                if(navigator.serviceWorker&&navigator.serviceWorker.getRegistration){
                    navigator.serviceWorker.getRegistration().then(function(r){if(r)r.update();}).catch(function(){});
                }
            }catch(e){}
            setTimeout(function(){ location.reload(); },2500);
        },600);
    }
    // 失败处理
    function onError(msg){
        window.removeEventListener("beforeunload", onBeforeUnload);
        if(card){
            card.querySelector(".ab-ovl-icon").textContent="❌";
            card.querySelector(".ab-ovl-title").style.color="#dc2626";
            card.querySelector(".ab-ovl-title").textContent="更新失败";
            card.querySelector(".ab-ovl-sub").textContent=msg||"请前往 GitHub 手动下载";
            if(barFill) barFill.style.background="#dc2626";
        }
        showBtns(
            '<a href="https://github.com/lhl77/Typecho-Plugin-AdminBeautify/releases"'+
            ' target="_blank" class="ab-ovl-btn-primary">前往 GitHub 下载</a>'+
            '<button class="ab-ovl-btn-secondary"'+
            ' onclick="document.getElementById(\'ab-update-overlay\').remove()">关闭</button>'
        );
    }
    // 连接中断处理
    function onInterrupt(){
        window.removeEventListener("beforeunload", onBeforeUnload);
        if(card){
            card.querySelector(".ab-ovl-icon").textContent="⚠️";
            card.querySelector(".ab-ovl-title").textContent="连接中断";
            card.querySelector(".ab-ovl-sub").textContent="更新状态未知，请手动检查后台文件是否已更新";
        }
        showBtns(
            '<button class="ab-ovl-btn-primary" onclick="location.reload()">刷新页面</button>'+
            '<button class="ab-ovl-btn-secondary"'+
            ' onclick="document.getElementById(\'ab-update-overlay\').remove()">关闭</button>'
        );
    }
    // 处理单个 SSE 事件
    function handleEvent(ev){
        var type=ev.type, msg=ev.message, pct=ev.progress;
        lastType=type;
        setProgress(pct, msg);
        if(type==="done") onDone();
        else if(type==="error") onError(msg);
    }
    // ---- 构造 SSE URL ----
    var sep=ajax.url.indexOf('?')>=0?'&':'?';
    var sseUrl=ajax.url+sep+"do=do-update-stream"
        +"&download_url="+encodeURIComponent(dlUrl)
        +"&new_version="+encodeURIComponent(newVer)
        +"&_="+encodeURIComponent(ajax.token||"");
    // ---- 校验 URL 协议，防止配置被篡改后注入 javascript: 等非法协议 ----
    if(!/^(https?:)?\/\//i.test(sseUrl)&&sseUrl.charAt(0)!=="/"){
        onError("非法的请求地址");
        return;
    }
    // ---- 优先使用 fetch + ReadableStream（兼容性更好，可读取错误内容）----
    // 不支持时降级到非流式 AJAX（do-update）
    var useStream=!!(window.fetch&&window.ReadableStream&&window.TextDecoder);
    if(useStream){
        fetch(sseUrl,{credentials:"same-origin",headers:{Accept:"text/event-stream"}})
        .then(function(resp){
            if(!resp.ok){
                return resp.text().then(function(t){
                    var detail=t?t.replace(/<[^>]+>/g,"").trim().substring(0,200):"";
                    onError("服务器返回 HTTP "+resp.status+(detail?"\n"+detail:""));
                });
            }
            var ct=resp.headers.get("content-type")||"";
            if(ct.indexOf("text/event-stream")<0){
                return resp.text().then(function(t){
                    var detail=t?t.replace(/<[^>]+>/g,"").trim().substring(0,200):"";
                    onError("响应格式异常（"+ct+"）"+(detail?"\n"+detail:""));
                });
            }
            // 流式读取 SSE 帧
            var reader=resp.body.getReader();
            var dec=new TextDecoder();
            var buf="";
            function readChunk(){
                return reader.read().then(function(r){
                    if(r.done){
                        if(lastType!=="done"&&lastType!=="error") onInterrupt();
                        return;
                    }
                    buf+=dec.decode(r.value,{stream:true});
                    var parts=buf.split("\n\n");
                    buf=parts.pop();
                    for(var i=0;i<parts.length;i++){
                        var m=parts[i].match(/^data:\s*(.+)$/m);
                        if(m){ try{ handleEvent(JSON.parse(m[1])); }catch(ex){} }
                    }
                    return readChunk();
                });
            }
            return readChunk();
        })
        .catch(function(err){
            if(lastType!=="done"&&lastType!=="error") onInterrupt();
        });
    } else {
        // 降级：非流式单次 AJAX（无实时进度，仅 loading 动画）
        setProgress(-1,"正在更新，请稍候...");
        var fd=new URLSearchParams();
        fd.append("do","do-update");
        fd.append("download_url",dlUrl);
        fd.append("new_version",newVer);
        fd.append("_",ajax.token||"");
        fetch(ajax.url,{method:"POST",body:fd,credentials:"same-origin"})
        .then(function(r){ return r.json(); })
        .then(function(d){
            if(d&&d.code===0) handleEvent({type:"done",message:"更新成功",progress:100});
            else onError((d&&d.message)||"更新失败");
        })
        .catch(function(){ onInterrupt(); });
    }
};
// ---- abShowUpdateToast: 轻量级提示（主要用于配置页手动检查反馈）----
window.abShowUpdateToast=function(type,msg){
    var old=document.getElementById("ab-update-notify"); if(old) old.remove();
    var colors={ok:"#059669",update:"#d97706",error:"#dc2626",info:"#6366f1"};
    var toast=document.createElement("div");
    toast.id="ab-update-notify";
    var banner=document.getElementById("ab-header-banner");
    if(banner){
        toast.style.cssText="margin:12px 0 0;padding:9px 14px;background:#fff;border:1px solid "+(colors[type]||"#6366f1")+";border-radius:12px;font-size:13px;color:"+(colors[type]||"#6366f1")+";display:flex;align-items:center;gap:8px;animation:ab-fadeIn .3s ease;font-weight:500;box-shadow:0 2px 8px rgba(0,0,0,.1)";
        toast.innerHTML="<span>"+msg+"</span>";
        banner.appendChild(toast);
    } else {
        // 非设置页：不再插顶部横条（插件仓库更新等改由通知中心展示）
        return;
    }
    setTimeout(function(){ if(toast.parentNode) toast.remove(); },6000);
};
// ---- 注入动画样式（如未注入）----
if(!document.getElementById("ab-update-anim")){
    var st=document.createElement("style");
    st.id="ab-update-anim";
    st.textContent="@keyframes ab-spin{to{transform:rotate(360deg)}}@keyframes ab-slideDown{from{transform:translateY(-100%);opacity:0}to{transform:translateY(0);opacity:1}}";
    document.head.appendChild(st);
}
// ---- abVerCompare: 返回 1(a>b) / -1(a<b) / 0(a===b) ----
function abVerCompare(a,b){
    var pa=(a||"").replace(/^v/i,"").split(".").map(Number);
    var pb=(b||"").replace(/^v/i,"").split(".").map(Number);
    for(var i=0;i<Math.max(pa.length,pb.length);i++){
        var na=pa[i]||0, nb=pb[i]||0;
        if(na>nb) return 1;
        if(na<nb) return -1;
    }
    return 0;
}
// ---- 自动检查（每小时一次，页面加载后 4 秒执行）----
setTimeout(function(){
    try{
        var cached=JSON.parse(localStorage.getItem("ab-update-check")||"null");
        var ONE_HOUR=3600000;
        // 若缓存中记录的"最新版"不高于当前运行版本，说明已更新完成但缓存未清除，直接丢弃
        if(cached&&cached.data&&cached.data.latest&&abVerCompare(cached.data.latest,__AB_VER__)<=0){
            try{ localStorage.removeItem("ab-update-check"); }catch(e){}
            cached=null;
        }
        if(!cached||(Date.now()-cached.ts)>ONE_HOUR){
            // 缓存已过期或不存在，发起网络请求
            window.abCheckUpdate(false);
        } else if(cached.data&&cached.data.has_update){
            // 缓存中有更新信息，检查是否已忽略
            var dismissed=localStorage.getItem("ab-update-dismissed-v"+cached.data.latest);
            if(!dismissed) window.abShowUpdateAvailable(cached.data);
        }
    }catch(e){}
},4000);
UPDATEJS;
        echo '})();</script>';
        echo '<script>(function(){'
            . '"use strict";'
            . 'function abIsMobile(){return window.innerWidth<=575;}'
            . 'document.addEventListener("click",function(e){'
            .   'if(!abIsMobile())return;'
            .   'var mb=document.querySelector(".typecho-head-nav .menu-bar[open]");'
            .   'if(!mb)return;'
            .   'var dr=document.querySelector(".typecho-head-nav nav > menu");'
            .   'if(mb.contains(e.target))return;'
            .   'if(dr&&dr.contains(e.target))return;'
            .   'mb.removeAttribute("open");'
            . '},true);'
            . 'function abInitMobileNav(){'
            .   'if(!abIsMobile())return;'
            .   'var drawerMenu=document.querySelector(".typecho-head-nav nav > menu");'
            .   'if(drawerMenu&&!document.getElementById("ab-mobile-branding")){'
            .     'var user=window.__AB_USER__||{};'
            .     'var cfg=window.__AB_CONFIG__||{};'
            .     'var siteName=cfg.siteName||"";'
            .     'var avatarUrl=user.avatar||"";'
            .     'var bd=document.createElement("div");'
            .     'bd.id="ab-mobile-branding";'
            .     'var bhtml="";'
            .     'if(avatarUrl)bhtml+="<img src=\""+avatarUrl+"\" alt=\"\" style=\"width:36px;height:36px;border-radius:50%;object-fit:cover;flex-shrink:0\">";'
            .     'if(siteName)bhtml+="<span style=\"font-size:15px;font-weight:600;color:var(--md-on-surface);white-space:nowrap;overflow:hidden;text-overflow:ellipsis\">"+siteName+"</span>";'
            .     'bd.innerHTML=bhtml;'
            .     'drawerMenu.insertBefore(bd,drawerMenu.firstChild);'
            .   '}'
            .   'var items=document.querySelectorAll(".typecho-head-nav nav > menu > li");'
            .   '[].forEach.call(items,function(li){'
            .     'var sub=li.querySelector("menu");'
            .     'if(!sub)return;'
            .     '/* 标记父级菜单项：避免被 AJAX 导航捕获拦截 */'
            .     'li.classList.add("ab-has-children");'
            .     'if(li.classList.contains("focus"))li.classList.add("ab-expanded");'
            .   '});'
            . '}'
            . 'if(document.readyState==="loading"){'
            .   'document.addEventListener("DOMContentLoaded",abInitMobileNav);'
            . '}else{abInitMobileNav();}'
            . 'var abResizeTimer;'
            . 'window.addEventListener("resize",function(){'
            .   'clearTimeout(abResizeTimer);'
            .   'abResizeTimer=setTimeout(function(){'
            .     'var bd=document.getElementById("ab-mobile-branding");'
            .     'if(!abIsMobile()&&bd){'
            .       'bd.parentNode&&bd.parentNode.removeChild(bd);'
            .     '} else if(abIsMobile()&&!document.getElementById("ab-mobile-branding")){'
            .       'abInitMobileNav();'
            .     '}'
            .   '},100);'
            . '});'
            . '}());</script>';
        $typechoVer = isset($options->version) ? (string) $options->version : '';
        if ($typechoVer && version_compare($typechoVer, '1.3.0', '<')) {
            $noteMsg = '检测到 Typecho 版本：v' . htmlspecialchars($typechoVer) . '，建议升级到 v1.3.0 以获得最佳兼容性。';
            if (version_compare($typechoVer, '1.2.1', '==')) {
                $noteMsg .= ' 如果暂时无法升级，请在 AB-Admin 插件设置中手动启用 Typecho 1.2.1 兼容脚本。';
            }
            echo '<script>(function(){try{var b=document.createElement("div");b.id="ab-typecho-version-note";b.style.cssText="position:fixed;top:0;left:0;right:0;z-index:99998;padding:10px 14px;background:#fef3c7;color:#92400e;font-size:13px;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 12px rgba(0,0,0,.06);";b.innerHTML=' . json_encode($noteMsg) . ';document.body.insertBefore(b,document.body.firstChild);document.body.style.paddingTop=(parseInt(document.body.style.paddingTop||0)+48)+"px";setTimeout(function(){b.style.transform="translateY(0)";},10);}catch(e){} })();</script>';
        }
        if (!(self::storeBoot() && class_exists('AdminBeautify_Store') && AdminBeautify_Store::enabled())) {
        $absDir = rtrim(dirname(__FILE__), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'AdminBeautifyStore';
        $absInstalled = is_dir($absDir);
        $absActivated = false;
        if ($absInstalled) {
            try {
                $options->plugin('AdminBeautifyStore');
                $absActivated = true;
            } catch (Exception $e) {
                $absActivated = false;
            }
        }
        if (!$absInstalled) {
            $absStoreUrl  = '';
            $absBtnText   = '安装AB插件仓库';
            $absTarget    = '';
            $absWarnText  = '';
            $absWarnUrl   = '';
            $absAction    = 'install';
        } elseif (!$absActivated) {
            $absStoreUrl  = $options->adminUrl . 'plugins.php';
            $absBtnText   = 'AB插件仓库';
            $absTarget    = '_self';
            $absWarnText  = '插件未启用，请先启用 AB-Store';
            $absWarnUrl   = $options->adminUrl . 'plugins.php';
            $absAction    = 'go';
        } else {
            $absStoreUrl  = $options->adminUrl . 'extending.php?panel=' . urlencode('AdminBeautifyStore/Panel.php');
            $absBtnText   = 'AB插件仓库';
            $absTarget    = '_self';
            $absWarnText  = '';
            $absWarnUrl   = '';
            $absAction    = 'go';
        }
        echo '<script>(function(){'
            . 'var BTN_ID="ab-store-shortcut-btn";'
            . 'var WARN_ID="ab-store-shortcut-warn";'
            . 'var BTN_URL=' . json_encode($absStoreUrl) . ';'
            . 'var BTN_TEXT=' . json_encode($absBtnText) . ';'
            . 'var BTN_TARGET=' . json_encode($absTarget) . ';'
            . 'var WARN_TEXT=' . json_encode($absWarnText) . ';'
            . 'var BTN_ACTION=' . json_encode($absAction) . ';'
            . 'function abInjectStoreBtn(){'
            .   'if(document.getElementById(BTN_ID)) return;'
            .   'var titleArea=document.querySelector(".typecho-page-title");'
            .   'if(!titleArea) return;'
            .   'titleArea.style.display="flex";'
            .   'titleArea.style.alignItems="center";'
            .   'titleArea.style.flexWrap="wrap";'
            .   'titleArea.style.gap="8px";'
            .   'var h2=titleArea.querySelector("h2,h3");'
            .   'if(h2) h2.style.flex="1 1 auto";'
            .   'if(WARN_TEXT&&!document.getElementById(WARN_ID)){'
            .     'var warn=document.createElement("span");'
            .     'warn.id=WARN_ID;'
            .     'warn.textContent=WARN_TEXT;'
            .     'warn.style.cssText="font-size:12px;color:var(--md-error,#b3261e,#b3261e);font-weight:500;white-space:nowrap;";'
            .     'titleArea.appendChild(warn);'
            .   '}'
            .   'var btn;'
            .   'if(BTN_ACTION==="install"){'
            .     'btn=document.createElement("button");'
            .     'btn.type="button";'
            .     'btn.onclick=function(){'
            .       'btn.disabled=true;'
            .       'btn.textContent="安装中...";'
            .       'var ajax=window.__AB_AJAX__||{};'
            .       'if(!ajax.url){btn.textContent="❌ 获取接口地址失败";btn.disabled=false;return;}'
            .       'var xhr=new XMLHttpRequest();'
            .       'xhr.open("POST",ajax.url+"?do=install-abs",true);'
            .       'xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");'
            .       'xhr.setRequestHeader("X-Requested-With","XMLHttpRequest");'
            .       'xhr.onload=function(){'
            .         'try{'
            .           'var res=JSON.parse(xhr.responseText);'
            .           'if(res.code===0){'
            .             'btn.textContent="✅ 安装成功，刷新中...";'
            .             'setTimeout(function(){location.reload();},1500);'
            .           '}else{'
            .             'btn.textContent="❌ "+(res.message||"安装失败");'
            .             'btn.disabled=false;'
            .           '}'
            .         '}catch(e){'
            .           'btn.textContent="❌ 安装失败";'
            .           'btn.disabled=false;'
            .         '}'
            .       '};'
            .       'xhr.onerror=function(){btn.textContent="❌ 网络错误";btn.disabled=false;};'
            .       'xhr.send("_="+encodeURIComponent(ajax.token||""));'
            .     '};'
            .   '}else{'
            .     'btn=document.createElement("a");'
            .     'btn.href=BTN_URL;'
            .     'btn.target=BTN_TARGET;'
            .     'btn.rel="noopener";'
            .   '}'
            .   'btn.id=BTN_ID;'
            .   'btn.innerHTML=\'<span class="material-icons-round" style="font-size:18px;margin-right:6px;vertical-align:-3px">store</span>\'+BTN_TEXT;'
            .   'btn.className="ab-store-shortcut-md3-btn";'
            .   'btn.style.cssText='
            .     '"display:inline-flex;align-items:center;margin-left:auto;flex-shrink:0;padding:8px 16px 8px 12px;'
            .     'border-radius:20px;border:none;cursor:pointer;font-size:14px;font-weight:600;font-family:inherit;'
            .     'background:var(--md-secondary-container,#e8def8);color:var(--md-on-secondary-container,#1d192b);'
            .     'box-shadow:0 1px 3px rgba(0,0,0,.12);transition:box-shadow .2s,background .2s;line-height:1;white-space:nowrap;'
            .     'text-decoration:none;";'
            .   'btn.addEventListener("mouseover",function(){this.style.boxShadow="0 3px 10px rgba(0,0,0,.18)";});'
            .   'btn.addEventListener("mouseout",function(){this.style.boxShadow="0 1px 3px rgba(0,0,0,.12)";});'
            .   'titleArea.appendChild(btn);'
            . '}'
            . 'function abRemoveStoreBtn(){'
            .   'var old=document.getElementById(BTN_ID);'
            .   'if(old)old.parentNode.removeChild(old);'
            .   'var ow=document.getElementById(WARN_ID);'
            .   'if(ow)ow.parentNode.removeChild(ow);'
            . '}'
            . 'function abCheckAndInject(url){'
            .   'if((url||window.location.href).indexOf("plugins.php")!==-1){abInjectStoreBtn();}'
            .   'else{abRemoveStoreBtn();}'
            . '}'
            . 'if(document.readyState==="loading"){'
            .   'document.addEventListener("DOMContentLoaded",function(){abCheckAndInject();});'
            . '}else{abCheckAndInject();}'
            . 'document.addEventListener("ab:pageload",function(e){'
            .   'var url=(e&&e.detail&&e.detail.url)?e.detail.url:window.location.href;'
            .   'abCheckAndInject(url);'
            . '});'
            . '})();</script>';
        }
        if (self::storeBoot() && AdminBeautify_Store::enabled()) {
            $storeOpts = Typecho_Widget::widget('Widget_Options');
            $storeJsUrl = Typecho_Common::url('AdminBeautify/store/assets/store.js', $storeOpts->pluginUrl);
            $storeJsFile = dirname(__FILE__) . '/store/assets/store.js';
            $storeJsVer = is_file($storeJsFile) ? (string) filemtime($storeJsFile) : '0';
            echo '<script src="' . htmlspecialchars($storeJsUrl . '?v=' . $storeJsVer) . '"></script>' . "\n";
        }
        if (self::storeBoot() && AdminBeautify_Store::enabled()
            && !AdminBeautify_Store::notifyOptOut()) {
            $ucOpts = Typecho_Widget::widget('Widget_Options');
            $ucUrl = Typecho_Common::url('AdminBeautify/store/assets/update-check.js', $ucOpts->pluginUrl);
            $ucFile = dirname(__FILE__) . '/store/assets/update-check.js';
            $ucVer = is_file($ucFile) ? (string) filemtime($ucFile) : '0';
            echo '<script src="' . htmlspecialchars($ucUrl . '?v=' . $ucVer) . '"></script>' . "\n";
        }
        echo '<script>(function(){
setTimeout(function(){
    var LS_KEY="ab-compat-auto-sync-ts";
    var ONE_DAY=86400000;
    var last=0;
    try{last=parseInt(localStorage.getItem(LS_KEY)||"0",10)||0;}catch(e){}
    if(Date.now()-last<ONE_DAY)return;
    var ajax=window.__AB_AJAX__||{};
    if(!ajax.url)return;
    var xhr=new XMLHttpRequest();
    xhr.open("POST",ajax.url+"?do=sync-compat",true);
    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    xhr.setRequestHeader("X-Requested-With","XMLHttpRequest");
    xhr.timeout=60000;
    xhr.onload=function(){
        try{
            var res=JSON.parse(xhr.responseText);
            if(res.code===0){
                try{localStorage.setItem(LS_KEY,Date.now().toString());}catch(e){}
                var s=(res.data||{}).summary||{};
                var n=(s.added||0)+(s.updated||0);
                if(n>0)abCompatAutoSyncToast(n);
            }
        }catch(e){}
    };
    xhr.onerror=xhr.ontimeout=function(){};
    xhr.send("_="+encodeURIComponent(ajax.token||""));
},10000);
function abCompatAutoSyncToast(n){
    if(document.getElementById("ab-compat-autosync-toast"))return;
    var t=document.createElement("div");
    t.id="ab-compat-autosync-toast";
    t.style.cssText="position:fixed;bottom:24px;right:24px;z-index:9999;background:var(--md-surface,#fff);border:1px solid var(--md-outline-variant,#cac4d0);border-radius:16px;padding:14px 18px;font-size:13px;color:var(--md-on-surface,#1c1b1f);box-shadow:0 4px 20px rgba(0,0,0,.14);display:flex;align-items:center;gap:10px;animation:ab-fade-in .3s ease;max-width:320px";
    t.innerHTML="<span class=\"material-icons-round\" style=\"font-size:20px;color:var(--md-primary,#6750a4)\">update</span>"
        +"<span>兼容脚本自动更新了 <strong>"+n+"</strong> 个，请刷新页面生效。</span>";
    var cls=document.createElement("button");
    cls.textContent="\u00d7";
    cls.style.cssText="border:none;background:transparent;cursor:pointer;font-size:16px;color:var(--md-on-surface-variant,#49454f);opacity:.6;flex-shrink:0;padding:0";
    cls.onclick=function(){t.parentNode&&t.parentNode.removeChild(t);};
    t.appendChild(cls);
    document.body.appendChild(t);
    setTimeout(function(){if(t.parentNode)t.parentNode.removeChild(t);},8000);
}
})();</script>';
        echo '<script>';
        echo 'window.__AB_TS_URL__='  . json_encode(Typecho_Common::url('/action/admin-beautify', $options->index)) . ';';
        echo 'window.__AB_TS_TOKEN__=' . json_encode($token) . ';';
        echo '</script>';
        self::loadCompatScripts($options, $pluginOptions);
    }
    private static function loadCompatScripts($options, $pluginOptions)
    {
        $compatBaseUrl = Typecho_Common::url('AdminBeautify/assets/compat/', $options->pluginUrl);
        $compatDir = dirname(__FILE__) . '/assets/compat/';
        $enabledRaw = isset($pluginOptions->compat_disabledScripts) ? (string) $pluginOptions->compat_disabledScripts : '';
        $enabledList = ($enabledRaw !== '') ? (array) json_decode($enabledRaw, true) : array();
        if (!is_array($enabledList)) $enabledList = array();
        if (is_dir($compatDir) && !empty($enabledList)) {
            foreach ($enabledList as $file) {
                if (substr($file, -3) === '.js' && is_file($compatDir . $file)) {
                    $fileUrl = $compatBaseUrl . $file;
                    $fileMtime = filemtime($compatDir . $file);
                    echo '<script src="' . htmlspecialchars($fileUrl) . '?v=' . $fileMtime . '"></script>' . "\n";
                }
            }
        }
        $externalJs = isset($pluginOptions->compat_externalJs) ? trim((string) $pluginOptions->compat_externalJs) : '';
        if ($externalJs !== '') {
            $lines = preg_split('/[\r\n]+/', $externalJs);
            foreach ($lines as $line) {
                $url = trim($line);
                if ($url !== '' && (strpos($url, 'http://') === 0 || strpos($url, 'https://') === 0 || strpos($url, '//') === 0)) {
                    echo '<script src="' . htmlspecialchars($url) . '"></script>' . "\n";
                }
            }
        }
    }
    private static function scanCompatScripts($compatDir)
    {
        $result = array();
        if (!is_dir($compatDir)) return $result;
        $files = scandir($compatDir);
        if (!$files) return $result;
        foreach ($files as $file) {
            if (substr($file, -3) !== '.js' || !is_file($compatDir . $file)) continue;
            $meta = self::parseCompatMeta($compatDir . $file);
            $meta['file'] = $file;
            $result[] = $meta;
        }
        return $result;
    }
    private static function parseCompatMeta($filePath)
    {
        $defaults = array(
            'name'        => '',
            'description' => '',
            'plugins'     => '',
            'version'     => '',
            'author'      => '',
        );
        $content = @file_get_contents($filePath, false, null, 0, 2048);
        if ($content === false) return $defaults;
        if (!preg_match('/\/\*\*(.*?)\*\//s', $content, $blockMatch)) {
            return $defaults;
        }
        $block = $blockMatch[1];
        $tags = array('name', 'description', 'plugins', 'version', 'author');
        foreach ($tags as $tag) {
            if (preg_match('/@' . $tag . '\s+(.+)/i', $block, $m)) {
                $defaults[$tag] = trim($m[1]);
            }
        }
        if ($defaults['name'] === '') {
            $defaults['name'] = basename($filePath, '.js');
        }
        return $defaults;
    }
    private static function renderCompatScriptsList($scripts, $enabledList, $accentColor)
    {
        if (empty($scripts)) {
            echo '<div id="ab-compat-scripts-list" class="ab-compat-empty" style="margin:12px 0 20px;padding:16px;background:#fefce8;border:1px solid #fde68a;border-radius:10px;font-size:13px;color:#854d0e">
                <span style="margin-right:6px">📂</span> <code>assets/compat/</code> 目录中未找到兼容脚本。
            </div>';
            return;
        }
        echo '<div id="ab-compat-scripts-list" style="margin:12px 0 20px">';
        echo '<div class="ab-compat-list-title" style="font-size:14px;font-weight:600;color:#374151;margin-bottom:10px;display:flex;align-items:center;gap:6px;flex-wrap:wrap">
            <span style="font-size:16px">📋</span>
            <span style="flex:1">本地兼容脚本（共 ' . count($scripts) . ' 个）</span>
            <button id="ab-compat-sync-btn" type="button" onclick="abSyncCompat()" style="'
                . 'display:inline-flex;align-items:center;gap:6px;padding:6px 14px;'
                . 'background:' . $accentColor . ';color:#fff;border:none;border-radius:20px;'
                . 'font-size:12px;font-weight:500;cursor:pointer;transition:opacity .2s;'
                . 'box-shadow:0 1px 4px rgba(0,0,0,.15);flex-shrink:0'
                . '" onmouseover="this.style.opacity=\'.85\'" onmouseout="this.style.opacity=\'1\'">'
                . '<span id="ab-compat-sync-icon">☁️</span><span id="ab-compat-sync-label">从 GitHub 同步</span>'
            . '</button>
        </div>
        <div id="ab-compat-sync-result" style="display:none;margin-bottom:12px"></div>';
        foreach ($scripts as $s) {
            $file = htmlspecialchars($s['file']);
            $name = htmlspecialchars($s['name']);
            $desc = htmlspecialchars($s['description']);
            $plugins = htmlspecialchars($s['plugins']);
            $version = htmlspecialchars($s['version']);
            $author = htmlspecialchars($s['author']);
            $isEnabled = in_array($s['file'], $enabledList);
            $toggleId = 'ab-compat-toggle-' . md5($s['file']);
            echo '<div class="ab-compat-script-item" data-file="' . $file . '" style="'
                . 'display:flex;align-items:flex-start;gap:14px;padding:14px 18px;margin-bottom:8px;'
                . 'background:' . ($isEnabled ? '#fff' : '#f9fafb') . ';'
                . 'border:1px solid ' . ($isEnabled ? $accentColor . '44' : '#e5e7eb') . ';'
                . 'border-radius:12px;transition:all .2s;'
                . ($isEnabled ? '' : 'opacity:.6;')
                . '">';
            echo '<div style="flex-shrink:0;padding-top:2px">'
                . '<label style="position:relative;display:inline-block;width:44px;height:24px;cursor:pointer">'
                . '<input type="checkbox" class="ab-compat-checkbox" data-file="' . $file . '" '
                . ($isEnabled ? 'checked' : '') . ' '
                . 'style="opacity:0;width:0;height:0;position:absolute">'
                . '<span style="'
                . 'position:absolute;top:0;left:0;right:0;bottom:0;'
                . 'background:' . ($isEnabled ? $accentColor : '#d1d5db') . ';'
                . 'border-radius:12px;transition:background .2s;'
                . '"></span>'
                . '<span style="'
                . 'position:absolute;top:2px;left:' . ($isEnabled ? '22px' : '2px') . ';'
                . 'width:20px;height:20px;background:#fff;border-radius:50%;'
                . 'transition:left .2s;box-shadow:0 1px 3px rgba(0,0,0,.2);'
                . '"></span>'
                . '</label>'
                . '</div>';
            echo '<div style="flex:1;min-width:0">';
            echo '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:4px">';
            echo '<span class="ab-compat-name" style="font-size:14px;font-weight:600;color:#111827">' . $name . '</span>';
            if ($version) {
                echo '<span class="ab-compat-meta" style="font-size:11px;color:#6b7280;background:#f3f4f6;padding:1px 8px;border-radius:8px">v' . $version . '</span>';
            }
            if ($author) {
                echo '<span class="ab-compat-meta" style="font-size:11px;color:#6b7280">by ' . $author . '</span>';
            }
            echo '</div>';
            if ($desc) {
                echo '<div class="ab-compat-desc" style="font-size:13px;color:#4b5563;line-height:1.5;margin-bottom:4px">' . $desc . '</div>';
            }
            if ($plugins) {
                $pluginArr = array_map('trim', explode(',', $plugins));
                echo '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:4px">';
                foreach ($pluginArr as $p) {
                    echo '<span style="font-size:11px;color:' . $accentColor . ';background:' . $accentColor . '15;padding:2px 10px;border-radius:8px;border:1px solid ' . $accentColor . '33;font-weight:500">'
                        . htmlspecialchars($p) . '</span>';
                }
                echo '</div>';
            }
            echo '<div class="ab-compat-meta" style="font-size:11px;color:#9ca3af;margin-top:4px">📄 ' . $file . '</div>';
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';
        echo '<script>
(function(){
    function updateEnabledList(){
        var items = document.querySelectorAll(".ab-compat-checkbox");
        var enabled = [];
        for(var i=0;i<items.length;i++){
            if(items[i].checked){
                enabled.push(items[i].getAttribute("data-file"));
            }
        }
        var hidden = document.querySelector("[name=compat_disabledScripts]");
        if(hidden) hidden.value = JSON.stringify(enabled);
    }
    function initToggles(){
        var checkboxes = document.querySelectorAll(".ab-compat-checkbox");
        for(var i=0;i<checkboxes.length;i++){
            checkboxes[i].addEventListener("change", function(){
                var item = this.closest(".ab-compat-script-item");
                var track = this.nextElementSibling;
                var thumb = track ? track.nextElementSibling : null;
                if(this.checked){
                    if(item){item.style.opacity="1";item.style.background="#fff";}
                    if(track) track.style.background="' . $accentColor . '";
                    if(thumb) thumb.style.left="22px";
                }else{
                    if(item){item.style.opacity=".6";item.style.background="#f9fafb";}
                    if(track) track.style.background="#d1d5db";
                    if(thumb) thumb.style.left="2px";
                }
                updateEnabledList();
            });
        }
    }
    if(document.readyState==="loading"){
        document.addEventListener("DOMContentLoaded",initToggles);
    }else{
        initToggles();
    }
})();
// ---- 从 GitHub 同步兼容脚本 ----
window.abSyncCompat = function(){
    var btn = document.getElementById("ab-compat-sync-btn");
    var icon = document.getElementById("ab-compat-sync-icon");
    var label = document.getElementById("ab-compat-sync-label");
    var resultBox = document.getElementById("ab-compat-sync-result");
    if(!btn) return;
    btn.disabled = true;
    btn.style.opacity = ".6";
    if(icon) icon.textContent = "⏳";
    if(label) label.textContent = "同步中...";
    if(resultBox){ resultBox.style.display="none"; resultBox.innerHTML=""; }
    var ajax = window.__AB_AJAX__ || {};
    var url = (ajax.url || "") + "?do=sync-compat";
    var token = ajax.token || "";
    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
    xhr.timeout = 60000;
    xhr.onload = function(){
        btn.disabled = false; btn.style.opacity = "1";
        if(icon) icon.textContent = "☁️";
        if(label) label.textContent = "从 GitHub 同步";
        try{
            var res = JSON.parse(xhr.responseText);
            if(res.code === 0){
                var d = res.data || {};
                var summary = d.summary || {};
                var results = d.results || [];
                var html = "<div style=\"padding:12px 16px;border-radius:12px;font-size:13px;line-height:1.8;"
                    + "background:#f0fdf4;border:1px solid #bbf7d0;color:#166534\">"
                    + "<div style=\"font-weight:600;margin-bottom:6px\">✅ " + res.message + "</div>"
                    + "<div style=\"display:flex;gap:16px;flex-wrap:wrap;margin-bottom:8px\">"
                    + "<span>❗ 新增 <strong>" + (summary.added||0) + "</strong></span>"
                    + "<span>☁️ 更新 <strong>" + (summary.updated||0) + "</strong></span>"
                    + "<span>✔️ 跳过 <strong>" + (summary.skipped||0) + "</strong></span>"
                    + (summary.errors > 0 ? "<span style=\"color:#dc2626\">❌ 失败 <strong>" + summary.errors + "</strong></span>" : "")
                    + "</div>";
                var changed = [];
                for(var i=0;i<results.length;i++){
                    var r = results[i];
                    if(r.status === "added" || r.status === "updated" || r.status === "error"){
                        var icon2 = r.status==="added"?"❗":r.status==="updated"?"☁️":"❌";
                        changed.push("<span style=\"margin-right:12px\">" + icon2 + " " + r.file
                            + (r.msg ? " <span style=\"color:#6b7280;font-size:12px\">(" + r.msg + ")</span>" : "")
                            + "</span>");
                    }
                }
                if(changed.length > 0){
                    html += "<div style=\"flex-wrap:wrap;display:flex\">" + changed.join("") + "</div>";
                }
                if((summary.added||0) + (summary.updated||0) > 0){
                    html += "<div style=\"margin-top:8px;font-size:12px;color:#166534\">💡 有脚本已更新，请刷新页面以查看最新列表。</div>";
                }
                html += "</div>";
                if(resultBox){ resultBox.innerHTML=html; resultBox.style.display="block"; }
            } else {
                var errHtml = "<div style=\"padding:12px 16px;border-radius:12px;font-size:13px;background:#fef2f2;border:1px solid #fecaca;color:#dc2626\">"
                    + "❌ " + (res.message || "同步失败") + "</div>";
                if(resultBox){ resultBox.innerHTML=errHtml; resultBox.style.display="block"; }
            }
        } catch(e){
            if(resultBox){ resultBox.innerHTML="<div style=\"padding:12px;border-radius:10px;background:#fef2f2;color:#dc2626;font-size:13px\">❌ 响应解析失败</div>"; resultBox.style.display="block"; }
        }
    };
    xhr.onerror = xhr.ontimeout = function(){
        btn.disabled = false; btn.style.opacity = "1";
        if(icon) icon.textContent = "☁️";
        if(label) label.textContent = "从 GitHub 同步";
        if(resultBox){ resultBox.innerHTML="<div style=\"padding:12px;border-radius:10px;background:#fef2f2;color:#dc2626;font-size:13px\">❌ 请求超时或网络错误，请检查服务器是否能访问 GitHub</div>"; resultBox.style.display="block"; }
    };
    xhr.send("_=" + encodeURIComponent(token));
};
</script>';
    }
    public static function renderLoginFooter()
    {
        self::renderLoginScript(false);
    }
    public static function renderLoginScript($ignoreEnabled = false)
    {
        if (!$ignoreEnabled && !self::isLoginPage()) {
            return;
        }
        $options = Typecho_Widget::widget('Widget_Options');
        $pluginOptions = self::pluginOptions($options);
        $loginIsEnabled = isset($pluginOptions->login_isEnabled) ? (string)$pluginOptions->login_isEnabled : '1';
        if (!$ignoreEnabled && $loginIsEnabled !== '1') {
            return;
        }
        $showSiteName = ((string) $pluginOptions->login_showSiteName !== '0');
        $showThemeToggle = ((string) $pluginOptions->login_showThemeToggle !== '0');
        $customJs = (string) $pluginOptions->login_customJs;
        $siteTitle = (string) $options->title;
        $jsSiteTitle = self::jsString($siteTitle);
        $jsShowSiteName = $showSiteName ? 'true' : 'false';
        $jsShowToggle = $showThemeToggle ? 'true' : 'false';
        $loginUrl = (string) $options->loginUrl;
        $jsForgotUrl = self::jsString(
            $loginUrl . (strpos($loginUrl, '?') === false ? '?' : '&') . 'ab-forgot=1'
        );
        $jsLoginUrl = self::jsString($loginUrl);
        $jsForgotApiUrl = self::jsString((string) Typecho_Common::url(
            'AdminBeautify/assets/pages/forgot/forgot-password.php',
            $options->pluginUrl
        ) . '?format=json');
        $jsTurnstileLogin = self::jsString(self::turnstileSiteKey('login'));
        $jsTurnstileRegister = self::jsString(self::turnstileSiteKey('register'));
        $jsTurnstileForgot = self::jsString(self::turnstileSiteKey('forgot'));
        include dirname(__FILE__) . '/assets/pages/login/script.php';
        include dirname(__FILE__) . '/assets/pages/forgot/client.php';
        include dirname(__FILE__) . '/assets/pages/forgot/turnstile.php';
    }
    private static function outputLoginHeaderCss()
    {
        self::renderLoginStyle(false);
    }
    public static function renderLoginStyle($ignoreEnabled = false)
    {
        $options = Typecho_Widget::widget('Widget_Options');
        $pluginOptions = self::pluginOptions($options);
        $loginIsEnabled = isset($pluginOptions->login_isEnabled) ? (string)$pluginOptions->login_isEnabled : '1';
        if (!$ignoreEnabled && $loginIsEnabled !== '1') {
            return;
        }
        $themeMode = isset($pluginOptions->login_themeMode) ? (string) $pluginOptions->login_themeMode : 'auto';
        if (!in_array($themeMode, array('auto', 'light', 'dark'), true)) {
            $themeMode = 'auto';
        }
        $bgImage = trim((string) $pluginOptions->login_bgImage);
        $blurType = in_array($pluginOptions->login_blurType, array('none', 'filter', 'backdrop'), true) ? $pluginOptions->login_blurType : 'filter';
        $blurSize = (int) $pluginOptions->login_blurSize;
        if ($blurSize < 0) $blurSize = 0;
        if ($blurSize > 80) $blurSize = 80;
        $customCss = (string) $pluginOptions->login_customCss;
        $preset = isset($pluginOptions->login_colorPreset) ? (string) $pluginOptions->login_colorPreset : 'purple';
        $colorPresets = array(
            'purple'   => array('#7d5260', '#9e7b8a'),
            'blue'     => array('#556270', '#7a8a9e'),
            'pink'     => array('#74565f', '#9e7a85'),
            'green'    => array('#55624c', '#7a8a6e'),
            'orange'   => array('#725a42', '#9e8062'),
            'red'      => array('#775654', '#a27a78'),
            'teal'     => array('#4a6363', '#6a8a8a'),
            'indigo'   => array('#5a4fd9', '#7b6ef2'),
            'sunset'   => array('#d38d1a', '#e06b3a'),
            'ocean'    => array('#0da0d8', '#39c1dd'),
            'forest'   => array('#2f7a3b', '#7fbf3a'),
            'lavender' => array('#8f6ee8', '#b89cfb'),
        );
        if ($preset === 'custom') {
            $primary = isset($pluginOptions->login_primaryColor) && trim((string) $pluginOptions->login_primaryColor) !== '' ? trim((string) $pluginOptions->login_primaryColor) : '#7d5260';
            $primary2 = isset($pluginOptions->login_primaryColor2) && trim((string) $pluginOptions->login_primaryColor2) !== '' ? trim((string) $pluginOptions->login_primaryColor2) : '#9e7b8a';
        } else {
            $colors = isset($colorPresets[$preset]) ? $colorPresets[$preset] : $colorPresets['purple'];
            $primary = $colors[0];
            $primary2 = $colors[1];
        }
        $bgCss = $bgImage !== '' ? "url(" . htmlspecialchars($bgImage, ENT_QUOTES, 'UTF-8') . ")" : "none";
        $jsThemeMode = self::jsString($themeMode);
        include dirname(__FILE__) . '/assets/pages/login/style.php';
        include dirname(__FILE__) . '/assets/pages/forgot/style.php';
    }
    private static function renderLoginPreview()
    {
        try {
            $opt = Typecho_Widget::widget('Widget_Options')->plugin('AdminBeautify');
            $preset = isset($opt->login_colorPreset) ? (string) $opt->login_colorPreset : 'purple';
            $pc1 = isset($opt->login_primaryColor) ? (string) $opt->login_primaryColor : '#7d5260';
            $pc2 = isset($opt->login_primaryColor2) ? (string) $opt->login_primaryColor2 : '#9e7b8a';
            $bgUrl = isset($opt->login_bgImage) ? (string) $opt->login_bgImage : '';
            $blurTypeVal = isset($opt->login_blurType) ? (string) $opt->login_blurType : 'filter';
            $blurSizeVal = isset($opt->login_blurSize) ? (int) $opt->login_blurSize : 12;
        } catch (Exception $e) {
            $preset = 'purple';
            $pc1 = '#7d5260';
            $pc2 = '#9e7b8a';
            $bgUrl = '';
            $blurTypeVal = 'filter';
            $blurSizeVal = 12;
        }
        include dirname(__FILE__) . '/assets/pages/login/preview.php';
    }
    const CARD_TABLE = 'abadmin';
    const CARD_KEY_PREFIX = 'card-';
    const CARD_KEY_MAX_LEN = 64;
    const CARD_CONTENT_MAX_BYTES = 65535;
    const CARD_CODE_KEY_PREFIX = 'cc';
    const CARD_CODE_MAX_BYTES = 65535;
    const OPTION_BLOB_MAX_BYTES = 61440;
    const DB_READ_DEFAULT_LIMIT = 50;
    const DB_READ_MAX_LIMIT = 200;
    const DB_READ_MAX_VALUE_BYTES = 8192;
    private static $dbReadDenyTables = array(
        'options',
        'information_schema',
        'performance_schema',
        'mysql',
        'sys',
        'pg_catalog',
        'sqlite_master',
        'sqlite_sequence',
    );
    private static $dbReadDenyColumns = array('password', 'passwd', 'authcode', 'salt');
    private static $dbReadOperators = array('=', '!=', '<>', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN');
    private static function currentUid()
    {
        try {
            $user = Typecho_Widget::widget('Widget_User');
            if ($user->hasLogin()) {
                return (int) $user->uid;
            }
        } catch (Exception $e) {
        } catch (Throwable $e) {
        }
        return 0;
    }
    private static function getDb()
    {
        try {
            return Typecho_Db::get();
        } catch (Exception $e) {
            return null;
        } catch (Throwable $e) {
            return null;
        }
    }
    private static function cardTableName($db)
    {
        $prefix = preg_replace('/[^A-Za-z0-9_]/', '', (string) $db->getPrefix());
        return $prefix . self::CARD_TABLE;
    }
    private static function cardTableReady($db, $reset = false)
    {
        static $ready = null;
        if ($reset) $ready = null;
        if ($ready !== null) return $ready;
        $ready = false;
        try {
            $db->fetchRow($db->select(array('COUNT(*)' => 'num'))->from('table.' . self::CARD_TABLE));
            $ready = true;
        } catch (Exception $e) {
            $ready = false;
        } catch (Throwable $e) {
            $ready = false;
        }
        return $ready;
    }
    private static function cardTableDdl($adapter, $table)
    {
        $a = strtolower((string) $adapter);
        if (strpos($a, 'sqlite') !== false) {
            return array(
                'CREATE TABLE IF NOT EXISTS "' . $table . '" ('
                . '"id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, '
                . '"uid" INTEGER NOT NULL DEFAULT 0, '
                . '"card_key" VARCHAR(64) NOT NULL DEFAULT \'\', '
                . '"content" TEXT, '
                . '"created_at" INTEGER NOT NULL DEFAULT 0, '
                . '"updated_at" INTEGER NOT NULL DEFAULT 0'
                . ')',
                'CREATE UNIQUE INDEX IF NOT EXISTS "' . $table . '_uid_key" ON "' . $table . '" ("uid","card_key")',
            );
        }
        if (strpos($a, 'pgsql') !== false) {
            return array(
                'CREATE TABLE IF NOT EXISTS "' . $table . '" ('
                . '"id" SERIAL NOT NULL, '
                . '"uid" INTEGER NOT NULL DEFAULT 0, '
                . '"card_key" VARCHAR(64) NOT NULL DEFAULT \'\', '
                . '"content" TEXT, '
                . '"created_at" INTEGER NOT NULL DEFAULT 0, '
                . '"updated_at" INTEGER NOT NULL DEFAULT 0, '
                . 'PRIMARY KEY ("id")'
                . ')',
                'CREATE UNIQUE INDEX IF NOT EXISTS "' . $table . '_uid_key" ON "' . $table . '" ("uid","card_key")',
            );
        }
        return array(
            'CREATE TABLE IF NOT EXISTS `' . $table . '` ('
            . '`id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, '
            . '`uid` INT(10) UNSIGNED NOT NULL DEFAULT 0, '
            . '`card_key` VARCHAR(64) NOT NULL DEFAULT \'\', '
            . '`content` TEXT NULL, '
            . '`created_at` INT(10) UNSIGNED NOT NULL DEFAULT 0, '
            . '`updated_at` INT(10) UNSIGNED NOT NULL DEFAULT 0, '
            . 'PRIMARY KEY (`id`), '
            . 'UNIQUE KEY `' . $table . '_uid_key` (`uid`,`card_key`)'
            . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
        );
    }
    public static function ensureCardTable()
    {
        $db = self::getDb();
        if (!$db) return false;
        if (self::cardTableReady($db)) return true;
        $table = self::cardTableName($db);
        foreach (self::cardTableDdl((string) $db->getAdapterName(), $table) as $sql) {
            try {
                $db->query($sql, Typecho_Db::WRITE, Typecho_Db::SELECT);
            } catch (Exception $e) {
                return false;
            } catch (Throwable $e) {
                return false;
            }
        }
        return self::cardTableReady($db, true);
    }
    private static function cardCodeKey($cardId, $part)
    {
        return self::CARD_KEY_PREFIX . self::CARD_CODE_KEY_PREFIX . '-' . $cardId . '-' . $part;
    }
    private static function normalizeCardField($value, $fallback)
    {
        $value = (string) preg_replace('/[^A-Za-z0-9_-]/', '', (string) $value);
        if ($value === '') $value = (string) $fallback;
        return substr($value, 0, 40);
    }
    private static function normalizeCards($cards)
    {
        $out = array();
        if (!is_array($cards)) return $out;
        foreach ($cards as $item) {
            if (!is_array($item)) continue;
            $out[] = array(
                'id'    => self::normalizeCardField(isset($item['id']) ? $item['id'] : '', 'c' . (count($out) + 1)),
                'icon'  => self::normalizeCardField(isset($item['icon']) ? $item['icon'] : '', 'widgets'),
                'title' => isset($item['title']) ? (string) $item['title'] : '',
                'html'  => isset($item['html']) ? (string) $item['html'] : '',
                'js'    => isset($item['js']) ? (string) $item['js'] : '',
                'code'  => isset($item['code']) ? (string) preg_replace('/[^A-Za-z0-9_-]/', '', (string) $item['code']) : '',
            );
        }
        return $out;
    }
    private static function normalizeCardGroups($raw)
    {
        $out = array();
        if (!is_string($raw) || $raw === '') return $out;
        $data = json_decode($raw, true);
        if (!is_array($data)) return $out;
        $builtin = array('umami', 'freq', 'cat', 'posts', 'replies', 'more');
        foreach ($data as $group) {
            if (!is_array($group)) continue;
            $id = isset($group['id']) ? preg_replace('/[^A-Za-z0-9_-]/', '', (string) $group['id']) : '';
            if ($id === '') continue;
            $cards = array();
            if (isset($group['cards']) && is_array($group['cards'])) {
                foreach ($group['cards'] as $key) {
                    $key = (string) $key;
                    if (strpos($key, 'custom:') === 0) {
                        if (!preg_match('/^custom:[A-Za-z0-9_-]{1,64}$/', $key)) continue;
                    } elseif (!in_array($key, $builtin, true)) {
                        continue;
                    }
                    if (!in_array($key, $cards, true)) $cards[] = $key;
                }
            }
            if (!$cards) continue;
            $title = isset($group['title']) ? trim((string) $group['title']) : '';
            $out[] = array(
                'id'    => substr($id, 0, 32),
                'title' => $title !== '' ? $title : '堆叠卡片',
                'cards' => $cards,
            );
        }
        return $out;
    }
    private static function readCardCodeRows($db = null)
    {
        if ($db === null) $db = self::getDb();
        if (!$db) return null;
        if (!self::cardTableReady($db)) return null;
        try {
            $rows = $db->fetchAll(
                $db->select('card_key', 'content')
                    ->from('table.' . self::CARD_TABLE)
                    ->where('uid = ?', 0)
                    ->where('card_key LIKE ?', self::CARD_KEY_PREFIX . self::CARD_CODE_KEY_PREFIX . '-%')
            );
        } catch (Exception $e) {
            return null;
        } catch (Throwable $e) {
            return null;
        }
        $out = array();
        foreach ((array) $rows as $row) {
            if (!is_array($row) || !isset($row['card_key'])) continue;
            $out[(string) $row['card_key']] = isset($row['content']) ? (string) $row['content'] : '';
        }
        return $out;
    }
    private static function hydrateCards(array &$cards, $db = null, $rows = null)
    {
        $missing = array();
        foreach ($cards as $i => $card) {
            if ($card['html'] === '' && $card['js'] === '') $missing[$i] = $card['id'];
        }
        if (empty($missing)) return true;
        if ($rows === null) {
            $rows = self::readCardCodeRows($db);
            if ($rows === null) return false;
        }
        foreach ($missing as $i => $cardId) {
            foreach (array('h' => 'html', 'j' => 'js') as $part => $field) {
                $key = self::cardCodeKey($cardId, $part);
                if (array_key_exists($key, $rows)) $cards[$i][$field] = $rows[$key];
            }
            $hasCode = ($cards[$i]['html'] !== '' || $cards[$i]['js'] !== '');
            $cards[$i]['code'] = $hasCode ? 'db' : '';
        }
        return true;
    }
    private static function writeCardCodes($db, array $cards, &$error)
    {
        $now = time();
        $keep = array();
        foreach ($cards as $card) {
            foreach (array('h' => $card['html'], 'j' => $card['js']) as $part => $code) {
                $key = self::cardCodeKey($card['id'], $part);
                $keep[$key] = true;
                if ($code === '') continue;
                if (strlen($code) > self::CARD_CODE_MAX_BYTES) {
                    $error = '卡片「' . ($card['title'] !== '' ? $card['title'] : $card['id']) . '」的代码单块超过 '
                        . self::CARD_CODE_MAX_BYTES . ' 字节，无法存入数据表，请精简后重试';
                    return false;
                }
                $key = self::cardCodeKey($card['id'], $part);
                try {
                    self::cardUpsertOnce($db, 0, $key, $code, $now);
                } catch (Exception $e) {
                    $error = '卡片代码写入失败：' . $e->getMessage();
                    return false;
                } catch (Throwable $e) {
                    $error = '卡片代码写入失败：' . $e->getMessage();
                    return false;
                }
            }
        }
        $rows = self::readCardCodeRows($db);
        if (is_array($rows)) {
            foreach (array_keys($rows) as $key) {
                if (isset($keep[$key])) continue;
                try {
                    $db->query($db->delete('table.' . self::CARD_TABLE)
                        ->where('uid = ?', 0)
                        ->where('card_key = ?', $key));
                } catch (Exception $e) {
                } catch (Throwable $e) {
                }
            }
        }
        return true;
    }
    private static function slimCardsJson(array $cards)
    {
        $slim = array();
        foreach ($cards as $card) {
            $item = array(
                'id'    => $card['id'],
                'icon'  => $card['icon'],
                'title' => $card['title'],
            );
            if ($card['html'] !== '' || $card['js'] !== '') {
                $item['code'] = 'db';
            } else {
                $item['html'] = '';
                $item['js']   = '';
            }
            $slim[] = $item;
        }
        return (string) json_encode($slim, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    private static function optionBlobBytes(array $settings)
    {
        $json = (string) json_encode($settings);
        $ser = '';
        try {
            $ser = (string) serialize($settings);
        } catch (Exception $e) {
            $ser = '';
        } catch (Throwable $e) {
            $ser = '';
        }
        return max(strlen($json), strlen($ser));
    }
    private static function optionBlobWarning(array $settings, $prefix = '自定义卡片')
    {
        $bytes = self::optionBlobBytes($settings);
        if ($bytes <= self::OPTION_BLOB_MAX_BYTES) return '';
        return $prefix . '体积 ' . number_format($bytes) . ' 字节，已超过安全阈值 '
            . number_format(self::OPTION_BLOB_MAX_BYTES) . ' 字节（Typecho 单条设置上限是 65535 字节，这里留了 4KB 余量）';
    }
    private static function notice($message, $type = 'notice')
    {
        if ($message === '' || $message === null) return;
        try {
            Typecho_Widget::widget('Widget_Notice')->set($message, $type);
        } catch (Exception $e) {
        } catch (Throwable $e) {
        }
    }
    public static function pluginOptions($options = null)
    {
        if ($options === null) {
            try {
                $options = Typecho_Widget::widget('Widget_Options');
            } catch (Exception $e) {
                return new AdminBeautify_MissingOptions();
            } catch (Throwable $e) {
                return new AdminBeautify_MissingOptions();
            }
        }
        try {
            return $options->plugin('AdminBeautify');
        } catch (Exception $e) {
            return new AdminBeautify_MissingOptions();
        } catch (Throwable $e) {
            return new AdminBeautify_MissingOptions();
        }
    }
    public static function savePluginOptions($pluginName, array $settings)
    {
        foreach (array('Widget\\Plugins\\Edit', 'Widget_Plugins_Edit') as $class) {
            if (!class_exists($class) || !method_exists($class, 'configPlugin')) continue;
            try {
                call_user_func(array($class, 'configPlugin'), $pluginName, $settings);
                return true;
            } catch (Exception $e) {
            } catch (Throwable $e) {
            }
        }
        return false;
    }
    public static function configCheck($settings)
    {
        if (!is_array($settings)) return '';
        $raw = isset($settings['dashboardCustomCards']) ? $settings['dashboardCustomCards'] : '';
        if (!is_string($raw) || $raw === '') return '';
        $cards = self::normalizeCards(json_decode($raw, true));
        if (empty($cards)) return '';
        $settings['dashboardCustomCards'] = self::slimCardsJson($cards);
        $warning = self::optionBlobWarning($settings);
        if ($warning === '') return '';
        return '⚠️ ' . $warning . '，本次设置不会保存，请删除部分卡片后再试。';
    }
    public static function prepareCardStorage(array &$settings, &$message)
    {
        $message = '';
        $raw = isset($settings['dashboardCustomCards']) ? $settings['dashboardCustomCards'] : '';
        if (!is_string($raw) || $raw === '') return true;
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) return true;
        $cards = self::normalizeCards($decoded);
        if (empty($cards)) {
            $clearDb = self::getDb();
            if ($clearDb && self::ensureCardTable()) {
                $clearError = '';
                self::writeCardCodes($clearDb, array(), $clearError);
            }
            return true;
        }
        $db = self::getDb();
        $canStore = $db ? self::ensureCardTable() : false;
        if (!$canStore) {
            $warning = self::optionBlobWarning($settings);
            if ($warning === '') return true;
            $message = '⚠️ ' . $warning . '，本次设置未保存。卡片代码需要存进数据表'
                . '（数据库账号要有建表 / 写表权限），或先删除部分卡片再试。';
            return false;
        }
        $rows = self::readCardCodeRows($db);
        if ($rows === null) {
            $message = '读取卡片代码失败（数据表暂时不可用），为避免把已存的代码写丢，本次设置未保存，请稍后重试。';
            return false;
        }
        self::hydrateCards($cards, $db, $rows);
        if (!self::writeCardCodes($db, $cards, $message)) {
            if ($message === '') $message = '卡片代码写入失败，设置未保存';
            return false;
        }
        $settings['dashboardCustomCards'] = self::slimCardsJson($cards);
        $warning = self::optionBlobWarning($settings);
        if ($warning !== '') {
            $message = '⚠️ ' . $warning . '，设置未保存：请删除部分卡片后重试。';
            return false;
        }
        return true;
    }
    public static function configHandle($settings, $isInit = false)
    {
        if (!is_array($settings) || empty($settings)) return false;
        $raw = isset($settings['dashboardCustomCards']) ? $settings['dashboardCustomCards'] : '';
        if (!is_string($raw)) $raw = '';
        if ($raw !== '') {
            $message = '';
            if (!self::prepareCardStorage($settings, $message)) {
                self::notice($message, 'error');
                return true;
            }
        }
        if (!self::savePluginOptions('AdminBeautify', $settings)) {
            self::notice('设置写入失败（Typecho 写库方法不可用），请重试。', 'error');
        }
        return true;
    }
    public static function hydrateCardValueForForm($raw)
    {
        $raw = (string) $raw;
        if ($raw === '') return $raw;
        $decoded = json_decode($raw, true);
        if (!is_array($decoded) || empty($decoded)) return $raw;
        $cards = self::normalizeCards($decoded);
        if (empty($cards)) return $raw;
        $db = self::getDb();
        if (!$db || !self::ensureCardTable()) return $raw;
        $rows = self::readCardCodeRows($db);
        if ($rows === null) return $raw;
        if (!self::hydrateCards($cards, $db, $rows)) return $raw;
        $needBackup = false;
        foreach ($cards as $card) {
            if ($card['html'] === '' && $card['js'] === '') continue;
            if (!isset($rows[self::cardCodeKey($card['id'], 'h')]) && !isset($rows[self::cardCodeKey($card['id'], 'j')])) {
                $needBackup = true;
                break;
            }
        }
        if ($needBackup) {
            $error = '';
            self::writeCardCodes($db, $cards, $error);
        }
        return (string) json_encode($cards, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    private static function normalizeCardDataKey($key)
    {
        $key = is_string($key) ? trim($key) : '';
        if ($key === '' || strlen($key) > self::CARD_KEY_MAX_LEN) return '';
        if (!preg_match('/^[A-Za-z0-9_-]+$/', $key)) return '';
        if (stripos($key, self::CARD_KEY_PREFIX) === 0) return '';
        if (stripos($key, self::CARD_CODE_KEY_PREFIX . '-') === 0) return '';
        return $key;
    }
    private static function validateCardContent($json)
    {
        if (!is_string($json)) return '内容必须为字符串';
        if ($json === '') return '内容不能为空';
        if (strlen($json) > self::CARD_CONTENT_MAX_BYTES) {
            return '内容超过上限（' . self::CARD_CONTENT_MAX_BYTES . ' 字节）';
        }
        json_decode($json, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return '内容不是合法的 JSON：' . (function_exists('json_last_error_msg') ? json_last_error_msg() : 'parse error');
        }
        return '';
    }
    public static function cardDataSave($key, $json, $scope = 'user')
    {
        $scope = self::normalizeCardScope($scope);
        $uid = self::currentUid();
        if ($uid <= 0) return array('error' => '未登录', 'code' => 401);
        $storeUid = ($scope === 'site') ? 0 : $uid;
        $key = self::normalizeCardDataKey($key);
        if ($key === '') {
            return array('error' => '数据键非法（只允许 A-Za-z0-9_-，长度 1~64，且不要带 card- 前缀）', 'code' => 400);
        }
        $err = self::validateCardContent($json);
        if ($err !== '') return array('error' => $err, 'code' => 400);
        $db = self::getDb();
        if (!$db) return array('error' => '数据库不可用', 'code' => 500);
        if (!self::ensureCardTable()) {
            return array('error' => '数据表不可用（请检查数据库账号是否具备建表权限）', 'code' => 500);
        }
        $fullKey = self::CARD_KEY_PREFIX . $key;
        $now = time();
        $created = null;
        $lastError = '';
        for ($attempt = 0; $attempt < 2 && $created === null; $attempt++) {
            try {
                $created = self::cardUpsertOnce($db, $storeUid, $fullKey, $json, $now);
            } catch (Exception $e) {
                $lastError = $e->getMessage();
            } catch (Throwable $e) {
                $lastError = $e->getMessage();
            }
        }
        if ($created === null) {
            return array('error' => '写入失败：' . $lastError, 'code' => 500);
        }
        return array(
            'key'        => $key,
            'full_key'   => $fullKey,
            'scope'      => $scope,
            'created'    => (bool) $created,
            'bytes'      => strlen($json),
            'updated_at' => $now,
        );
    }
    private static function cardUpsertOnce($db, $uid, $fullKey, $json, $now)
    {
        $row = $db->fetchRow(
            $db->select('id')
                ->from('table.' . self::CARD_TABLE)
                ->where('uid = ?', $uid)
                ->where('card_key = ?', $fullKey)
                ->limit(1)
        );
        if ($row) {
            $db->query(
                $db->update('table.' . self::CARD_TABLE)
                    ->rows(array('content' => $json, 'updated_at' => $now))
                    ->where('id = ?', (int) $row['id'])
            );
            return false;
        }
        $db->query(
            $db->insert('table.' . self::CARD_TABLE)
                ->rows(array(
                    'uid'        => $uid,
                    'card_key'   => $fullKey,
                    'content'    => $json,
                    'created_at' => $now,
                    'updated_at' => $now,
                ))
        );
        return true;
    }
    public static function cardDataGet($key, $scope = 'user')
    {
        $scope = self::normalizeCardScope($scope);
        $uid = self::currentUid();
        if ($uid <= 0) return array('error' => '未登录', 'code' => 401);
        $storeUid = ($scope === 'site') ? 0 : $uid;
        $key = self::normalizeCardDataKey($key);
        if ($key === '') {
            return array('error' => '数据键非法（只允许 A-Za-z0-9_-，长度 1~64）', 'code' => 400);
        }
        $db = self::getDb();
        if (!$db) return array('error' => '数据库不可用', 'code' => 500);
        if (!self::cardTableReady($db)) {
            return array('exists' => false, 'key' => $key, 'scope' => $scope, 'content' => null, 'json' => null, 'created_at' => 0, 'updated_at' => 0);
        }
        $fullKey = self::CARD_KEY_PREFIX . $key;
        try {
            $row = $db->fetchRow(
                $db->select('content', 'created_at', 'updated_at')
                    ->from('table.' . self::CARD_TABLE)
                    ->where('uid = ?', $storeUid)
                    ->where('card_key = ?', $fullKey)
                    ->limit(1)
            );
        } catch (Exception $e) {
            return array('error' => '读取失败：' . $e->getMessage(), 'code' => 500);
        } catch (Throwable $e) {
            return array('error' => '读取失败：' . $e->getMessage(), 'code' => 500);
        }
        if (!$row) {
            return array('exists' => false, 'key' => $key, 'scope' => $scope, 'content' => null, 'json' => null, 'created_at' => 0, 'updated_at' => 0);
        }
        $decoded = json_decode((string) $row['content'], true);
        return array(
            'exists'     => true,
            'key'        => $key,
            'scope'      => $scope,
            'content'    => (string) $row['content'],
            'json'       => (json_last_error() === JSON_ERROR_NONE) ? $decoded : null,
            'created_at' => (int) $row['created_at'],
            'updated_at' => (int) $row['updated_at'],
        );
    }
    public static function cardDataList($scope = 'user')
    {
        $scope = self::normalizeCardScope($scope);
        $uid = self::currentUid();
        if ($uid <= 0) return array('error' => '未登录', 'code' => 401);
        $storeUid = ($scope === 'site') ? 0 : $uid;
        $db = self::getDb();
        if (!$db) return array('error' => '数据库不可用', 'code' => 500);
        if (!self::cardTableReady($db)) {
            return array('items' => array(), 'count' => 0, 'scope' => $scope);
        }
        try {
            $rows = $db->fetchAll(
                $db->select('card_key', 'created_at', 'updated_at')
                    ->from('table.' . self::CARD_TABLE)
                    ->where('uid = ?', $storeUid)
                    ->where('card_key LIKE ?', self::CARD_KEY_PREFIX . '%')
                    ->where('card_key NOT LIKE ?', self::CARD_KEY_PREFIX . self::CARD_CODE_KEY_PREFIX . '-%')
                    ->order('updated_at', Typecho_Db::SORT_DESC)
                    ->order('id', Typecho_Db::SORT_DESC)
                    ->limit(self::DB_READ_MAX_LIMIT)
            );
        } catch (Exception $e) {
            return array('error' => '读取失败：' . $e->getMessage(), 'code' => 500);
        } catch (Throwable $e) {
            return array('error' => '读取失败：' . $e->getMessage(), 'code' => 500);
        }
        $items = array();
        foreach ((array) $rows as $row) {
            $items[] = array(
                'key'        => substr((string) $row['card_key'], strlen(self::CARD_KEY_PREFIX)),
                'created_at' => (int) $row['created_at'],
                'updated_at' => (int) $row['updated_at'],
            );
        }
        return array('items' => $items, 'count' => count($items), 'scope' => $scope);
    }
    public static function cardDataDelete($key, $scope = 'user')
    {
        $scope = self::normalizeCardScope($scope);
        $uid = self::currentUid();
        if ($uid <= 0) return array('error' => '未登录', 'code' => 401);
        $storeUid = ($scope === 'site') ? 0 : $uid;
        $key = self::normalizeCardDataKey($key);
        if ($key === '') {
            return array('error' => '数据键非法（只允许 A-Za-z0-9_-，长度 1~64）', 'code' => 400);
        }
        $db = self::getDb();
        if (!$db) return array('error' => '数据库不可用', 'code' => 500);
        if (!self::cardTableReady($db)) {
            return array('deleted' => 0, 'key' => $key, 'scope' => $scope);
        }
        try {
            $deleted = (int) $db->query(
                $db->delete('table.' . self::CARD_TABLE)
                    ->where('uid = ?', $storeUid)
                    ->where('card_key = ?', self::CARD_KEY_PREFIX . $key)
            );
        } catch (Exception $e) {
            return array('error' => '删除失败：' . $e->getMessage(), 'code' => 500);
        } catch (Throwable $e) {
            return array('error' => '删除失败：' . $e->getMessage(), 'code' => 500);
        }
        return array('deleted' => $deleted, 'key' => $key, 'scope' => $scope);
    }
    private static function normalizeCardScope($scope)
    {
        return (strtolower(trim((string) $scope)) === 'site') ? 'site' : 'user';
    }
    const NOTICE_KEY_PREFIX = 'notice-';
    const NOTICE_MAX_ROWS = 200;
    const NOTICE_DELETED_TTL = 2592000;
    const NOTICE_TITLE_MAX = 120;
    const NOTICE_BODY_MAX = 500;
    const NOTICE_DETAIL_MAX = 8000;
    const NOTICE_PAGE_MAX = 50;
    private static $noticeLevels = array('info', 'success', 'warn', 'error');
    public static function pushNotice($title, $body = '', $level = 'info', array $opt = array())
    {
        $title = self::noticeText($title, self::NOTICE_TITLE_MAX);
        if ($title === '') return array('error' => '通知标题不能为空', 'code' => 400);
        $body = self::noticeText($body, self::NOTICE_BODY_MAX);
        $detail = isset($opt['detail']) ? self::noticeText($opt['detail'], self::NOTICE_DETAIL_MAX) : '';
        $level = strtolower(trim((string) $level));
        if (!in_array($level, self::$noticeLevels, true)) $level = 'info';
        $uid = isset($opt['uid']) ? (int) $opt['uid'] : self::currentUid();
        if ($uid <= 0) return array('error' => '未登录', 'code' => 401);
        $ts = isset($opt['ts']) ? (int) $opt['ts'] : time();
        if ($ts <= 0) $ts = time();
        $db = self::getDb();
        if (!$db) return array('error' => '数据库不可用', 'code' => 500);
        if (!self::ensureCardTable()) {
            return array('error' => '数据表不可用（请检查数据库账号是否具备建表权限）', 'code' => 500);
        }
        $dedup = isset($opt['dedup']) && (string) $opt['dedup'] !== ''
            ? (string) $opt['dedup']
            : ($level . '|' . $title . '|' . $body);
        $key = self::NOTICE_KEY_PREFIX . substr(md5($dedup), 0, 12) . '-' . date('Ymd', $ts);
        $payload = array(
            'v'     => 1,
            'lv'    => $level,
            'title' => $title,
            'body'  => $body,
            'link'  => isset($opt['link']) ? (string) $opt['link'] : '',
            'src'   => isset($opt['src']) ? self::noticeText($opt['src'], 40) : '',
            'act'   => isset($opt['act']) ? self::noticeText($opt['act'], 24) : '',
            'state' => 0,
            'ts'    => $ts,
            'rd'    => 0,
            'n'     => 1,
            'day'   => date('Ymd', $ts),
        );
        if ($detail !== '') $payload['detail'] = $detail;
        $result = null;
        $lastError = '';
        for ($attempt = 0; $attempt < 2 && $result === null; $attempt++) {
            try {
                $result = self::noticeUpsertOnce(
                    $db,
                    $uid,
                    $key,
                    $payload,
                    !empty($opt['rearm'])
                );
            } catch (Exception $e) {
                $lastError = $e->getMessage();
            } catch (Throwable $e) {
                $lastError = $e->getMessage();
            }
        }
        if ($result === null) {
            return array('error' => '写入失败：' . $lastError, 'code' => 500);
        }
        self::noticePrune($db, $uid);
        return $result;
    }
    private static function noticeUpsertOnce($db, $uid, $key, array $payload, $rearm = false)
    {
        $row = $db->fetchRow(
            $db->select('id', 'content', 'created_at')
                ->from('table.' . self::CARD_TABLE)
                ->where('uid = ?', $uid)
                ->where('card_key = ?', $key)
                ->limit(1)
        );
        $now = time();
        if ($row) {
            $old = json_decode((string) $row['content'], true);
            if (!is_array($old)) $old = array();
            $merged = array_merge($payload, array(
                'state' => $rearm ? 0 : (isset($old['state']) ? (int) $old['state'] : 0),
                'rd'    => $rearm ? 0 : (isset($old['rd']) ? (int) $old['rd'] : 0),
                'ts'    => isset($old['ts']) ? (int) $old['ts'] : (int) $row['created_at'],
                'n'     => (isset($old['n']) ? (int) $old['n'] : 1) + 1,
                'link'  => isset($old['link']) && $old['link'] !== '' ? $old['link'] : $payload['link'],
            ));
            if (!isset($payload['detail']) && isset($old['detail'])) $merged['detail'] = $old['detail'];
            $db->query(
                $db->update('table.' . self::CARD_TABLE)
                    ->rows(array(
                        'content'    => self::noticeJson($merged),
                        'updated_at' => $now,
                    ))
                    ->where('id = ?', (int) $row['id'])
            );
            return array('id' => (int) $row['id'], 'created' => false, 'counted' => (int) $merged['n']);
        }
        $db->query(
            $db->insert('table.' . self::CARD_TABLE)
                ->rows(array(
                    'uid'        => $uid,
                    'card_key'   => $key,
                    'content'    => self::noticeJson($payload),
                    'created_at' => $payload['ts'],
                    'updated_at' => $now,
                ))
        );
        $id = 0;
        $row = $db->fetchRow(
            $db->select('id')
                ->from('table.' . self::CARD_TABLE)
                ->where('uid = ?', $uid)
                ->where('card_key = ?', $key)
                ->limit(1)
        );
        if ($row) $id = (int) $row['id'];
        return array('id' => $id, 'created' => true, 'counted' => 1);
    }
    public static function noticeDetail($id)
    {
        $uid = self::currentUid();
        if ($uid <= 0) return array('error' => '未登录', 'code' => 401);
        $id = (int) $id;
        if ($id <= 0) return array('error' => '通知不存在', 'code' => 404);
        $db = self::getDb();
        if (!$db) return array('error' => '数据库不可用', 'code' => 500);
        if (!self::cardTableReady($db)) return array('error' => '数据表不可用', 'code' => 500);
        try {
            $row = $db->fetchRow(
                $db->select('id', 'content', 'created_at', 'updated_at')
                    ->from('table.' . self::CARD_TABLE)
                    ->where('uid = ?', $uid)
                    ->where('id = ?', $id)
                    ->where('card_key LIKE ?', self::NOTICE_KEY_PREFIX . '%')
                    ->limit(1)
            );
        } catch (Exception $e) {
            return array('error' => '读取失败：' . $e->getMessage(), 'code' => 500);
        } catch (Throwable $e) {
            return array('error' => '读取失败：' . $e->getMessage(), 'code' => 500);
        }
        if (!$row) return array('error' => '通知不存在', 'code' => 404);
        $data = json_decode((string) $row['content'], true);
        $item = self::noticeRowItem($row);
        $item['detail'] = (is_array($data) && isset($data['detail'])) ? (string) $data['detail'] : '';
        $item['md'] = ($item['detail'] !== '') ? $item['detail'] : $item['body'];
        return $item;
    }
    public static function noticeList($state = 'all', $limit = 30, $offset = 0)
    {
        $uid = self::currentUid();
        if ($uid <= 0) return array('error' => '未登录', 'code' => 401);
        $state = self::noticeStateName($state);
        $limit = (int) $limit;
        if ($limit < 0) $limit = 0;
        if ($limit > self::NOTICE_PAGE_MAX) $limit = self::NOTICE_PAGE_MAX;
        $offset = max(0, (int) $offset);
        $db = self::getDb();
        if (!$db) return array('error' => '数据库不可用', 'code' => 500);
        $empty = array('items' => array(), 'state' => $state, 'hasMore' => false,
                       'counts' => array('unread' => 0, 'read' => 0, 'deleted' => 0, 'all' => 0));
        if (!self::cardTableReady($db)) return $empty;
        try {
            $items = array();
            if ($limit > 0) {
                $rows = $db->fetchAll(
                    self::noticeBaseQuery($db, $uid, $state)
                        ->order('updated_at', Typecho_Db::SORT_DESC)
                        ->order('id', Typecho_Db::SORT_DESC)
                        ->limit($limit)
                        ->offset($offset)
                );
                foreach ((array) $rows as $row) $items[] = self::noticeRowItem($row);
                $hasMore = count($items) === $limit;
            } else {
                $hasMore = false;
            }
            $counts = self::noticeCounts($db, $uid);
        } catch (Exception $e) {
            return array('error' => '读取失败：' . $e->getMessage(), 'code' => 500);
        } catch (Throwable $e) {
            return array('error' => '读取失败：' . $e->getMessage(), 'code' => 500);
        }
        return array('items' => $items, 'state' => $state, 'hasMore' => $hasMore, 'counts' => $counts);
    }
    public static function noticeCount()
    {
        $uid = self::currentUid();
        if ($uid <= 0) return array('error' => '未登录', 'code' => 401);
        $db = self::getDb();
        if (!$db) return array('error' => '数据库不可用', 'code' => 500);
        if (!self::cardTableReady($db)) return array('unread' => 0, 'counts' => array('unread' => 0, 'read' => 0, 'deleted' => 0, 'all' => 0));
        try {
            $counts = self::noticeCounts($db, $uid);
        } catch (Exception $e) {
            return array('error' => '读取失败：' . $e->getMessage(), 'code' => 500);
        } catch (Throwable $e) {
            return array('error' => '读取失败：' . $e->getMessage(), 'code' => 500);
        }
        return array('unread' => $counts['unread'], 'counts' => $counts);
    }
    public static function noticeSetState($ids, $state)
    {
        $uid = self::currentUid();
        if ($uid <= 0) return array('error' => '未登录', 'code' => 401);
        $newState = self::noticeStateValue($state);
        if ($newState === null) return array('error' => '状态非法', 'code' => 400);
        $db = self::getDb();
        if (!$db) return array('error' => '数据库不可用', 'code' => 500);
        if (!self::cardTableReady($db)) return array('updated' => 0, 'state' => $newState);
        $elapsed = time();
        try {
            if ($ids === 'all' || $ids === null) {
                $list = $db->fetchAll(self::noticeBaseQuery($db, $uid, 'all'));
            } else {
                $clean = array();
                foreach ((array) $ids as $one) {
                    $one = (int) $one;
                    if ($one > 0) $clean[] = $one;
                }
                $clean = array_values(array_unique($clean));
                if (empty($clean)) return array('updated' => 0, 'state' => $newState);
                $list = $db->fetchAll(
                    $db->select('id', 'content')
                        ->from('table.' . self::CARD_TABLE)
                        ->where('uid = ?', $uid)
                        ->where('id IN ?', $clean)
                        ->where('card_key LIKE ?', self::NOTICE_KEY_PREFIX . '%')
                );
            }
            $updated = 0;
            foreach ((array) $list as $row) {
                $data = json_decode((string) $row['content'], true);
                if (!is_array($data)) continue;
                $cur = isset($data['state']) ? (int) $data['state'] : 0;
                if ($cur === $newState) continue;
                $data['state'] = $newState;
                if ($newState === 1 && empty($data['rd'])) $data['rd'] = $elapsed;
                $db->query(
                    $db->update('table.' . self::CARD_TABLE)
                        ->rows(array('content' => self::noticeJson($data), 'updated_at' => $elapsed))
                        ->where('uid = ?', $uid)
                        ->where('id = ?', (int) $row['id'])
                );
                $updated++;
            }
        } catch (Exception $e) {
            return array('error' => '更新失败：' . $e->getMessage(), 'code' => 500);
        } catch (Throwable $e) {
            return array('error' => '更新失败：' . $e->getMessage(), 'code' => 500);
        }
        return array('updated' => $updated, 'state' => $newState);
    }
    public static function noticeClearRead()
    {
        return self::noticeSetState(self::noticeIdsByState(1), 2);
    }
    public static function noticePurgeDeleted()
    {
        $uid = self::currentUid();
        if ($uid <= 0) return array('error' => '未登录', 'code' => 401);
        $db = self::getDb();
        if (!$db) return array('error' => '数据库不可用', 'code' => 500);
        if (!self::cardTableReady($db)) return array('deleted' => 0);
        $ids = self::noticeIdsByState(2);
        if (empty($ids)) return array('deleted' => 0);
        try {
            $deleted = (int) $db->query(
                $db->delete('table.' . self::CARD_TABLE)
                    ->where('uid = ?', $uid)
                    ->where('id IN ?', $ids)
            );
        } catch (Exception $e) {
            return array('error' => '删除失败：' . $e->getMessage(), 'code' => 500);
        } catch (Throwable $e) {
            return array('error' => '删除失败：' . $e->getMessage(), 'code' => 500);
        }
        return array('deleted' => $deleted);
    }
    private static function noticeIdsByState($state)
    {
        $uid = self::currentUid();
        if ($uid <= 0) return array();
        $db = self::getDb();
        if (!$db || !self::cardTableReady($db)) return array();
        try {
            $rows = $db->fetchAll(self::noticeBaseQuery($db, $uid, self::noticeStateName($state)));
        } catch (Exception $e) {
            return array();
        } catch (Throwable $e) {
            return array();
        }
        $ids = array();
        foreach ((array) $rows as $row) $ids[] = (int) $row['id'];
        return $ids;
    }
    private static function noticeBaseQuery($db, $uid, $state)
    {
        $q = $db->select('id', 'content', 'created_at', 'updated_at')
            ->from('table.' . self::CARD_TABLE)
            ->where('uid = ?', $uid)
            ->where('card_key LIKE ?', self::NOTICE_KEY_PREFIX . '%');
        $state = self::noticeStateName($state);
        if ($state !== 'all') {
            $q->where('content LIKE ?', '%"state":' . self::noticeStateValue($state) . ',%');
        } else {
            $q->where('content NOT LIKE ?', '%"state":2,%');
        }
        return $q;
    }
    private static function noticeCounts($db, $uid)
    {
        $out = array('unread' => 0, 'read' => 0, 'deleted' => 0, 'all' => 0);
        foreach (array('unread' => 0, 'read' => 1, 'deleted' => 2) as $name => $val) {
            $row = $db->fetchRow(
                $db->select(array('COUNT(*)' => 'num'))
                    ->from('table.' . self::CARD_TABLE)
                    ->where('uid = ?', $uid)
                    ->where('card_key LIKE ?', self::NOTICE_KEY_PREFIX . '%')
                    ->where('content LIKE ?', '%"state":' . $val . ',%')
            );
            $out[$name] = isset($row['num']) ? (int) $row['num'] : 0;
        }
        $out['all'] = $out['unread'] + $out['read'] + $out['deleted'];
        return $out;
    }
    private static function noticePrune($db, $uid)
    {
        try {
            $deadline = time() - self::NOTICE_DELETED_TTL;
            $rows = $db->fetchAll(self::noticeBaseQuery($db, $uid, 'deleted'));
            $expired = array();
            foreach ((array) $rows as $row) {
                $t = max((int) $row['updated_at'], (int) $row['created_at']);
                if ($t > 0 && $t < $deadline) $expired[] = (int) $row['id'];
            }
            if (!empty($expired)) {
                $db->query($db->delete('table.' . self::CARD_TABLE)->where('uid = ?', $uid)->where('id IN ?', $expired));
            }
            $row = $db->fetchRow(
                $db->select(array('COUNT(*)' => 'num'))
                    ->from('table.' . self::CARD_TABLE)
                    ->where('uid = ?', $uid)
                    ->where('card_key LIKE ?', self::NOTICE_KEY_PREFIX . '%')
            );
            $total = isset($row['num']) ? (int) $row['num'] : 0;
            $over = $total - self::NOTICE_MAX_ROWS;
            if ($over > 0) {
                $old = $db->fetchAll(
                    self::noticeBaseQuery($db, $uid, 'all')
                        ->order('updated_at', Typecho_Db::SORT_ASC)
                        ->order('id', Typecho_Db::SORT_ASC)
                        ->limit($over)
                );
                $ids = array();
                foreach ((array) $old as $r) $ids[] = (int) $r['id'];
                if (!empty($ids)) {
                    $db->query($db->delete('table.' . self::CARD_TABLE)->where('uid = ?', $uid)->where('id IN ?', $ids));
                }
            }
        } catch (Exception $e) {
        } catch (Throwable $e) {
        }
    }
    private static function noticeRowItem($row)
    {
        $data = json_decode((string) $row['content'], true);
        if (!is_array($data)) $data = array();
        $ts = isset($data['ts']) ? (int) $data['ts'] : (int) $row['created_at'];
        if ($ts <= 0) $ts = (int) $row['created_at'];
        return array(
            'id'      => (int) $row['id'],
            'lv'      => isset($data['lv']) ? (string) $data['lv'] : 'info',
            'title'   => isset($data['title']) ? (string) $data['title'] : '',
            'body'    => isset($data['body']) ? (string) $data['body'] : '',
            'link'    => isset($data['link']) ? (string) $data['link'] : '',
            'src'     => isset($data['src']) ? (string) $data['src'] : '',
            'act'     => isset($data['act']) ? (string) $data['act'] : '',
            'state'   => isset($data['state']) ? (int) $data['state'] : 0,
            'ts'      => $ts,
            'rd'      => isset($data['rd']) ? (int) $data['rd'] : 0,
            'n'       => isset($data['n']) ? (int) $data['n'] : 1,
            'hasDetail' => !empty($data['detail']),
            'updated' => (int) $row['updated_at'],
        );
    }
    private static function noticeStateValue($state)
    {
        if (is_int($state) || (is_string($state) && ctype_digit($state))) {
            $state = (int) $state;
            return in_array($state, array(0, 1, 2), true) ? $state : null;
        }
        $map = array('unread' => 0, 'read' => 1, 'deleted' => 2);
        $key = strtolower(trim((string) $state));
        return isset($map[$key]) ? $map[$key] : null;
    }
    private static function noticeStateName($state)
    {
        if (is_string($state)) {
            $key = strtolower(trim($state));
            if (in_array($key, array('all', 'unread', 'read', 'deleted'), true)) return $key;
        }
        $val = self::noticeStateValue($state);
        if ($val === null) return 'all';
        return array(0 => 'unread', 1 => 'read', 2 => 'deleted')[$val];
    }
    private static function noticeText($text, $max)
    {
        $text = str_replace(array("\r\n", "\r"), "\n", (string) $text);
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text);
        if ($text === null) $text = '';
        $text = trim($text);
        if (function_exists('mb_substr')) {
            if (mb_strlen($text, 'UTF-8') > $max) $text = mb_substr($text, 0, $max, 'UTF-8') . '…';
        } elseif (strlen($text) > $max) {
            $text = substr($text, 0, $max) . '…';
        }
        return $text;
    }
    private static function noticeJson(array $data)
    {
        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return ($json === false) ? '{}' : $json;
    }
    private static function isDeniedDbColumn($column)
    {
        $normalized = strtolower(preg_replace('/[^A-Za-z0-9]/', '', (string) $column));
        if ($normalized === '') return true;
        foreach (self::$dbReadDenyColumns as $deny) {
            if (strpos($normalized, $deny) !== false) return true;
        }
        return false;
    }
    private static function sanitizeDbValue($value)
    {
        if (!is_string($value) || $value === '') return $value;
        if (!preg_match('//u', $value)) {
            return '[binary data: ' . strlen($value) . ' bytes]';
        }
        if (strlen($value) > self::DB_READ_MAX_VALUE_BYTES) {
            return substr($value, 0, self::DB_READ_MAX_VALUE_BYTES) . '…[truncated]';
        }
        return $value;
    }
    public static function dbReadTable($table, $query)
    {
        $uid = self::currentUid();
        if ($uid <= 0) return array('error' => '未登录', 'code' => 401);
        $db = self::getDb();
        if (!$db) return array('error' => '数据库不可用', 'code' => 500);
        $table = is_string($table) ? strtolower(trim($table)) : '';
        $prefix = strtolower(preg_replace('/[^A-Za-z0-9_]/', '', (string) $db->getPrefix()));
        if ($prefix !== '' && strpos($table, $prefix) === 0) {
            $table = substr($table, strlen($prefix));
        }
        if ($table === '' || !preg_match('/^[a-z0-9_]{1,64}$/', $table)) {
            return array('error' => '表名非法（只允许字母 / 数字 / 下划线，且不要带站点前缀）', 'code' => 400);
        }
        if (in_array($table, self::$dbReadDenyTables, true)) {
            return array('error' => '禁止读取该表：' . $table, 'code' => 403);
        }
        $query = is_array($query) ? $query : array();
        $columns = isset($query['columns']) ? $query['columns'] : array('*');
        if (is_string($columns)) $columns = array($columns);
        if (!is_array($columns) || empty($columns)) $columns = array('*');
        $cleanColumns = array();
        foreach ($columns as $col) {
            $col = is_string($col) ? trim($col) : '';
            if ($col === '*') {
                $cleanColumns = array('*');
                break;
            }
            if (!preg_match('/^[A-Za-z0-9_]{1,64}$/', $col)) {
                return array('error' => '列名非法：' . $col, 'code' => 400);
            }
            if (self::isDeniedDbColumn($col)) {
                return array('error' => '禁止读取该列：' . $col, 'code' => 403);
            }
            $cleanColumns[] = $col;
        }
        if (empty($cleanColumns)) $cleanColumns = array('*');
        $where = isset($query['where']) ? $query['where'] : array();
        if (is_array($where) && isset($where['field'])) $where = array($where);
        if (!is_array($where)) $where = array();
        $cleanWhere = array();
        foreach ($where as $cond) {
            if (!is_array($cond)) {
                return array('error' => 'where 条件格式错误（应为 {field,op,value}）', 'code' => 400);
            }
            $field = isset($cond['field']) ? (string) $cond['field'] : '';
            if (!preg_match('/^[A-Za-z0-9_]{1,64}$/', $field)) {
                return array('error' => 'where 字段非法：' . $field, 'code' => 400);
            }
            if (self::isDeniedDbColumn($field)) {
                return array('error' => '禁止按该列查询：' . $field, 'code' => 403);
            }
            $op = strtoupper(trim(isset($cond['op']) ? (string) $cond['op'] : '='));
            $op = preg_replace('/\s+/', ' ', $op);
            if (!in_array($op, self::$dbReadOperators, true)) {
                return array('error' => '不支持的查询操作符：' . $op, 'code' => 400);
            }
            $value = isset($cond['value']) ? $cond['value'] : null;
            if ($op === 'IN' || $op === 'NOT IN') {
                if (!is_array($value) || empty($value)) {
                    return array('error' => $op . ' 查询需要一个非空数组作为 value', 'code' => 400);
                }
                if (count($value) > 100) {
                    return array('error' => $op . ' 查询条件过多（上限 100）', 'code' => 400);
                }
                $vals = array();
                foreach ($value as $v) {
                    if (is_array($v) || is_object($v)) {
                        return array('error' => 'IN 查询的值必须是标量', 'code' => 400);
                    }
                    $vals[] = is_bool($v) ? (int) $v : $v;
                }
                $value = $vals;
            } elseif (is_array($value) || is_object($value)) {
                return array('error' => '查询值必须是标量', 'code' => 400);
            }
            $cleanWhere[] = array('field' => $field, 'op' => $op, 'value' => $value);
        }
        $orderBy = isset($query['orderBy']) ? $query['orderBy'] : null;
        $orderField = '';
        $orderDir = 'ASC';
        if (is_array($orderBy) && !empty($orderBy)) {
            $orderField = isset($orderBy['field']) ? (string) $orderBy['field'] : '';
            $dir = strtoupper(trim(isset($orderBy['dir']) ? (string) $orderBy['dir'] : 'ASC'));
            $orderDir = ($dir === 'DESC') ? 'DESC' : 'ASC';
        } elseif (is_string($orderBy) && trim($orderBy) !== '') {
            $orderField = trim($orderBy);
        }
        if ($orderField !== '') {
            if (!preg_match('/^[A-Za-z0-9_]{1,64}$/', $orderField)) {
                return array('error' => '排序字段非法：' . $orderField, 'code' => 400);
            }
            if (self::isDeniedDbColumn($orderField)) {
                return array('error' => '禁止按该列排序：' . $orderField, 'code' => 403);
            }
        }
        $limit = isset($query['limit']) ? (int) $query['limit'] : self::DB_READ_DEFAULT_LIMIT;
        if ($limit <= 0) $limit = self::DB_READ_DEFAULT_LIMIT;
        if ($limit > self::DB_READ_MAX_LIMIT) $limit = self::DB_READ_MAX_LIMIT;
        $offset = isset($query['offset']) ? (int) $query['offset'] : 0;
        if ($offset < 0) $offset = 0;
        try {
            $q = call_user_func_array(array($db, 'select'), $cleanColumns)->from('table.' . $table);
            foreach ($cleanWhere as $c) {
                $q->where($c['field'] . ' ' . $c['op'] . ' ?', $c['value']);
            }
            if ($orderField !== '') {
                $q->order($orderField, $orderDir === 'DESC' ? Typecho_Db::SORT_DESC : Typecho_Db::SORT_ASC);
            }
            $q->limit($limit)->offset($offset);
            $rows = $db->fetchAll($q);
        } catch (Exception $e) {
            return array('error' => '查询失败：' . $e->getMessage(), 'code' => 500);
        } catch (Throwable $e) {
            return array('error' => '查询失败：' . $e->getMessage(), 'code' => 500);
        }
        $data = array();
        $returnedColumns = array();
        foreach ((array) $rows as $row) {
            $item = array();
            foreach ((array) $row as $k => $v) {
                if (self::isDeniedDbColumn($k)) continue;
                $item[$k] = self::sanitizeDbValue($v);
            }
            if (empty($returnedColumns)) $returnedColumns = array_keys($item);
            $data[] = $item;
        }
        if (empty($returnedColumns)) $returnedColumns = $cleanColumns;
        return array(
            'table'   => $table,
            'columns' => $returnedColumns,
            'rows'    => $data,
            'count'   => count($data),
            'limit'   => $limit,
            'offset'  => $offset,
        );
    }
    private static function getColorScheme($scheme)
    {
        $schemes = array(
            'purple' => array(
                '--md-primary'           => '#7D5260',
                '--md-on-primary'        => '#FFFFFF',
                '--md-primary-container' => '#FFD8E4',
                '--md-on-primary-container' => '#21005D',
                '--md-secondary'         => '#625B71',
                '--md-on-secondary'      => '#FFFFFF',
                '--md-secondary-container' => '#E8DEF8',
                '--md-on-secondary-container' => '#1D192B',
                '--md-tertiary'          => '#7D5260',
                '--md-surface'           => '#FFFBFE',
                '--md-surface-dim'       => '#DED8E1',
                '--md-surface-bright'    => '#FFFBFE',
                '--md-surface-container-lowest'  => '#FFFFFF',
                '--md-surface-container-low'     => '#F7F2FA',
                '--md-surface-container'         => '#F3EDF7',
                '--md-surface-container-high'    => '#ECE6F0',
                '--md-surface-container-highest' => '#E6E0E9',
                '--md-on-surface'        => '#1C1B1F',
                '--md-on-surface-variant' => '#49454F',
                '--md-outline'           => '#79747E',
                '--md-outline-variant'   => '#CAC4D0',
                '--md-error'             => '#B3261E',
                '--md-on-error'          => '#FFFFFF',
                '--md-error-container'   => '#F9DEDC',
                '--md-on-error-container' => '#410E0B',
                '--md-dark-primary'           => '#D0BCFF',
                '--md-dark-on-primary'        => '#381E72',
                '--md-dark-primary-container' => '#4F378B',
                '--md-dark-on-primary-container' => '#EADDFF',
                '--md-dark-secondary'         => '#CCC2DC',
                '--md-dark-tertiary'       => '#DEB0BF',
                '--md-dark-surface'           => '#1C1B1F',
                '--md-dark-surface-dim'       => '#1C1B1F',
                '--md-dark-surface-bright'    => '#3B383E',
                '--md-dark-surface-container-lowest'  => '#0F0D13',
                '--md-dark-surface-container-low'     => '#211F26',
                '--md-dark-surface-container'         => '#2B2930',
                '--md-dark-surface-container-high'    => '#36343B',
                '--md-dark-surface-container-highest' => '#484649',
                '--md-dark-on-surface'        => '#E6E1E5',
                '--md-dark-on-surface-variant' => '#CAC4D0',
                '--md-dark-outline'           => '#938F99',
                '--md-dark-outline-variant'   => '#49454F',
                '--md-dark-error'             => '#F2B8B5',
            ),
            'blue' => array(
                '--md-primary'           => '#556270',
                '--md-on-primary'        => '#FFFFFF',
                '--md-primary-container' => '#D9E2FF',
                '--md-on-primary-container' => '#001A41',
                '--md-secondary'         => '#565E71',
                '--md-on-secondary'      => '#FFFFFF',
                '--md-secondary-container' => '#DAE2F9',
                '--md-on-secondary-container' => '#131C2B',
                '--md-tertiary'          => '#715573',
                '--md-surface'           => '#FDFBFF',
                '--md-surface-dim'       => '#DBD9DD',
                '--md-surface-bright'    => '#FDFBFF',
                '--md-surface-container-lowest'  => '#FFFFFF',
                '--md-surface-container-low'     => '#F5F3F7',
                '--md-surface-container'         => '#EFEDF1',
                '--md-surface-container-high'    => '#EAE7EC',
                '--md-surface-container-highest' => '#E4E2E6',
                '--md-on-surface'        => '#1B1B1F',
                '--md-on-surface-variant' => '#44474F',
                '--md-outline'           => '#74777F',
                '--md-outline-variant'   => '#C4C6D0',
                '--md-error'             => '#BA1A1A',
                '--md-on-error'          => '#FFFFFF',
                '--md-error-container'   => '#FFDAD6',
                '--md-on-error-container' => '#410E0B',
                '--md-dark-primary'           => '#ADC6FF',
                '--md-dark-on-primary'        => '#002E69',
                '--md-dark-primary-container' => '#004494',
                '--md-dark-on-primary-container' => '#D8E2FF',
                '--md-dark-secondary'         => '#BEC6DC',
                '--md-dark-tertiary'       => '#DAB1DD',
                '--md-dark-surface'           => '#1B1B1F',
                '--md-dark-surface-dim'       => '#1B1B1F',
                '--md-dark-surface-bright'    => '#3A3A3F',
                '--md-dark-surface-container-lowest'  => '#0E0E13',
                '--md-dark-surface-container-low'     => '#1F1F24',
                '--md-dark-surface-container'         => '#2A2A2F',
                '--md-dark-surface-container-high'    => '#35353A',
                '--md-dark-surface-container-highest' => '#464649',
                '--md-dark-on-surface'        => '#E4E2E6',
                '--md-dark-on-surface-variant' => '#C4C6D0',
                '--md-dark-outline'           => '#8E9099',
                '--md-dark-outline-variant'   => '#44474F',
                '--md-dark-error'             => '#FFB4AB',
            ),
            'teal' => array(
                '--md-primary'           => '#4A6363',
                '--md-on-primary'        => '#FFFFFF',
                '--md-primary-container' => '#CCE8E7',
                '--md-on-primary-container' => '#002020',
                '--md-secondary'         => '#4A6363',
                '--md-on-secondary'      => '#FFFFFF',
                '--md-secondary-container' => '#CCE8E7',
                '--md-on-secondary-container' => '#051F1F',
                '--md-tertiary'          => '#4B607C',
                '--md-surface'           => '#FAFDFC',
                '--md-surface-dim'       => '#DBE4E3',
                '--md-surface-bright'    => '#FAFDFC',
                '--md-surface-container-lowest'  => '#FFFFFF',
                '--md-surface-container-low'     => '#F2FAF9',
                '--md-surface-container'         => '#EDF5F3',
                '--md-surface-container-high'    => '#E7EFEE',
                '--md-surface-container-highest' => '#E1E9E8',
                '--md-on-surface'        => '#191C1C',
                '--md-on-surface-variant' => '#3F4948',
                '--md-outline'           => '#6F7979',
                '--md-outline-variant'   => '#BEC9C8',
                '--md-error'             => '#BA1A1A',
                '--md-on-error'          => '#FFFFFF',
                '--md-error-container'   => '#FFDAD6',
                '--md-on-error-container' => '#410E0B',
                '--md-dark-primary'           => '#4CDADA',
                '--md-dark-on-primary'        => '#003737',
                '--md-dark-primary-container' => '#004F50',
                '--md-dark-on-primary-container' => '#6FF7F6',
                '--md-dark-secondary'         => '#B0CCCB',
                '--md-dark-tertiary'       => '#B1C4DD',
                '--md-dark-surface'           => '#191C1C',
                '--md-dark-surface-dim'       => '#191C1C',
                '--md-dark-surface-bright'    => '#3A3D3D',
                '--md-dark-surface-container-lowest'  => '#0C0F0F',
                '--md-dark-surface-container-low'     => '#1F2222',
                '--md-dark-surface-container'         => '#2A2D2D',
                '--md-dark-surface-container-high'    => '#353838',
                '--md-dark-surface-container-highest' => '#464949',
                '--md-dark-on-surface'        => '#E1E9E8',
                '--md-dark-on-surface-variant' => '#BEC9C8',
                '--md-dark-outline'           => '#899392',
                '--md-dark-outline-variant'   => '#3F4948',
                '--md-dark-error'             => '#FFB4AB',
            ),
            'green' => array(
                '--md-primary'           => '#55624C',
                '--md-on-primary'        => '#FFFFFF',
                '--md-primary-container' => '#D9E7CB',
                '--md-on-primary-container' => '#042100',
                '--md-secondary'         => '#55624C',
                '--md-on-secondary'      => '#FFFFFF',
                '--md-secondary-container' => '#D9E7CB',
                '--md-on-secondary-container' => '#131F0D',
                '--md-tertiary'          => '#386666',
                '--md-surface'           => '#FDFDF5',
                '--md-surface-dim'       => '#DBDBD4',
                '--md-surface-bright'    => '#FDFDF5',
                '--md-surface-container-lowest'  => '#FFFFFF',
                '--md-surface-container-low'     => '#F5F5ED',
                '--md-surface-container'         => '#F0F0E8',
                '--md-surface-container-high'    => '#EAEAE2',
                '--md-surface-container-highest' => '#E4E4DD',
                '--md-on-surface'        => '#1A1C18',
                '--md-on-surface-variant' => '#44483E',
                '--md-outline'           => '#74796D',
                '--md-outline-variant'   => '#C4C8BB',
                '--md-error'             => '#BA1A1A',
                '--md-on-error'          => '#FFFFFF',
                '--md-error-container'   => '#FFDAD6',
                '--md-on-error-container' => '#410E0B',
                '--md-dark-primary'           => '#9CD67D',
                '--md-dark-on-primary'        => '#0E3900',
                '--md-dark-primary-container' => '#215107',
                '--md-dark-on-primary-container' => '#B7F397',
                '--md-dark-secondary'         => '#BDC9B0',
                '--md-dark-tertiary'       => '#B6D8D8',
                '--md-dark-surface'           => '#1A1C18',
                '--md-dark-surface-dim'       => '#1A1C18',
                '--md-dark-surface-bright'    => '#3A3D36',
                '--md-dark-surface-container-lowest'  => '#0D0F0B',
                '--md-dark-surface-container-low'     => '#1F2220',
                '--md-dark-surface-container'         => '#2A2D28',
                '--md-dark-surface-container-high'    => '#353833',
                '--md-dark-surface-container-highest' => '#464944',
                '--md-dark-on-surface'        => '#E4E4DD',
                '--md-dark-on-surface-variant' => '#C4C8BB',
                '--md-dark-outline'           => '#8E9285',
                '--md-dark-outline-variant'   => '#44483E',
                '--md-dark-error'             => '#FFB4AB',
            ),
            'orange' => array(
                '--md-primary'           => '#725A42',
                '--md-on-primary'        => '#FFFFFF',
                '--md-primary-container' => '#FFDCBE',
                '--md-on-primary-container' => '#2C1600',
                '--md-secondary'         => '#725A42',
                '--md-on-secondary'      => '#FFFFFF',
                '--md-secondary-container' => '#FDDDBF',
                '--md-on-secondary-container' => '#2A1706',
                '--md-tertiary'          => '#586339',
                '--md-surface'           => '#FFFBFF',
                '--md-surface-dim'       => '#E0D9D1',
                '--md-surface-bright'    => '#FFFBFF',
                '--md-surface-container-lowest'  => '#FFFFFF',
                '--md-surface-container-low'     => '#FAF3EB',
                '--md-surface-container'         => '#F4EDE5',
                '--md-surface-container-high'    => '#EEE8E0',
                '--md-surface-container-highest' => '#E8E2DA',
                '--md-on-surface'        => '#201B13',
                '--md-on-surface-variant' => '#51453A',
                '--md-outline'           => '#837568',
                '--md-outline-variant'   => '#D5C3B5',
                '--md-error'             => '#BA1A1A',
                '--md-on-error'          => '#FFFFFF',
                '--md-error-container'   => '#FFDAD6',
                '--md-on-error-container' => '#410E0B',
                '--md-dark-primary'           => '#FFB870',
                '--md-dark-on-primary'        => '#4A2800',
                '--md-dark-primary-container' => '#6A3C00',
                '--md-dark-on-primary-container' => '#FFDCBE',
                '--md-dark-secondary'         => '#DFBFA3',
                '--md-dark-tertiary'       => '#CFD8B6',
                '--md-dark-surface'           => '#201B13',
                '--md-dark-surface-dim'       => '#201B13',
                '--md-dark-surface-bright'    => '#423A31',
                '--md-dark-surface-container-lowest'  => '#140F08',
                '--md-dark-surface-container-low'     => '#29231B',
                '--md-dark-surface-container'         => '#332D25',
                '--md-dark-surface-container-high'    => '#3E3830',
                '--md-dark-surface-container-highest' => '#4A443B',
                '--md-dark-on-surface'        => '#ECE0D4',
                '--md-dark-on-surface-variant' => '#D5C3B5',
                '--md-dark-outline'           => '#9D8E81',
                '--md-dark-outline-variant'   => '#51453A',
                '--md-dark-error'             => '#FFB4AB',
            ),
            'pink' => array(
                '--md-primary'           => '#74565F',
                '--md-on-primary'        => '#FFFFFF',
                '--md-primary-container' => '#FFD9E3',
                '--md-on-primary-container' => '#3E001E',
                '--md-secondary'         => '#74565F',
                '--md-on-secondary'      => '#FFFFFF',
                '--md-secondary-container' => '#FFD9E3',
                '--md-on-secondary-container' => '#2B151C',
                '--md-tertiary'          => '#7C5635',
                '--md-surface'           => '#FFFBFF',
                '--md-surface-dim'       => '#E4D6DB',
                '--md-surface-bright'    => '#FFFBFF',
                '--md-surface-container-lowest'  => '#FFFFFF',
                '--md-surface-container-low'     => '#FEF0F4',
                '--md-surface-container'         => '#F9EAEF',
                '--md-surface-container-high'    => '#F3E5E9',
                '--md-surface-container-highest' => '#EDDFE4',
                '--md-on-surface'        => '#201A1C',
                '--md-on-surface-variant' => '#524347',
                '--md-outline'           => '#847377',
                '--md-outline-variant'   => '#D5C2C6',
                '--md-error'             => '#BA1A1A',
                '--md-on-error'          => '#FFFFFF',
                '--md-error-container'   => '#FFDAD6',
                '--md-on-error-container' => '#410E0B',
                '--md-dark-primary'           => '#FFB0CA',
                '--md-dark-on-primary'        => '#5E1133',
                '--md-dark-primary-container' => '#7C294A',
                '--md-dark-on-primary-container' => '#FFD9E3',
                '--md-dark-secondary'         => '#E2BDC7',
                '--md-dark-tertiary'       => '#DAC6B3',
                '--md-dark-surface'           => '#201A1C',
                '--md-dark-surface-dim'       => '#201A1C',
                '--md-dark-surface-bright'    => '#3F383A',
                '--md-dark-surface-container-lowest'  => '#150F11',
                '--md-dark-surface-container-low'     => '#29222B',
                '--md-dark-surface-container'         => '#332C2F',
                '--md-dark-surface-container-high'    => '#3E373A',
                '--md-dark-surface-container-highest' => '#4A4345',
                '--md-dark-on-surface'        => '#EDDFE4',
                '--md-dark-on-surface-variant' => '#D5C2C6',
                '--md-dark-outline'           => '#9E8C90',
                '--md-dark-outline-variant'   => '#524347',
                '--md-dark-error'             => '#FFB4AB',
            ),
            'red' => array(
                '--md-primary'           => '#775654',
                '--md-on-primary'        => '#FFFFFF',
                '--md-primary-container' => '#FFDAD7',
                '--md-on-primary-container' => '#410005',
                '--md-secondary'         => '#775654',
                '--md-on-secondary'      => '#FFFFFF',
                '--md-secondary-container' => '#FFDAD7',
                '--md-on-secondary-container' => '#2C1514',
                '--md-tertiary'          => '#725B2E',
                '--md-surface'           => '#FFFBFF',
                '--md-surface-dim'       => '#E3D6D5',
                '--md-surface-bright'    => '#FFFBFF',
                '--md-surface-container-lowest'  => '#FFFFFF',
                '--md-surface-container-low'     => '#FDF0EF',
                '--md-surface-container'         => '#F8EAEA',
                '--md-surface-container-high'    => '#F2E4E3',
                '--md-surface-container-highest' => '#ECDEDE',
                '--md-on-surface'        => '#201A19',
                '--md-on-surface-variant' => '#534342',
                '--md-outline'           => '#857372',
                '--md-outline-variant'   => '#D8C2C0',
                '--md-error'             => '#BA1A1A',
                '--md-on-error'          => '#FFFFFF',
                '--md-error-container'   => '#FFDAD6',
                '--md-on-error-container' => '#410E0B',
                '--md-dark-primary'           => '#FFB3AD',
                '--md-dark-on-primary'        => '#68000E',
                '--md-dark-primary-container' => '#930016',
                '--md-dark-on-primary-container' => '#FFDAD7',
                '--md-dark-secondary'         => '#E7BDB9',
                '--md-dark-tertiary'       => '#D8CDB5',
                '--md-dark-surface'           => '#201A19',
                '--md-dark-surface-dim'       => '#201A19',
                '--md-dark-surface-bright'    => '#413735',
                '--md-dark-surface-container-lowest'  => '#140E0D',
                '--md-dark-surface-container-low'     => '#291F1E',
                '--md-dark-surface-container'         => '#332928',
                '--md-dark-surface-container-high'    => '#3E3433',
                '--md-dark-surface-container-highest' => '#4A3F3E',
                '--md-dark-on-surface'        => '#ECDEDE',
                '--md-dark-on-surface-variant' => '#D8C2C0',
                '--md-dark-outline'           => '#A08C8B',
                '--md-dark-outline-variant'   => '#534342',
                '--md-dark-error'             => '#FFB4AB',
            ),
        );
        return isset($schemes[$scheme]) ? $schemes[$scheme] : $schemes['purple'];
    }
}
