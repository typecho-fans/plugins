# Dynamics

**我的动态** 不依赖评论框架，而是单独建表。

**什么是我的动态呢？**
像QQ一样，可以在南博发布说说，加上使用**我的动态插件**就可以在博客需要的地方，显示我的动态即说说。
插件：https://github.com/krait-team/Dynamics-typecho/

## 动态主题
可以在themes目录下使用自己开发的动态主题，类似ty主题，然后在我的动态的插件设置选择主题

## 使用教程
https://github.com/krait-team/Dynamics-typecho/wiki

https://docs.nabo.krait.cn/#/course-dynamics
