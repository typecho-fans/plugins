# Dynamics

**我的动态**

## 使用教程

 - https://nabo.krait.cn/docs/#/course-dynamics
 - https://github.com/krait-team/Dynamics-typecho/wiki