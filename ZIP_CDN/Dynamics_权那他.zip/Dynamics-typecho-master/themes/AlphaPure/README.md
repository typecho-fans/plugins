# AlphaPure - A Theme For Nabo Dynamics

Author：[@ShangJixin](https://github.com/ShangJixin/)

Plugin:[@kraity](https://github.com/kraity/Dynamics/)

欢迎基于此进行改造~
