<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$pageType = '404';
include('header.php');
?>
<h1 class="miui-style">我的动态</h1>
<div class="nabo-dynamics">

    <div class="dynamic-content">
        错误！该路径不存在！
    </div>
</div>

<?php include('footer.php'); ?>
