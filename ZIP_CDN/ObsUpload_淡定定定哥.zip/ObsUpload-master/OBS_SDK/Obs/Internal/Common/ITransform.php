<?php
namespace Obs\Internal\Common;

interface ITransform {
    public function transform($sign, $para);
}

