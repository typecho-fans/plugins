# AvatarQQ

## 简介

Typecho 插件,将评论者的头像替换为 QQ 头像(如果是 QQ 邮箱).

## 安装

1.下载 AvatarQQ.php 文件,并复制到 /usr/plugins 中.

2.在博客后台启用此插件.

## License
```
   Copyright 2019 web1n

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
```
