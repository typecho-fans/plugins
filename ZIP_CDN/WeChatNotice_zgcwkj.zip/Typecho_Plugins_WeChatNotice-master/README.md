# Typecho_Plugins_WeChatNotice

Typecho 插件：微信公众号消息推送插件
<br />
Blog：[zgcwkj](http://zgcwkj.cn)

# 使用方法

![001.png](img/001.png)

![002.png](img/002.png)
