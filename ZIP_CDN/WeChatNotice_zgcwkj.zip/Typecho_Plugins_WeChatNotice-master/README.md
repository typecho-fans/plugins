# Typecho_Plugins_WeChatNotice

Typecho插件、微信公众号消息推送插件

# 使用方法

![001.png](img/001.png)