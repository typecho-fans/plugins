<?php

class BufannaoWap_Login extends Widget_Login
{
    public function action()
    {
		Typecho_Widget::widget('Widget_Notice')->to($notice);
		$rememberName = Typecho_Cookie::get('__typecho_remember_name');
		Typecho_Cookie::delete('__typecho_remember_name');
		BufannaoWap_Plugin::wapHeader();
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Cache-control" content="no-cache" />
<style type="text/css">
</style>
<title>登录 - <?php $this->options->title(); ?></title>
</head>
<body>
<form action="<?php $this->options->loginAction(); ?>" method="post" name="login">
<?php if(!$this->user->hasLogin()): ?>
<?php if($notice->have() && in_array($notice->noticeType, array('success', 'notice', 'error'))): ?>
<ul>
<?php $notice->lists(); ?>
</ul>
<?php endif; ?>
<p><?php _e('用户名'); ?>:<br /><input type="text" id="name" name="name" value="<?php echo $rememberName; ?>" /></p>
<p><?php _e('密码'); ?>:<br /><input type="password" id="password" name="password" /></p>
<p><input type="checkbox" name="remember" value="1" /> <?php _e('记住我'); ?><br /><input type="submit" value="<?php _e('登录'); ?>" /><input type="hidden" name="referer" value="<?php echo htmlspecialchars($this->request->get('referer', $this->options->siteUrl)); ?>" /></p>
<?php else: ?>
<p><?php _e('您已经登录到%s', $this->options->title); ?></p>
<?php endif; ?>
</form>
<p><a href="<?php $this->options->siteUrl(); ?>"><?php _e('&laquo; 返回%s', $this->options->title); ?></a></p>
</body>
</html>
<?php
    }
}
