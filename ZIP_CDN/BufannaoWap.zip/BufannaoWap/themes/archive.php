<?php
require $this->getThemeDir() . 'header.php';
?>

<?php
require $this->getThemeDir() . 'sidebar.php';
?>

<?php
require $this->getThemeDir() . 'footer.php';
