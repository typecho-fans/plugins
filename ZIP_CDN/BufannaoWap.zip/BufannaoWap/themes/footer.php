<!-- pagelist -->
<div id="pagelist">
<div class="headline">管理页面</div>
<?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
<p><a href="<?php $this->options->siteUrl(); ?>">首页</a>&nbsp;|&nbsp;<?php if($this->user->hasLogin()): ?><a href="<?php $this->options->logoutUrl(); ?>"><?php _e('退出登录'); ?></a>&nbsp;|&nbsp;<a href="<?php echo Typecho_Common::url('/action/wap-editPost', $this->options->index); ?>">创建文章</a>&nbsp;|&nbsp;<a href="<?php echo Typecho_Common::url('/action/wap-editPage', $this->options->index); ?>">创建页面</a>&nbsp;|&nbsp;<a href="<?php echo Typecho_Common::url('/action/wap-editComment', $this->options->index); ?>">审核评论</a><?php else: ?><a href="<?php echo Typecho_Common::url('/action/wap-login', $this->options->index); ?>">登录</a><?php endif; ?><?php while($pages->next()): ?>
&nbsp;|&nbsp;<a href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a>
<?php endwhile; ?></p>
</div>

<div id="footer">
<p>&copy;2011&nbsp;<a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title() ?></a>&nbsp;-&nbsp;<a href="http://bufannao.com" class="light">WAP版</a><br />powered by <a href="http://www.typecho.org">Typecho)))</a>&nbsp;<a href="#header">▲top</a></p>
</div>
<?php echo Helper::options()->plugin('BufannaoWap')->footer; ?>
</body>
</html>
