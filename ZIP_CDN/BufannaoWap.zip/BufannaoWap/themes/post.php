<?php require $this->getThemeDir() . 'header.php'; ?>
<div id="article">
<div class="headline"><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></div>
<p><?php _e('作者：'); ?><?php $this->author(); ?></p>
<p><?php _e('分类：'); ?><?php $this->category(','); ?></p>
<p><?php _e('标签：'); ?><?php $this->tags(', ', true, 'none'); ?></p>
<p><?php _e('评论：'); ?><?php $this->commentsNum('No Comments', '1 Comment', '%d Comments'); ?></p>
<p><?php _e('发布时间：'); ?><?php $this->date('Y-m-d'); ?></p>
<p><?php _e('文章链接：'); ?><a href="<?php $this->permalink() ?>"><?php $this->permalink() ?></a></p>
<?php if(!$this->is('attachment') AND !Helper::options()->plugin('BufannaoWap')->showPic) : ?>
<?php echo preg_replace('/<img.*?\s+src=\"([^"]+?)\"[^>]*?>/is', '<ins>图片：\\1</ins>', $this->content); ?>
<?php else: ?>
<?php $this->content(); ?>
<?php endif; ?>
<?php if($this->user->hasLogin()): ?>
<p><?php _e('文章管理：'); ?><a href="<?php echo Typecho_Common::url('/action/wap-editPost?cid='.$this->cid, $this->options->index); ?>">编辑</a>&nbsp;|&nbsp;<a href="<?php echo Typecho_Common::url('/action/wap-editPost?do=delete&cid='.$this->cid, $this->options->index); ?>">删除</a></p>
<?php endif; ?>
<p><?php $this->thePrev('上一篇：%s'); ?></p>
<p><?php $this->theNext('下一篇：%s'); ?></p>
</div>
<div id="related">
<div class="headline"><?php _e('相关文章'); ?></div>
<?php $this->related(5)->to($relatedPosts); ?> 
<?php if ($relatedPosts->have()): ?>
<?php while ($relatedPosts->next()): ?>
<p><?php $relatedPosts->sequence();?>.&nbsp;<a href="<?php $relatedPosts->permalink(); ?>" title="<?php $relatedPosts->title(); ?>"><?php $relatedPosts->title(12); ?></a></p> 
<?php endwhile; ?>
<?php else: ?>
<p><?php _e('没有找到相关文章'); ?></p>
<?php endif; ?>
</div>

<?php require $this->getThemeDir() . 'comments.php'; ?>

<?php
require $this->getThemeDir() . 'footer.php';
