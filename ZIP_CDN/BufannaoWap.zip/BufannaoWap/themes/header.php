<?php BufannaoWap_Plugin::wapHeader(); ?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Cache-control" content="no-cache" />
<style type="text/css">
</style>
<link rel="alternate" type="application/rss+xml" title="<?php $this->options->title() ?> RSS Feed" href="<?php $this->options->feedUrl(); ?>" />
<link rel="stylesheet" type="text/css" media="all" href="<?php $this->options->pluginUrl('BufannaoWap/themes/style.css'); ?>" />
<?php echo $this->options->plugin('BufannaoWap')->header; ?>
<title><?php if($this->is('post')): ?><?php $this->title() ?> - <?php $this->category(' - ', false); ?> - <?php elseif($this->is('category')): ?><?php $this->category(' - ', false); ?> - <?php else: ?><?php $this->archiveTitle(' - ', '', ' - '); ?><?php endif; ?><?php $this->options->title(); ?></title>
</head>
<body>

<!-- header -->
<div id="header">
<div id="title"><a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title() ?></a></div>
<div id="description"><?php $this->options->description() ?></div>
</div>

<!-- breadcrumb -->
<?php if ($this->is('index')): ?>
<div id="search">
<form id="search" method="post" action="/">
<input type="text" name="s" size="15" /><input type="submit" value="<?php _e('搜索'); ?>" />
</form>
</div>
<?php else: ?>
<div id="breadcrumb">
当前位置：<a href="<?php $this->options->siteUrl(); ?>">首页</a> &raquo; <?php if($this->is('post')): ?><?php $this->category(); ?> &raquo; <?php $this->title() ?>
<?php else: ?>
<?php $this->archiveTitle(' &raquo; ','',''); ?>
<?php endif; ?>
</div>
<?php endif; ?>
