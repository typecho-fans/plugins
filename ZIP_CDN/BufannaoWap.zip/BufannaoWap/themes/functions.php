<?php
function threadedComments($widget, $singleCommentOptions)
{

	echo '<div class="comment-list">';
	echo '<p id="comment-'.$widget->coid.'">';
	$widget->author();
	if(!$widget->isTopLevel)
	{
		echo '&nbsp;|&nbsp;';
		$widget->reply('@'.$widget->coid);
	}
	echo ($widget->parent ? '&nbsp;|&nbsp;<a href="#comment-'.$widget->parent.'">#'.$widget->parent.'</a>' : '');
	echo '</p>';
	echo '<p>'.($widget->parent ? '回复时间：' : '评论时间：');
	$widget->date($singleCommentOptions->dateFormat);
	echo '</p>';
	$widget->content();
	if(Typecho_Widget::widget('Widget_User')->hasLogin())
	{
		echo '<p>评论管理：<a href="'.Typecho_Common::url('/action/wap-editComment?do=edit&coid='.$widget->coid, Helper::options()->index).'">编辑</a>&nbsp;|&nbsp;<a href="'.Typecho_Common::url('/action/wap-editComment?do=delete&coid='.$widget->coid, Helper::options()->index).'">删除</a></p>';
	}
	echo '</div>';
	if ($widget->children)
	{
		$widget->threadedComments($singleCommentOptions);
	}
}
