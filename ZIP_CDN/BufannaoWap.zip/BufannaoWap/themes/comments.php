<div id="comments">
<div class="headline"><?php _e('文章评论'); ?></div>
<?php Helper::options()->commentsThreaded = FALSE; ?>
<?php Helper::options()->commentsPageBreak = 0; ?>
<?php $this->comments()->to($comments); ?>
<?php Helper::options()->commentsThreaded = TRUE; ?>
<?php if ($comments->have()): ?>
<ol>
<?php $comments->listComments(array('before' => '', 'after' => '', 'dateFormat' =>'Y-m-d H:i')); ?>
</ol>
<?php $comments->pageNav(); ?>
<?php else: ?>
<p><?php _e('没有找到文章评论'); ?></p>
<?php endif; ?>

            <?php if($this->allow('comment')): ?>
            <div id="<?php $this->respondId(); ?>" class="respond">

			<div id="response">
			<div class="headline"><?php _e('发表评论'); ?>&nbsp;<span class="cancel-comment-reply"><?php $comments->cancelReply(); ?></span></div>
			<form method="post" action="<?php $this->commentUrl() ?>" id="comment_form">
                <?php if($this->user->hasLogin()): ?>
				<p>Logged in as <a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>. <a href="<?php $this->options->logoutUrl(); ?>" title="Logout"><?php _e('退出'); ?> &raquo;</a></p>
                <?php else: ?>
				<p><?php _e('称呼'); ?><span class="required">*</span><br />	<input type="text" name="author" value="<?php $this->remember('author'); ?>" /></p>
				<p><?php _e('电子邮件'); ?><?php if ($this->options->commentsRequireMail): ?><span class="required">*</span><?php endif; ?><br />	<input type="text" name="mail" value="<?php $this->remember('mail'); ?>" /></p>
				<p><?php _e('网站'); ?><?php if ($this->options->commentsRequireURL): ?><span class="required">*</span><?php endif; ?><br /><input type="text" name="url" value="<?php $this->remember('url'); ?>" /></p>
                <?php endif; ?>
				<p><textarea rows="3" name="text"><?php $this->remember('text'); ?></textarea></p>
				<p><input type="submit" value="<?php _e('提交评论'); ?>" /></p>
			</form>
            </div>
            <?php else: ?>
            <p><?php _e('评论已关闭'); ?></p>
            <?php endif; ?>
		</div>
