<?php
require $this->getThemeDir() . 'header.php';
?>

<p>404 - <?php _e('页面没找到'); ?></p>
<p><a href="<?php $this->options->siteUrl(); ?>"><?php _e('&laquo; 返回%s', $this->options->title); ?></a></p>
<?php
require $this->getThemeDir() . 'footer.php';
