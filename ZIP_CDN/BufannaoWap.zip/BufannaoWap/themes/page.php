<?php require $this->getThemeDir() . 'header.php'; ?>
<div id="article">
<div class="headline"><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></div>
<p><?php _e('作者：'); ?><?php $this->author(); ?></p>
<p><?php _e('评论：'); ?><?php $this->commentsNum('No Comments', '1 Comment', '%d Comments'); ?></p>
<p><?php _e('发布时间：'); ?><?php $this->date('Y-m-d'); ?></p>
<?php if(!$this->is('attachment') AND !Helper::options()->plugin('BufannaoWap')->showPic) : ?>
<?php echo preg_replace('/<img.*?\s+src=\"([^"]+?)\"[^>]*?>/is', '<ins>图片：\\1</ins>', $this->content); ?>
<?php else: ?>
<?php $this->content(); ?>
<?php endif; ?>
<?php if($this->user->hasLogin()): ?>
<p><?php _e('页面管理：'); ?><a href="<?php echo Typecho_Common::url('/action/wap-editPage?cid='.$this->cid, $this->options->index); ?>">编辑</a>&nbsp;|&nbsp;<a href="<?php echo Typecho_Common::url('/action/wap-editPage?do=delete&cid='.$this->cid, $this->options->index); ?>">删除</a></p>
<?php endif; ?>
</div>

<?php require $this->getThemeDir() . 'comments.php'; ?>

<?php
require $this->getThemeDir() . 'footer.php';
