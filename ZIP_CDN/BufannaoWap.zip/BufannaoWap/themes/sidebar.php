<!-- articlelist -->
<div id="articlelist">
<div class="headline">最新文章</div>
<?php while($this->next()): ?>
<div class="post">
<p><a href="<?php $this->permalink() ?>"><?php $this->title(12) ?></a></p>
<p><?php $this->date('Y-m-d'); ?> | <?php $this->commentsNum('No Comments', '1 Comment', '%d Comments'); ?></p>
</div>
<?php endwhile; ?>
<!-- pagenav -->
<?php $this->pageNav(); ?>
</div>

<!-- categorylist -->
<div id="categorylist">
<div class="headline">分类列表</div>
<?php $this->widget('Widget_Metas_Category_List')->to($category); ?>
<?php while($category->next()): ?>
<p><?php $category->sequence();?>.&nbsp;<a href="<?php $category->permalink(); ?>"><?php $category->name(); ?></a></p>
<?php endwhile; ?>
</div>

<!-- commentlist -->
<div id="commentlist">
<div class="headline">最新评论</div>
<?php $this->widget('Widget_Comments_Recent',array('ignoreAuthor' => TRUE))->to($comments); ?>
<?php while($comments->next()): ?>
<p><?php $comments->sequence();?>.&nbsp;<a href="<?php $comments->permalink(); ?>"><?php $comments->excerpt(10, '...'); ?></a></p>
<?php endwhile; ?>
</div>
