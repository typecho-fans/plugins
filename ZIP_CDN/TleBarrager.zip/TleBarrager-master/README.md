### TleBarragerForTypecho弹幕插件
---

为Typecho增加评论弹幕功能

#### 使用方法：
第一步：下载本插件，放在 `usr/plugins/` 目录中（插件文件夹名必须为TleBarrager）；

第二步：激活插件；

第三步：填写配置；

第四步：完成。

#### 与我联系：
作者：二呆

网站：http://www.tongleer.com/

Github：https://github.com/muzishanshi/TleBarrager

#### 更新记录：
2019-10-17 V1.0.3

	修复上次更新因马虎和便捷操作产生的bug。
	
2019-10-16 V1.0.2

	1、增加了jquery载入控制；
	2、修改成自动加载弹幕代码等
	
2019-04-22 V1.0.1

	第一版本实现