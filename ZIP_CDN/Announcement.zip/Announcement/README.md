### Typecho悬浮式公告栏插件Announcement v1.0.0

给你的Typecho提供公告栏的功能，从Emlog的公告栏插件修改而成
- 纯插件支持
- 显示位置支持弹窗展示和底部固定
- 显示区域支持全站或者仅首页
- 弹出框公告支持最小化模式，且24小时只自动弹出一次。
- 支持手动或者自动加载Jquery库

###### 更多详见论坛原帖：http://forum.typecho.org/viewtopic.php?f=6&t=5443