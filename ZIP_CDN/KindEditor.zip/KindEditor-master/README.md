typecho kindeditor plugin
==================

新版的typecho0.9 kindeditor插件，支持上传，自动保存。
文件上传完美兼容。

插件名称应该为KindEditor

## TODO

* ~~文件浏览~~ 为系统安全性不再增加文件浏览
* ~~工具栏模式选择~~
