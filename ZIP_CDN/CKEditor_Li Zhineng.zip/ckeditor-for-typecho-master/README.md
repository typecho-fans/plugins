# CKEditor for Typecho

一个用 CKEditor 替换 Typecho 默认编辑器的插件

## 开发环境

* Typecho 1.0 (14.10.10)
* CKEditor 4.5.3

## 插件特性

* 兼容 Typecho 自带的附件插入功能

## 使用方法

1. 把插件根目录 `CKEditor` 放入 Typecho 插件目录 `/usr/plugins/`.
2. 进入后台插件管理，找到 CKEditor 插件，点击开启。
3. 大功告成，你现在可以通过 CKEditor 编辑文章进行创作了。

## 授权协议

插件在 GPL v2 许可证下开源，详细可以查看 LICENSE 文件。# Typecho plugin: CKEditor
