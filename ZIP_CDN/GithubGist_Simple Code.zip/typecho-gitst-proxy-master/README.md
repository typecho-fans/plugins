# typecho-gitst-proxy
代理 Github 的 Gist, 防止国内一些用户打不开.

# 使用:

1. 把 `GithubGist.php` 文件放到网站根目录的 `/usr/plugins` 下面.
2. 进入后台, 依次找到: 控制台->插件->Github Gist 点击启用

之后博客文章内部的以 `https://gist.github.com/` 开头的链接就会使用我的代理加载.
