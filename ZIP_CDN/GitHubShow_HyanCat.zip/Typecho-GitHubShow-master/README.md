Typecho-GitHubShow
==================

用于在typecho博客文章中展示github组件的插件

使用方法：

1. 复制至插件目录并启用，无需设置。
2. 在文章中需要引入GitHub组件的地方输入以下代码即可：

		[github show="HyanCat/Typecho-GitHubShow"]

注：目前只针对github可以使用，且只在文章中引入有效。