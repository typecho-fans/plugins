# Typecho-ShortLinks-Plugin
typecho的外链转换内链插件（目标是更好的兼容handsome主题）
