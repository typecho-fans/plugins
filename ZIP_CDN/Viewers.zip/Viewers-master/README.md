# Viewers

Typecho读者墙插件

## Instructions

即插即用插件，使用`Viewers_Plugin::render($mode, $limit, $size);`模板输出读者墙
* $mode=NULL：模板样式
* $limit=NULL：人数上限
* $size=40：头像大小

## Changelog

### 0.1.0

* 实现基本功能