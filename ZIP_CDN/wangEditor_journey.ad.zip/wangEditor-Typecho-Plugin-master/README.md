# wangEditor

**富文本编辑器 [wangEditor](https://github.com/wangfupeng1988/wangEditor/) for Typecho**

[Demo](https://imjad.cn/archives/none/wangeditor-for-typecho)

![img](https://img.imjad.cn/images/2017/07/09/Screenshot-20170709143733-824x419.png)

## 介绍

- 支持emoji😋；
- 可通过粘贴快速上传图片；
- 支持代码/引用插入、快速创建表格；

## 使用

点击 ```Download ZIP``` 按钮，解压，将 wangEditor-Typecho-Plugin-master 重命名为 wangEditor ，之后上传到你博客中的 /usr/plugins 目录，在后台启用即可

_注意：这是一个富文本编辑器，并未采用 Markdown 语法_

## LICENSE

MIT © [journey.ad](https://github.com/journey-ad/)
