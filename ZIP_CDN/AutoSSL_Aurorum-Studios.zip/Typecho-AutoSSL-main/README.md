# Typecho-AutoSSL

正式的readme正在写哦

安装并激活插件后在“控制台”里面找到“在线生成SSL证书”按照引导就能很方便地生成SSL证书

 * 在线自动生成免费SSL证书，解决SSL证书的烦恼。自动进行域名所有权验证，不需要有主机权限就可以轻松在线生成一份SSL证书。可以从 Let's Encrypt, ZeroSSL, Google中选择一家机构免费生成SSL证书。
 * 
 * @package 在线生成SSL证书
 * @author Aurorum-Studios
 * @version v.0.0.2
 * @link https://open.aurorum.co/t/aurorum-studio-typecho-autossl
 */
