CREATE TABLE `typecho_connect` (
  `uid` int(10) NOT NULL PRIMARY KEY,
  `qqOpenId` varchar(64) default NULL,
  `weiboOpenId` varchar(64) default NULL,
);
