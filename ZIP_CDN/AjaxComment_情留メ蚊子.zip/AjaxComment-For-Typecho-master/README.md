# AjaxComment For Typecho

Typecho插件：支持Ajax评论

开发者：情留メ蚊子

插件地址：[http://www.94qing.com/ajaxcomment-for-typecho.html](http://www.94qing.com/ajaxcomment-for-typecho.html)

最新版本：1.0.0.0

更新日期：2017-01-12