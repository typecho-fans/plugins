<!DOCTYPE HTML>
<html class="no-js">
    <head>
        <meta charset="UTF-8">
      	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="renderer" content="webkit">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>会员中心</title>
      	<style>
          *{margin:0;
            padding:0;}
          html,body{
          	height:100%;
            width:100%;
          }
        </style>
    </head>
    <body>
  		<!--<iframe id="contentPage" src="admin" scrolling="yes" frameborder="0" marginheight="0" marginwidth="0" width="100%" height="100%" frameborder="0"></iframe>-->
	    <script type="text/javascript">
		window.location.href="admin";
		</script>
	</body>
</html>
