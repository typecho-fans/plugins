# phpQuery-single
phpQuery单文件版本，是Querylist的依赖(http://querylist.cc )，phpQuery项目主页:http://code.google.com/p/phpquery/

## 安装

```
composer require jaeger/phpquery-single
```