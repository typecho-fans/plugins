AliceStyle
### 介绍

本插件附带了常见的美化功能，如：
 1、首页文章列表获取焦点放大
 2、首页头像自动旋转
 3、首页文章版式阴影化
 4、首页文章图片获取焦点放大
 5、顶部彩色跑马灯特效
 6、文章内打赏处插入menhera酱求打赏图片
 7、文章内打赏图标跳动
 8、右侧列表导航栏图标颜色
 9、canvas动态背景
 10、页面背景透明
 11、主题盒子优化等效果
 12、评论框打字粒子特效
 13、彩色标签特效

最新更新时间：`2019-11-27`

### 起始

最初的美化教程  http://racns.com/index.php/211.html  
AliceStyle插件使用教程  http://racns.com/index.php/374.html


### 激活

以Handsome主题为例：

第 1 步：下载本插件，解压，放到 usr/plugins/ 目录中；

第 2 步：文件夹名改为 AliceStyle；

第 3 步：登录管理后台，激活插件 （请勿与其它同类插件同时启用，以免互相影响）

第 4 步：设置：选择主题风格、动态背景风格等。


### 重要说明

#### 可设置项

选择主题动态背景风格-提供了13个动态背景可选，总有一款适合你

- HackereMpire-01
- HackereMpire
- Kaleidoscope
- MagnetLine
- PinkBubble
- Rainbow
- Raindrop
- RiseBalloon
- RiseLove
- ScienceLine
- SodaWater
- StarrySky
- wave


### 后记

插件的兼容性应该不存在什么问题，博主在Handsome主题上使用一切正常

如果你在其他主题使用过程中出现了问题可以随时联系我

若有任何意见或发现任何BUG欢迎访问到我的博客racns.com留言
